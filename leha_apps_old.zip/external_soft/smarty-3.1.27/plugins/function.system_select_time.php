<?php
// yozh
function smarty_function_system_select_time($params) {
	$options = [
		'date'	=> time(),
		'name'	=> 'data',
	];
	foreach($options as $k=>$v)
		if(isset($params[$k]))
			$options[$k] = $params[$k];

	$a = $GLOBALS['lib']->date_time->to_array($options['date']);

	$_html = "";
	foreach (['h'=>24, 'i'=>60, 's'=>60] as $k=>$n) {
		$_html .= ($k=='h'?'':"<span>:</span>\n").
			"<select name='{$options['name']}[{$k}]' class='w40'>\n";
		for($i=0; $i<$n; $i++)
			$_html .= "<option value='{$i}'".($a[$k]==$i?' selected':'').">".sprintf("%02d", $i)."</option>\n";
		$_html .= "</select>\n";
	}

	return $_html;
}
