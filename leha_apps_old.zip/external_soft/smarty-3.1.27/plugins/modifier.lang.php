<?php // yozh
function smarty_modifier_lang($data, $index=false) {
	if (is_array($data)) {
		$res = '';
		foreach ($data as $i)
			$res .= smarty_modifier_lang($i).' ';
		return $res;
	}
	if ($index!==false)
		if (isset($GLOBALS['lang'][$data][$index]))
			return $GLOBALS['lang'][$data][$index];

	if (isset($GLOBALS['lang'][$data]))
		return $GLOBALS['lang'][$data];

	return "<span style='background-color: red'>{$data}</span>";
}
