<?php
function smarty_modifier_mail_hash($string, $hash_type) {
	$res = '';
	$symbols = ['@'=>'&#64;', '.'=>'&#46;', ':'=>'&#58;'];
	if (empty($hash_type) || $hash_type=='hash') {
		$f = function ($n) use ($string, $symbols) {
			$c = isset($string[$n]) ? $string[$n] : '';
			return isset($symbols[$c]) ? $symbols[$c] : $c;
		};
		for($i=0; $i<strlen($string); $i+=3) {
			$res .= $f($i+2).$f($i+1).$f($i);
		}
	}
	if ($hash_type=='html') {
		for($i=0; $i<strlen($string); $i+=2) {
			$res .= '<span>'.str_replace(array_keys($symbols), array_values($symbols), substr($string, $i, 2)).'</span>';
		}
	}
	return $res;
}
