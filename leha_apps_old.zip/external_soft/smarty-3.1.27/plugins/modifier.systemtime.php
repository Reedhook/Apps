<?php
//yozh
function smarty_modifier_systemtime($string) {
	return $GLOBALS['lib']->date_time->to_sql_time($string);
}
