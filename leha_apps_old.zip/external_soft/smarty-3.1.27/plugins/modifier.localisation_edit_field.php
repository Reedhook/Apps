<?php
function smarty_modifier_localisation_edit_field($field_name, $data=[]) {
	$lang_list = $GLOBALS['lib']->lang->list;
	$current_lang = $GLOBALS['lib']->lang->value;

	$input = function($lang) use($data, $field_name, $current_lang) {
		return "<div class='flex-block between5'>
<input type='text' name='data[{$field_name}][{$lang}]' value='{$data[$field_name][$lang]}' />
<div class='btn icon".($lang==$current_lang?'':' disabled')."'".($lang==$current_lang? " onclick='this.parentNode.parentNode.querySelector(\".lang-list\").classList.toggle(\"display-none\")'":'').">{$lang}</div>
</div>\n";
	};

	$res = "<div class='flex-block vert between5'>".$input($current_lang)."<div class='lang-list display-none flex-block vert between5'>\n";
	foreach ($lang_list as $lang) if ($lang != $current_lang) $res .= $input($lang);
	return $res."</div></div>";
}
