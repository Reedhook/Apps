<?php
//yozh
function smarty_modifier_systemdatetime($string) {
	return $GLOBALS['lib']->date_time->to_format($string, true);
}
