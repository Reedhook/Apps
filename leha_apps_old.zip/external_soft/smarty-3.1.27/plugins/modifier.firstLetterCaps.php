<?php // yozh
function smarty_modifier_firstLetterCaps($str) {
	if (mb_strlen($str)>0) {
		$first = mb_substr($str, 0, 1);
		$first_Up = mb_strtoupper($first);
		if (mb_strlen($str)>1) {
			$second = mb_substr($str, 1, 1);
			$second_Up = mb_strtoupper($second);
			if ($first===$first_Up && $second===$second_Up) {// abbreviation
				return $str;
			} else {
				return $first_Up.mb_strtolower(mb_substr($str, 1));
			}
		}
		return $first_Up;
	}
	return '';
}
