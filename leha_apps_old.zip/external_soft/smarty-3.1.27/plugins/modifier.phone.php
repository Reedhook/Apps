<?php
// yozh
function smarty_modifier_phone($str) {
	return $GLOBALS['lib']->phone->format($str);
}
