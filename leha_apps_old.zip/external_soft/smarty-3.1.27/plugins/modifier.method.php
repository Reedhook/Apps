<?php // yozh
function smarty_modifier_method($data, $method) {
	return $method($data);
}
