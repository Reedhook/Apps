<?php
// yozh
function smarty_modifier_systemdate($string) {
	return $GLOBALS['lib']->date_time->to_format($string);
}
