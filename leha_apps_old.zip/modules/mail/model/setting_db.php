<?php
namespace mail;
class setting_db extends \setting_db {
	protected static $setting_group = 'mail';
	protected static $setting_list = [];

	static $setting_map = [
//		'mail_settings'	=> ['type'=>'group'],
		'mail_cron'		=> ['type'=>'checkbox'],
	];
}
