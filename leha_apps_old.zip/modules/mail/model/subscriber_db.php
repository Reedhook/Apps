<?php
namespace mail;

class subscriber_db extends \table_db {
	protected static $table_name = 'subscriber';
	protected static $field_list = [
		'name'		=> ['type'=>'str'],
		'email'		=> ['type'=>'str'],
		'phone'		=> ['type'=>'str'],
		'is_active'	=> ['type'=>'bool'],
	];
	protected static $columns = [
		'id'		=> ['sorted'=>true, 'className'=>'a-right w50'],
		'name'		=> ['sorted'=>true],
		'email'		=> ['sorted'=>true],
		'is_active'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_edit_field_bool', 'className'=>'a-right w50'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'name', 'dir'=>'asc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default'	=> [
			'id'		=> ['type'=>'int'],
			'name'		=> ['type'=>'like'],
			'email'		=> ['type'=>'like'],
			'phone'		=> ['type'=>'like'],
			'is_active'	=> ['type'=>'yes_no'],
		]
	];
	public function access($action) {
		if (in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			return true;
		return false;
	}

}
/*
ES_CALLBACK_MARKET_MESSAGE
MUS_CATALOG_REQUEST
ES_USER_ACTIVATED
*/
