<?php
namespace mail;

class mail_template_db extends \table_db {
	protected static $table_name = 'mail_template';
	protected static $field_list = [
		'name'			=> ['type'=>'str'],
		'subject'		=> ['type'=>'str'],
		'html'			=> ['type'=>'text', 'html'=>true],
		'code'			=> ['type'=>'str'],
	];
	protected static $columns = [
		'id'		=> ['sorted' => true, 'className' => 'a-right w50'],
		'name'		=> ['sorted' => true],
		'code'		=> ['sorted' => true],
		'functions'	=> ['className'=>'w0', 'js_formatter' => 'td_formatter_icons', 'title'=>''],
	];
	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'code', 'dir'=>'asc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default'	=> [
			'id'		=> ['type'=>'int'],
			'name'		=> ['type'=>'like'],
			'subject'	=> ['type'=>'like'],
			'html'		=> ['type'=>'like'],
			'code'		=> ['type'=>'like'],
		]
	];
	public function access($action) {
		if (in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			return true;
		return false;
	}
}
/*
ES_CALLBACK_MARKET_MESSAGE
MUS_CATALOG_REQUEST
ES_USER_ACTIVATED
*/
