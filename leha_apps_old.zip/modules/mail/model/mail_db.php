<?php
namespace mail;

class mail_db extends \table_db{
	protected static $table_name = 'mail';

	protected static $field_list = [
		'created'	=> ['type'=>'datetime'],
		'from_mail'	=> ['type'=>'str'],
		'from_name'	=> ['type'=>'str'],
		'to_mail'	=> ['type'=>'str'],
		'to_name'	=> ['type'=>'str'],
		'subject'	=> ['type'=>'str'],
		'body'		=> ['type'=>'text', 'html'=>true],
		'status'	=> ['type'=>'enum'],
		'error'		=> ['type'=>'text'],
//		'is_html'	=> ['type'=>'int']
	];

	protected static $enum = [
		'status'	=> [
			'wait'	=> 'wait',
			'sent'	=> 'sent',
			'error'	=> 'error',
		],
	];

	protected static $columns = [
		'id'		=> ['sorted'=>true, 'className'=>'w50 a-right'],
		'created'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_str', 'className'=>'w150'],
		'from_mail'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ellipsis', 'className'=>'w200'],
		'to_mail'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ellipsis', 'className'=>'w200'],
		'subject'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ellipsis'],
		'status'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_enum', 'className'=>'w150'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default' => [
			'id'		=> ['type'=>'int'],
			'to_mail'	=> ['type'=>'like'],
			'subject'	=> ['type'=>'like'],
			'body'		=> ['type'=>'like'],
			'status'	=> ['type'=>'enum'],
		]
	];
	static $record_name_field = 'subject';

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		if(isset($filters['status_all']) && $filters['status_all']!='all')
			$res['status'] = ['f'=>static::$table_alias.'.status', 'o'=>'=', 'v'=>$filters['status_all']];

		return $res;
	}

	function save($save_data = [], $options = []) {
		if (!$this->id)
			$save_data['created'] = time();
		return parent::save($save_data, $options);
	}

	function send(){
		if($this->status!=='wait')
			return;

//		if(!isset($this->data['from_mail'])) {
//			$this->data['from_mail'] = \setting_db::get_setting('admin_email');
//			$this->data['from_name'] = \setting_db::get_setting('admin_name');
//		}

		$this->status = $GLOBALS['lib']->mail->real_send($this->data) ? 'sent' : 'error';
		$this->error = $GLOBALS['lib']->mail->get_err_msg();
		$this->save();
	}

	protected static function post_process(&$list, $options=[]){
		foreach($list as &$r) {
			$r['created_str']	= $GLOBALS['lib']->date_time->to_format($r['created'], true);
			$r['subject_str']	= static::shorten_str($r['subject']);
		}
	}

	function access($action) {
		if($GLOBALS['user']['role']=='root')
			return true;
		if($GLOBALS['user']['role']=='admin')
			return true;
//		if(in_array($GLOBALS['user']['role'], ['user', 'guest']) && $action=='view')
//			return true;
		return false;
	}

}