function mail_class() {
	table_call_class.call(this)

	this.data.title_icon = 'envelope-o'
	this.list_url	= 'mail/mail/list_ajax'
	this.edit_url	= 'mail/mail/info_ajax'
	this.edit_field_title_width = 100
	this.data.call_width = 1200

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, el) {
		td_formatter_icons_parent.call(this, field_name, record, el)

		el.children[0].children[0].attributes.title = this.lang('info')
		el.children[0].children[0].className = ['btn', 'icon', 'file-text-o']

		el.children[0].children.splice(1);
	}

	//let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return mail_action_icons.call(this, 'mail')
	}

}

function mail_list_show(data, event) {
	if (event) data.call_btn = event.target
	new mail_class().show(data)
}

function mail_action_icons(current=false) {
	return [
		current==='mail'?null:{
			tagName: 'a',
			className: ['btn', 'icon', 'envelope-o'],
			attributes: {
				href: script_url + 'mail/mail',
				title: this.lang('email_list')
			},
			events: {link_click: mail_list_show.bind(null, {
					title: this.lang('email_list'),
				})}
		},
		current==='mail_settings'?null:{
			tagName: 'a',
			className: ['btn', 'icon', 'cog'],
			attributes: {
				href: script_url + 'mail/settings',
				title: this.lang('settings')
			},
			events: {link_click: mail_settings_list_show.bind(null, {
				title: this.lang('email_list')+' - '+this.lang('settings', true),
			})}
		},
		current==='subscriber'?null:{
			tagName: 'a',
			className: ['btn', 'icon', 'users'],
			attributes: {
				href: script_url + 'mail/subscriber',
				title: this.lang('subscribers')
			},
			events: {link_click: subscriber_list_show.bind(null, {
					title: this.lang('email_list')+' - '+this.lang('subscribers', true),
				})}
		},
		current==='mail_template'?null:{
			tagName: 'a',
			className: ['btn', 'icon', 'envelope-open-o'],
			attributes: {
				href: script_url + 'mail/mail_template',
				title: this.lang('mail_templates')
			},
			events: {link_click: mail_template_list_show.bind(null, {
					title: this.lang('mail_templates', true),
				})}
		},
	]
}