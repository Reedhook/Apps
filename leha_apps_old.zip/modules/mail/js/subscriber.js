function subscriber_class() {
	table_call_class.call(this)

	this.data.title_icon = 'users'
	this.list_url	= 'mail/subscriber/list_ajax'
	this.edit_url	= 'mail/subscriber/edit_ajax'
	this.del_url	= 'mail/subscriber/delete_ajax'
	this.edit_field_url= 'mail/subscriber/edit_field_ajax'

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return create_action_icons_parent.call(this).concat(mail_action_icons.call(this, 'subscriber'))
	}
}

function subscriber_list_show(data, event) {
	if (event) data.call_btn = event.target
	new subscriber_class().show(data)
}
