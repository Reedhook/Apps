function mail_template_class() {
	table_call_class.call(this)

	this.data.title_icon = 'envelope-open-o'
	this.list_url	= 'mail/mail_template/list_ajax'
	this.edit_url	= 'mail/mail_template/edit_ajax'
	this.del_url	= 'mail/mail_template/delete_ajax'

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return create_action_icons_parent.call(this).concat(mail_action_icons.call(this, 'mail_template'))
	}
}

function mail_template_list_show(data, event) {
	if (event) data.call_btn = event.target
	new mail_template_class().show(data)
}
