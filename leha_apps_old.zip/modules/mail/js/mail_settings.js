function mail_settings_class() {
	settings_class.call(this);

	this.list_url = 'mail/settings/list_ajax'
	this.edit_url = 'mail/settings/edit_ajax'

	this.create_action_icons = function () {
		return mail_action_icons.call(this, 'mail_settings')
	}
}
function mail_settings_list_show(data, event) {
	new mail_settings_class().show(data)
}
