<?php
namespace mail;

class subscriber_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin'];

	function start(){
		require 'modules/mail/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('subscribers'));
		$GLOBALS['lib']->smarty->assign('js_class', 'subscriber_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];

		list($pagination, $records) = subscriber_db::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
				], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> subscriber_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=> '\\mail\\subscriber_db', 'list'=>[
					'subscriber', 'settings', 'email_list', 'subscribers', 'mail_templates'
				]]),
				'filters_model'=> subscriber_db::get_filters(),
//				'filters_ref_name' => mail_db::get_filters_ref_name($pagination['filters']),
			]),
		]);
	}

	function edit_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new subscriber_db($id);
		if(!$obj->access('edit'))
			no_access();

		$field_list = subscriber_db::get_field_list();

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if ($action=='save') {
			$data = $_REQUEST['data'];
			$err = $obj->validate($data);
			if(empty($err))
				$obj->save($data);
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;
		}

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'subscriber',
				'lang'				=> \output::lang_prepare(['model_name'=> '\\mail\\subscriber_db', 'edit'=>true, 'list'=>['subscriber']]),
//				'enum'				=> mail_db::get_enum(),

//				'field_localisation'=> mail_db::get_localisation_fields(),
//				'data_localisation'	=> $obj->get_localisation(),
//				'lang_list'			=> $GLOBALS['lib']->lang->list,
//				'lang_cur'			=> $GLOBALS['lib']->lang->value,
			],
		]);
	}

	function delete_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new subscriber_db($id);
		if(!$obj->access('edit'))
			no_access();

		$obj->delete();

		\output::ajax([
			'success'	=> true,
		]);
	}

	function edit_field_ajax() {
		$success = false;
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			no_access();

		$fields = ['is_active'];

		$field_name	= isset($_REQUEST['field_name']) ? $_REQUEST['field_name'] : false;
		$item_id	= isset($_REQUEST['item_id']) ? intval($_REQUEST['item_id']) : -1;
		$value		= isset($_REQUEST['value']) ? $_REQUEST['value'] : false;

		if (in_array($field_name, $fields)) {
			$obj = new subscriber_db($item_id);
			$obj->save([
				$field_name => $value
			]);
			$success = true;
		}

		\output::ajax([
			'success'	=> $success,
		]);
	}

}