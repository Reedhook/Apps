<?php
namespace mail;
require_once 'modules/core/controller/settings_controller.php';

class settings_controller extends \settings_controller {
	static $model	= '\\mail\\setting_db';

	function start() {
		require 'modules/mail/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('email_list').' - '.lang('settings', false));
		$GLOBALS['lib']->smarty->assign('js_class', 'mail_settings_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		setting_db::$setting_map['mail_cron']['notification'] = '*/1 * * * *	cd '.getcwd().' && php index.php mail cron send 2>&1';
		parent::list_ajax();
	}

	function list_lang() {
		return array_merge(parent::list_lang(), [
			'email_list', 'subscribers', 'mail_templates',
		]);
	}
}
