<?php
\output::add_files([
	'mail/js/mail.js',
	'core/js/settings.js',
	'mail/js/mail_settings.js',
	'mail/js/mail_template.js',
	'mail/js/subscriber.js',
]);
