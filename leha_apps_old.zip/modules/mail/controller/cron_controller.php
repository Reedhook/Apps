<?php
namespace mail;

class cron_controller extends \controller {
	function send () {
		$cron = \cron\cron_db::begin('mail_cron_send', 600);
		if ($cron===false)
			return;

		mail_db::get_list(['filters'=>['status'=>'wait'], 'no_answer'=>true, 'row_function'=>function($r){
			$o = new mail_db();
			$o->construct_by_data($r);
			$o->save([
				'status'	=> $GLOBALS['lib']->mail->real_send($r) ? 'sent' : 'error',
				'error'		=> $GLOBALS['lib']->mail->get_err_msg(),
			]);
			echo $o->id."\t".$o->status."\n";
		}]);

		$cron->finish();
	}
}
