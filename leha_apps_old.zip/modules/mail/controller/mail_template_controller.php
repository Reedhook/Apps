<?php
namespace mail;

class mail_template_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin'];

	function start(){
		require 'modules/mail/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('mail_templates'));
		$GLOBALS['lib']->smarty->assign('js_class', 'mail_template_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];

		list($pagination, $records) = mail_template_db::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> mail_template_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=> '\\mail\\mail_template_db', 'list'=>[
					'mail_template', 'settings', 'email_list', 'subscribers', 'mail_templates'
				]]),
				'filters_model'=> mail_template_db::get_filters(),
//				'filters_ref_name' => mail_db::get_filters_ref_name($pagination['filters']),
			]),
		]);
	}

	function edit_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new mail_template_db($id);
		if(!$obj->access('edit'))
			no_access();

		$field_list = mail_template_db::get_field_list();

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if ($action=='save') {
			$data = $_REQUEST['data'];
			$err = $obj->validate($data);
			if(empty($err))
				$obj->save($data);
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;
		}

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'mail_template',
				'lang'				=> \output::lang_prepare(['model_name'=> '\\mail\\mail_template_db', 'edit'=>true, 'list'=>['mail_template']]),
//				'enum'				=> mail_db::get_enum(),

//				'field_localisation'=> mail_db::get_localisation_fields(),
//				'data_localisation'	=> $obj->get_localisation(),
//				'lang_list'			=> $GLOBALS['lib']->lang->list,
//				'lang_cur'			=> $GLOBALS['lib']->lang->value,
			],
		]);
	}

	function delete_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new mail_template_db($id);
		if(!$obj->access('edit'))
			no_access();

		$obj->delete();

		\output::ajax([
			'success'	=> true,
		]);
	}
}