<?php
namespace mail;

class mail_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {
		require 'modules/mail/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('email_list'));
		$GLOBALS['lib']->smarty->assign('js_class', 'mail_class');
		\output::smarty('modules/core/view/manager.tpl');
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];
		list($pagination, $records) = mail_db::get_page($pagination);

		foreach($records as $r)
			unset($r['body']);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
				], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> mail_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=>'\\mail\\mail_db', 'list'=>[
					'info', 'settings', 'email_list', 'subscribers', 'mail_templates'
				]]),
				'filters_model'	=> mail_db::get_filters(),
				'enum'		=> mail_db::get_enum(),
			])
		]);
	}

	function info_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : -1;
		$obj = new mail_db($id);
		if(!$obj->access('view'))
			throw new Exception('no access');

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> mail_db::get_field_list(),
				'form_view_only'	=> true,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'email',
				'lang'				=> \output::lang_prepare(['model_name'=>'\\mail\\mail_db', 'list'=>['email', 'close']]),
				'enum'				=> mail_db::get_enum(),
//				'json_map'			=> mail_db::get_json_map()
			],
		]);
	}
}
