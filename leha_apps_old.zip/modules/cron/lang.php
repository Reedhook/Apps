<?php
$GLOBALS['lib']->lang->add([
	'en' => [
		'cron' => 'cron',
		'cron_list' => 'cron_list',
		'last_start' => 'last start',
		'last_work' => 'duration',
	],
	'ru' => [
		'cron' => 'cron',
		'cron_list' => 'cron`ы',
		'last_start' => 'запуск',
		'last_work' => 'продолжительность',
	],
]);
