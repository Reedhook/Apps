<?php
namespace cron;

class cron_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];
	static $model = '\\cron\\cron_db';

	function edit_ajax() {
		$localisation_fl = in_array('_localisation_db', class_parents(static::$model));
		list($module_name, $model_name) = static::parse_model();

		$item_id = empty($_REQUEST['item_id']) ? null : $_REQUEST['item_id'];
		$obj = new static::$model($item_id);
		if (!$obj->access('edit'))
			no_access();

		$field_list = (static::$model)::get_field_list();
		$field_list['last_start']['type'] = 'datetime';
		$field_list['last_work']['type'] = 'time';

		$data = empty($_REQUEST['data']) ? [] : array_intersect_key($_REQUEST['data'], $field_list);

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : false;
		if ($action==='save') {
			$data['last_start'] = $GLOBALS['lib']->date_time->to_stamp($data['last_start']);
			$data['last_work'] = $GLOBALS['lib']->date_time->sql_time_to_sec($GLOBALS['lib']->date_time->to_sql_time($data['last_work']));

			$err = $obj->validate($data);

			if(empty($err))
				$obj->save($data);

			\output::ajax([
				'success'	=> count($err)===0,
				'err'		=> $err,
			]);
			return;
		} else {
			if (!$item_id)
				$obj->set_data($data);
			$data = $obj->get_data(['get_ref_name'=>'true']);
			$data['last_start'] = $GLOBALS['lib']->date_time->to_format($data['last_start'], true);
			$data['last_work'] = $GLOBALS['lib']->date_time->sec_to_sql_time($data['last_work']);
		}

		\output::ajax([
			'edit_data'	=> array_merge([
				'field_list'		=> $field_list,
				'data'				=> $data,
				'item_name'			=> $model_name,
				'lang'				=> \output::lang_prepare(['model_name'=>static::$model]),
				'enum'				=> (static::$model)::get_enum(),
				'json_map'			=> (static::$model)::get_json_map(),
			],
				$localisation_fl ? [
					'field_localisation'=> (static::$model)::get_localisation_fields(),
					'lang_list'			=> $GLOBALS['lib']->lang->list,
					'lang_cur'			=> $GLOBALS['lib']->lang->value,
					'data_localisation'	=> $obj->get_localisation(),
				] : []),
		]);
	}
}