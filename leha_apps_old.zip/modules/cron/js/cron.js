function cron_class() {
	table_call_class.call(this);

	this.edit_url	= 'cron/cron/edit_ajax';
	this.del_url	= 'cron/cron/delete_ajax';
	this.list_url	= 'cron/cron/list_ajax';

	this.td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, td_structure) {
		this.td_formatter_icons_parent.call(this, field_name, record, td_structure)
		td_structure.children[0].children[1] = null
	}
	this.create_action_icons = function() {
		return []
	}
}
function cron_list_show(data, event) {
	if (event) data.call_btn = event.target
	new cron_class().show(data)
}
