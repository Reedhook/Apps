<?php
/*namespace cron;

class dict_db extends \dict_db {
	protected static $log_changes = false;
}
*/