<?php
namespace cron;

class cron_db extends \table_db {
	protected static $log_changes = false;
	protected static $table_name = 'cron';

	protected static $field_list = [
		'name'			=> ['type'=>'str', 'title'=>'title'],	// название крона
		'active'		=> ['type'=>'bool'],					// флаг, что крон сейчас выполняется
		'last_start'	=> ['type'=>'int'],						// время последнего запуска
		'last_work'		=> ['type'=>'int'],						// время последнего выполнения (сек)
	];
	protected static $columns = [
		'id'			=> ['sorted'=> true, 'className'=>'w50 a-right'],
		'name'			=> ['sorted'=> true, 'js_formatter'=>'td_formatter_ellipsis'],
		'last_start'	=> ['sorted'=> true, 'js_formatter'=>'td_formatter_str', 'className'=>'w200 a-right'],
		'last_work'		=> ['sorted'=> true, 'js_formatter'=>'td_formatter_str', 'className'=>'w200 a-right'],
		'active'		=> ['sorted'=> true, 'js_formatter'=>'td_formatter_yes_no', 'className'=>'w100 a-right'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'last_start', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	public static function begin($cron_name, $reset_time=3600) {
		$obj = new static();
		$list = static::get_list(['filters'=>['name'=>$cron_name]]);
		if (count($list)>0) {
			$obj->construct_by_data($list[0]);
		} else {
			$obj->set_data(['name'=>$cron_name]);
		}

		if ($obj->active && $obj->last_start+$reset_time>time())
			return false;

		$obj->save([
			'last_start'	=> time(),
			'active'		=> true,
		]);

		echo "\n-- ".gmdate("Y-m-d H:i:s")." -- {$cron_name} --\n";
		return $obj;
	}

	public function finish() {
		$this->save([
			'active'		=> false,
			'last_work'		=> time() - $this->last_start,
		]);
	}

	static function post_process(&$list, $options = []) {
		foreach ($list as $k=>$r) {
			$list[$k]['last_start_str'] = $GLOBALS['lib']->date_time->to_format($list[$k]['last_start'], true);
			$list[$k]['last_work_str'] = $GLOBALS['lib']->date_time->sec_to_sql_time($list[$k]['last_work']);
		}
	}
}
