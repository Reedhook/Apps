<?php
$GLOBALS['lib']->lang->add([
'en'	=> [
	'callback'			=> 'callback',
	'question'			=> 'question',
	'answer'			=> 'answer',
//	'send_answer'		=> 'Send answer',
	'question_accepted'	=> 'question accepted',
	],
'ru'	=> [
	'callback'			=> 'обратная связь',
	'question'			=> 'вопрос',
	'answer'			=> 'ответ',
//	'send_answer'		=> 'Послать ответ',
	'question_accepted'	=> 'вопрос принят',
	],
]);
