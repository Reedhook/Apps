<?php
namespace callback;

class callback_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {
		\output::add_files(['callback/js/callback.js',]);
		$GLOBALS['lib']->smarty->assign('title', lang('callback'));
		$GLOBALS['lib']->smarty->assign('js_class', 'callback_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];
		list($pagination, $records) = callback_db::get_page($pagination);

		foreach($records as $r)
			unset($r['question'], $r['answer']);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
				],
				empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> callback_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=>'\\callback\\callback_db', 'list'=>['published', 'unpublished']]),
				'filters_model'	=> callback_db::get_filters(),
				'enum'			=> callback_db::get_enum(),
			]),
		]);
	}

	function edit_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new callback_db($item_id);
		if(!$obj->access('edit'))
			throw new Exception('no access');

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if($action=='save') {
			$data = $_REQUEST['data'];
			$err= $obj->validate($data);

			if(empty($err)) {
				$obj->save($data);
/*				if(!empty($_REQUEST['send_answer']))
					$GLOBALS['lib']->mail->send([
						'to_mail'	=> $obj->email,
						'subject'	=> \setting_db::get_setting('seo_title').' '.$GLOBALS['lang']['answer'],
						'body'		=> str_replace(['#site_url#', '#question#', '#answer#'], [$GLOBALS['conf']['site']['site_url'], $o->question, $o->answer], $GLOBALS['lang']['answer_mail']),
					]);
*/				$success = true;
			}
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;
		}

		\output::ajax([
			'recaptcha_key'		=> empty($item_id) && \site\setting_db::get_setting('recaptcha_use') ? \site\setting_db::get_setting('recaptcha_key') : false,
			'edit_data'	=> [
				'field_list'		=> callback_db::get_field_list(),
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'callback',
				'lang'				=> \output::lang_prepare(['model_name'=>'\\callback\\callback_db', 'list'=>['callback']]),
				'enum'				=> callback_db::get_enum(),
//				'json_map'			=> mail_db::get_json_map()
			],
		]);
	}

	function delete_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : -1;
		$obj = new callback_db($id);
		if(!$obj->access('edit'))
			throw new Exception('no access');

		$obj->delete();

		\output::ajax([
			'success'	=> true,
		]);
	}
}