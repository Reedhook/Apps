<?php
namespace callback;

class site_controller extends \controller {

	function start() {
		\output::add_files([
			'callback/js/callback_send.js',
		]);

		$GLOBALS['lib']->smarty->assign('registration_type', \site\setting_db::get_setting('registration_type'));
		if ($GLOBALS['user']['id']>0)
			$GLOBALS['lib']->smarty->assign('user_data', $GLOBALS['user']);

		\output::smarty('modules/callback/view/site.tpl');
	}

	function send_ajax() {
		$data = array_intersect_key(empty($_REQUEST['data']) ? [] : $_REQUEST['data'], ['name'=>true, 'email'=>true, 'phone'=>true, 'question'=>true]);
		$obj = new callback_db();
		$err = $obj->validate($data);

		$this->check_recaptcha($err);

		if (empty($err))
			$obj->save($data);

		\output::ajax([
			'success'	=> count($err)===0,
			'msg'		=> count($err)===0 ? lang('question_accepted') : false,
			'err'		=> $err,
		]);
	}
}