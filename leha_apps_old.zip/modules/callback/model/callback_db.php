<?php
namespace callback;

class callback_db extends \table_db{
	protected static $table_name = 'callback';
	protected static $table_alias = 'c';
	protected static $field_list = [
		'created'		=> ['type'=>'datetime'],
		'user_id'		=> ['type'=>'int', 'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
		'name'			=> ['type'=>'str'],
		'email'			=> ['type'=>'str'],
		'phone'			=> ['type'=>'str'],
		'question'		=> ['type'=>'text',	'validator'=>'str'],
		'answer'		=> ['type'=>'text'],
		'published'		=> ['type'=>'bool'],
	];
	protected static $columns = [
		'id'			=> ['sorted'=>true, 'styles'=>['width'=>'50px'], 'className'=>'a-right w50'],
		'created'		=> ['sorted'=>true, 'js_formatter'=>'td_formatter_str', 'className'=>'w150'],
		'email'			=> ['sorted'=>true, 'className'=>'w200'],
//		'phone'			=> ['sorted'=>true],
		'question'		=> ['js_formatter'=>'td_formatter_str'],
//		'answer'		=> ['js_formatter'=>'td_formatter_str'],
		'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
	protected static $pagination = ['page_size'=>5, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50]];

	protected static $filters = [
		'default'	=> [
			'email'			=> ['type'=>'like'],
			'subject'		=> ['type'=>'like',],
			'question'		=> ['type'=>'like'],
		],
	];

	function save($save_data=[], $options=[]) {
		static::set_data($save_data);
		$save_data = [];
		if (!$this->id) {
			$save_data['created'] = time();
			if ($GLOBALS['user']['id']>0)
				$save_data['user_id'] = $GLOBALS['user']['id'];
		}

		parent::save($save_data, $options);
	}

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		$fields_like = ['email', 'question', 'answer'];
		foreach($fields_like as $f)
			if(!empty($filters[$f.'_like']))
					$res[$f] = ['f'=>static::$table_alias.'.'.$f, 'o'=>'like', 'v'=>$filters[$f.'_like']];

		return $res;
	}

	protected static function post_process(&$list, $options=[]){
		foreach($list as &$r) {
			$r['created_str']	= !empty($r['created']) && $r['created']!='0000-00-00 00:00:00' ? $GLOBALS['lib']->date_time->to_format($r['created'], true) : '';
			$r['question_str']	= static::shorten_str($r['question']);
			$r['answer_str']	= static::shorten_str($r['answer']);
		}
	}

	function access($action) {
		if(!$this->id)
			return true;

		if(in_array($GLOBALS['user']['role'], ['root', 'admin']))
			return true;

		return false;
	}

//	protected function prepare_changes(){
//		if (empty($this->data_old['id']))
//			$this->send_subscribers();
//		parent::prepare_changes();
//	}

	function send_subscribers() {
//		$subscribers_list = \table_db::$db->query("SELECT * FROM es_subscribers WHERE is_active=1");
//		$template = \table_db::$db->query("SELECT * FROM mtemplates WHERE pcode='ES_CALLBACK_MARKET_MESSAGE'")[0];
		$subscribers_list = \mail\subscriber_db::get_list(['filters'=>['is_active'=>true]]);
		$template = \mail\mail_template_db::get_list(['filters'=>['code'=>'ES_CALLBACK_MARKET_MESSAGE']])[0];

		$body = str_replace(
			['[NAME]', '[EMAIL]', '[PHONE]', '[MESSAGE]'],
			[$this->name, $this->email, $this->phone, $this->question],
			$template['html']
		);

		$res = false;
		foreach ($subscribers_list as $subscriber)
			$res = $GLOBALS['lib']->mail->send([
				'to_mail'	=> $subscriber['email'],
				'subject'	=> $template['subject'],
				'body'		=> $body,
			]) || $res;
		return $res;
	}

}
