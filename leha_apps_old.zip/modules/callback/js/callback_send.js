async function callback_send(form) {
	form.wait()

	let token = typeof(recaptcha_key)!=='undefined' && recaptcha_key ? await get_reCAPTCHAv3(recaptcha_key, 'login') : false,
		response_data = await yozh_fetch({
		url: script_url + 'callback/site/send_ajax',
		data: Object.assign({data: get_form_data(form)}, {recaptcha_token: token}),
	})

	form_show_errors(form, response_data)
	if (response_data.success) {
		form.reset()
		yozh_notify({text: response_data.msg})
	}

	form.wait(false)
}