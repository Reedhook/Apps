function callback_class() {
	table_call_class.call(this)

	this.data.title_icon = 'phone'
	this.edit_url	= 'callback/callback/edit_ajax'
	this.del_url	= 'callback/callback/delete_ajax'
	this.list_url	= 'callback/callback/list_ajax'
	this.publish_url= 'callback/callback/publish_ajax'

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, el) {
		td_formatter_icons_parent.call(this, field_name, record, el)

		el.children[0].children.push(
/*			{
				properties: {title: this.lng(to_bool(record.published) ? 'published' : 'unpublished')},
				className: to_bool(record.published) ? 'btn icon flag' : 'btn icon flag red',
				events: {click: this.publish.bind(this, record.id)},
			)
*/		)
	}


	this.publish = function(id) {
		yozh_ajax({
			url: script_url + this.publish_url,
			data: {item_id: id},
			on_success_fn: function (response_data, textStatus) {
				if (response_data.success) {
					this.list({});
				} else {
					alert(response_data.err_msg)
				}
			}.bind(this)
		});
	}

	this.list_common = function(data) {
		let //t = this,
			res = {};
		res.pagination = get_form_data('callback_pagination');
		for(let i in res.pagination)
			if(typeof(data[i])!='undefined')
				res.pagination[i] = data[i];
		res.pagination.filters = get_form_data('callback_filters');

		yozh_ajax({
			url: script_url + 'callback/manager/list_ajax',
			data: res,
			on_success_fn: function (return_data, textStatus) {
				if (return_data.success) {
					document.getElementById('callback_list').innerHTML = return_data.html;
				} else {
				}
			}
		});
	}
}

function callback_list_show(data, event) {
	if (event) data.call_btn = event.target
	new callback_class().show(data)
}
