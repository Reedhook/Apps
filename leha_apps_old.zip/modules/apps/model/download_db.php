<?php
namespace apps;

class download_db extends \table_db {
	protected static $table_name = 'apps_download';

	protected static $field_list = [
		'release_id'	=> ['type'=>'int', 'ref'=>'\\apps\\release_db', 'js_call'=>'release_list_show'],
		'time'			=> ['type'=>'datetime'],
		'ip'			=> ['type'=>'str'],
		'user_agent'	=> ['type'=>'str'],
	];

	static $record_name_field = 'time';
	static function record_get_name($record) {
		return "[{$record['id']}] ".$GLOBALS['lib']->date_time->to_format($record['time']);
	}

	protected static $columns = [
		'id'			=> ['sorted'=>true, 'className'=>'w50 a-right'],
		'project_id'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ref', 'js_call'=>'project_list_show'],
		'release_id'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ref', 'js_call'=>'release_list_show', 'className'=>'w200'],
		'time'			=> ['sorted'=>true, 'js_formatter'=>'td_formatter_str', 'className'=>'w180 a-right'],
		'ip'			=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ellipsis', 'className'=>'w120 a-right'],
		'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
			'project_id'	=> ['type'=>'ref', 'ref'=>'\\apps\\project_db', 'js_call'=>'project_list_show'],
			'release_id'	=> ['type'=>'ref', 'ref'=>'\\apps\\release_db', 'js_call'=>'release_list_show'],
			'ip'			=> ['type'=>'like'],
			'user_agent'	=> ['type'=>'like'],
			'time_min'		=> ['type'=>'date_group_from',	'date_group'=>'time', 'clear'=>true, 'title'=>['time', 'from']],
			'time_max'		=> ['type'=>'date_group_to',	'date_group'=>'time', 'clear'=>true, 'title'=>['time', 'to']],
			'day'			=> ['type'=>'date_group_day',	'date_group'=>'time', 'slim'=>true],
			'month'			=> ['type'=>'date_group_month',	'date_group'=>'time', 'slim'=>true],
			'year'			=> ['type'=>'date_group_year',	'date_group'=>'time', 'slim'=>true],
		]
	];

	protected static function post_process(&$list, $options = []) {
		$release_list = get_ref_list($list, 'release_id', '\\apps\\release_db');

		$id_list = array_unique(array_diff(array_map('intval', array_column($release_list, 'project_id')), [0]));
		$project_list = empty($id_list) ? [] : project_db::get_list(['filters'=>['id'=>$id_list, 'constructor'=>true], 'key'=>'id']);

		foreach ($list as $k=>$r) {
			$list[$k]['release_id_str'] = isset($release_list[$r['release_id']]) ? release_db::record_get_name($release_list[$r['release_id']]) : $r['release_id'];

			$list[$k]['project_id'] = isset($release_list[$r['release_id']]) ? $release_list[$r['release_id']]['project_id'] : null;
			$list[$k]['project_id_str'] = isset($project_list[$list[$k]['project_id']]) ? project_db::record_get_name($project_list[$list[$k]['project_id']]) : null;

			$list[$k]['time_str'] = $GLOBALS['lib']->date_time->to_format($r['time'], true);
		}
	}
}