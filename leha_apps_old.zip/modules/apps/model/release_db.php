<?php
namespace apps;

class release_db extends \table_db {
	protected static $table_name = 'apps_release';

	protected static $field_list = [
		'project_id'	=> ['type'=>'int', 'ref'=>'\\apps\\project_db', 'js_call'=>'project_list_show', 'validator'=>'int_positive'],
		'file_id'		=> ['type'=>'int', 'ref'=>'\\file_db', 'js_call'=>'file_list_show', 'file_protected'=>true, 'validator'=>'int_positive'],

		'platform'		=> ['type'=>'enum'],
		'version'		=> ['type'=>'str'],
		'type'			=> ['type'=>'enum'],
		'description'	=> ['type'=>'text'],
		'public'		=> ['type'=>'bool'],
	];

	static $record_name_field = 'platform';
	static function record_get_name($record) {
		return "[{$record['id']}] {$record['platform']} {$record['version']}";
	}

	protected static $enum = [
		'platform'	=> [
			'win'		=> 'win',
			'xp'		=> 'win_xp',
			'linux'		=> 'linux',
			'ubuntu'	=> 'ubuntu',
			'android'	=> 'android',
			'ios'		=> 'ios',
		],
		'type'		=> [
			'dev'		=> 'developing',
			'pre'		=> 'prerelease',
			'stable'	=> 'stable',
		],
	];

	protected static $columns = [
		'id'		=> ['sorted'=>true, 'className'=>'w50 a-right'],
		'url'		=> ['sorted'=>true, 'js_formatter'=>'td_formatter_url'],
		'platform'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_enum', 'className'=>'w100'],
		'version'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_ellipsis', 'className'=>'w100'],
		'type'		=> ['sorted'=>true, 'js_formatter'=>'td_formatter_enum', 'className'=>'w100'],
		'public'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_edit_field_bool', 'className'=>'w100'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
			'project_id'	=> ['type'=>'ref', 'ref'=>'\\apps\\project_db', 'js_call'=>'project_list_show'],
			'platform'		=> ['type'=>'enum'],
			'version'		=> ['type'=>'like'],
			'type'			=> ['type'=>'enum'],
			'public'		=> ['type'=>'yes_no'],
		]
	];

	protected static function prepare_filters($filters) {
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			$filters['public'] = true;

		return parent::prepare_filters($filters);
	}

	protected static function post_process(&$list, $options = []) {
		$project_list = get_ref_list($list, 'project_id', '\\apps\\project_db');

		foreach ($list as $k=>$r) {

			$list[$k]['url'] = $GLOBALS['conf']['site']['site_url'].
				'download/'.
				($project_list[$r['project_id']]['download_code'] ?? '').'/'.
				$r['platform'].'/'.
				$r['type'].'/'
				.$r['version'].'/';
		}
	}
}