<?php
namespace apps;

class project_db extends \table_db {
	protected static $table_name = 'apps_project';

	protected static $field_list = [
		'title'			=> ['type'=>'str'],
		'description'	=> ['type'=>'text'],
		'download_code'	=> ['type'=>'str', 'description'=>'download_code_description'],
		'public'		=> ['type'=>'bool'],
	];

	static $record_name_field = 'title';

	protected static $columns = [
		'id'		=> ['sorted'=>true, 'className'=>'w50 a-right'],
		'title'		=> ['sorted'=>true],
		'public'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_edit_field_bool', 'className'=>'w100'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
			'title'			=> ['type'=>'like'],
			'description'	=> ['type'=>'like'],
			'public'		=> ['type'=>'yes_no'],
		]
	];

	protected static function prepare_filters($filters) {
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			$filters['public'] = true;

		return parent::prepare_filters($filters);
	}

}