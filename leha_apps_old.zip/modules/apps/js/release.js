function release_class() {
	table_call_class.call(this)

//	this.data.title_icon = 'envelope-open-o'
	this.list_url	= 'apps/release/list_ajax'
	this.edit_url	= 'apps/release/edit_ajax'
	this.del_url	= 'apps/release/delete_ajax'
	this.edit_field_url= 'apps/release/edit_field_ajax'

	this.record_name = function(record) {
		return '['+record.id+'] '+record.platform+' '+record.version
	}

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return this.admin_access ? create_action_icons_parent.call(this) : []
	}

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, td_structure) {
		if (this.admin_access)
			td_formatter_icons_parent.call(this, field_name, record, td_structure)
	}

	this.td_formatter_url = function(field_name, record, td_structure) {
		if (this.data.select_mode>0) {
			this.td_formatter_ellipsis(field_name, record, td_structure)
			return
		}

		delete td_structure.text
//		td_structure.className.push('.td_ellipsis')
		td_structure.children = [{
			className: ['td_ellipsis'],
			children: [{
				tagName: 'a',
				attributes: {
					href: record[field_name],
					target: '_blank',
				},
				className: ['ellipsis', 'w100p'],
				text: record[field_name],
			}],
		}]
	}
}

function release_list_show(data, event) {
	if (event) data.call_btn = event.target
	new release_class().show(data)
}
