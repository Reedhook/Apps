function download_class() {
	table_call_class.call(this)

//	this.data.title_icon = 'envelope-open-o'
	this.data.filter_title_width = 80

	this.list_url	= 'apps/download/list_ajax'
	this.edit_url	= 'apps/download/edit_ajax'

	this.record_name = function(record) {
		return '['+record.id+'] '+record.time_str
	}

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return this.admin_access ? create_action_icons_parent.call(this) : []
	}

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, td_structure) {
		if (this.admin_access)
			td_formatter_icons_parent.call(this, field_name, record, td_structure)
	}
}

function project_list_show(data, event) {
	if (event) data.call_btn = event.target
	new project_class().show(data)
}
