<?php
$GLOBALS['lib']->lang->add([
'en'	=> [
	'project'		=> 'project',
	'project_id'	=> 'project',
	'project_list'	=> 'projects',
	'public'		=> 'public',
	'download_code'	=> 'code',
	'download_code_description'=>'download code',

	'release'		=> 'release',
	'release_id'	=> 'release',
	'release_list'	=> 'releases',
	'platform'		=> 'platform',

	'version'		=> 'version',
	'win'			=> 'windows',
	'win_xp'		=> 'windows XP',
	'linux'			=> 'linux',
	'ubuntu'		=> 'ubuntu',
	'android'		=> 'android',
	'ios'			=> 'IOS',

	'type'			=> 'type',
	'developing'	=> 'developing',
	'prerelease'	=> 'prerelease',
	'stable'		=> 'stable',

	'download_id'	=> 'download',
	'download_list'	=> 'downloads',
	'time'			=> 'time',
	'user_agent'	=> 'user agent',
],
'ru'	=> [
	'project'		=> 'проект',
	'project_id'	=> 'проект',
	'project_list'	=> 'проекты',
	'public'		=> 'общий',
	'download_code'	=> 'код',
	'download_code_description'=>'код для скачивания',

	'release'		=> 'релиз',
	'release_id'	=> 'релиз',
	'release_list'	=> 'релизы',
	'platform'		=> 'платформа',

	'version'		=> 'версия',
	'win'			=> 'windows',
	'win_xp'		=> 'windows XP',
	'linux'			=> 'linux',
	'ubuntu'		=> 'ubuntu',
	'android'		=> 'android',
	'ios'			=> 'IOS',

	'type'			=> 'тип',
	'developing'	=> 'в разработке',
	'prerelease'	=> 'пред.выпуск',
	'stable'		=> 'стабильная',

	'download_id'	=> 'скачивание',
	'download_list'	=> 'скачивания',
	'time'			=> 'время',
	'user_agent'	=> 'агент',
],
]);