<?php
namespace apps;

class project_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin', 'user', 'guest'];
	static $model		= "\\apps\\project_db";

	protected function strat_add_files($module_name, $model_name) {
		require 'modules/apps/controller/js_files.php';
	}

	protected static $edit_field_list = ['public'];
}
