<?php
namespace apps;

class release_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin', 'user', 'guest'];
	static $model		= "\\apps\\release_db";

	protected function strat_add_files($module_name, $model_name) {
		require 'modules/apps/controller/js_files.php';
	}

	protected static $edit_field_list = ['public'];

	function download() {
		$object_code = array_shift($_REQUEST['request_line']) ?? '-';
		$platform = array_shift($_REQUEST['request_line']) ?? '-';
		$type = array_shift($_REQUEST['request_line']) ?? '-';
		$version = array_shift($_REQUEST['request_line']) ?? '-';

		$project = project_db::get_list(['filters'=>['object_code'=>$object_code]])[0] ?? false;
		if ($project) {
			if ($version==='latest') {
				$release = release_db::get_list([
					'filters'=>[
						'project_id'	=> $project['id'],
						'platform'		=> $platform,
						'type'			=> $type,
					], 'order'=>'version', 'dir'=>'desc',
				])[0] ?? false;
			} else {
				$release = release_db::get_list([
					'filters'=>[
						'project_id'	=> $project['id'],
						'platform'		=> $platform,
						'type'			=> $type,
					'version'		=> $version,
				]])[0] ?? false;
			}
			if ($release) {
				(new download_db())->save([
					'release_id'	=> $release['id'],
					'time'			=> time(),
					'ip'			=> \session_db::get_ip(),
					'user_agent'	=> $_SERVER['HTTP_USER_AGENT'] ?? '',
				]);

				$file = new \file_db($release['file_id']);
				$file->out();

				return;
			}
		}

		echo "Release doesn't exist or unpublished";
	}
}
