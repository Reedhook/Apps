<?php
namespace apps;

class download_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin'];
	static $model		= "\\apps\\download_db";

	protected function strat_add_files($module_name, $model_name) {
		require 'modules/apps/controller/js_files.php';
	}

	function list_lang() {
		return ['display', 'prev', 'next'];
	}

	function edit_ajax() {
		list($module_name, $model_name) = static::parse_model();

		$item_id = empty($_REQUEST['item_id']) ? null : $_REQUEST['item_id'];
		$obj = new static::$model($item_id);
		if (!$obj->access('edit'))
			no_access();

		$field_list = (static::$model)::get_field_list();
		$data = empty($_REQUEST['data']) ? [] : array_intersect_key($_REQUEST['data'], $field_list);

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : false;
		if ($action==='save') {
			$err = $obj->validate($data);

			if(empty($err))
				$obj->save($data);

			\output::ajax([
				'success'	=> count($err)===0,
				'err'		=> $err,
			]);
			return;
		} else {
			if (!$item_id)
				$obj->set_data($data);
		}

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> $model_name,
				'lang'				=> \output::lang_prepare(['model_name'=>static::$model]),
				'enum'				=> (static::$model)::get_enum(),
				'form_view_only'	=> true,
			],
		]);
	}

	protected static $edit_field_list = ['public'];
}
