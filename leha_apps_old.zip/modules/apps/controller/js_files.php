<?php
\output::add_files([
	'apps/js/project.js',
	'apps/js/release.js',
	'apps/js/download.js',
]);
