<?php
namespace news;
require_once 'modules/core/controller/settings_controller.php';

class settings_controller extends \settings_controller {
	static $model	= '\\news\\setting_db';

	function start() {
		require 'modules/news/controller/js_files.php';

		$GLOBALS['lib']->smarty->assign('title', lang('news_list').' - '.lang('settings', false));
		$GLOBALS['lib']->smarty->assign('js_class', 'news_settings_class');
		$GLOBALS['lib']->smarty->assign('pagination', ['filters'=>['module'=>'news']]);
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_lang() {
		return array_merge(parent::list_lang(), [
			'news_list', 'news_category_list'
		]);
	}
}
