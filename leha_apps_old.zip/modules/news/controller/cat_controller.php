<?php
namespace news;

class cat_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin', 'manager'];
	static $model = '\\news\\cat_db';

	function start() {
		require 'modules/news/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('news_category_list'));
		$GLOBALS['lib']->smarty->assign('js_class', 'news_cat_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$root_data = cat_db::get_root_data();
		$obj = new cat_db();
		$obj->construct_by_data($root_data);

		if (!$obj->access('view'))
			no_access('wrong tree_id');

		$pagination = [
			'filters' => [
				'tree_id'	=> $obj->tree_id,
			],
			'page_size'	=> 'all',
			'order'		=> 'left',
			'dir'		=> 'asc'
		];

//		$records = cat_db::get_list(['filters'=>['tree_id'=>$obj->tree_id], '']);
		list($pagination, $records) = cat_db::get_page($pagination);
		unset($pagination['page_size_values'], $pagination['buttons']);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> cat_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=>'\\news\\cat_db', 'list'=>[
					'news_category', 'move', 'into', 'before', 'after',
					'news_list', 'settings',
				]]),
//				'filters_model'	=> cat_db::get_filters(),
//				'filters_ref_name'=> cat_db::get_filters_ref_name($pagination['filters']),
				'enum'			=> cat_db::get_enum(),
			])
		]);
	}

	function edit_ajax() {
		$root = cat_db::get_root_data();

		$item_id = isset($_REQUEST['item_id']) ? intval($_REQUEST['item_id']) : null;
		$obj = new cat_db($item_id);
		if(!$obj->access('edit'))
			no_access();
		$parent_item_id = isset($_REQUEST['parent_item_id']) ? intval($_REQUEST['parent_item_id']) : null;
		if ($parent_item_id) {
			$parent_item = new cat_db($parent_item_id);
		} else {
			$parent_item = new cat_db();
			if ($obj->level>0)
				$parent_item->construct_by_data($obj->get_parent_item());
		}
		if(!$parent_item->access('edit'))
			no_access();

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if($action=='save') {
			$data = $_REQUEST['data'];
			$err = $obj->validate($data);
			$obj->set_data($data);
			if(empty($err)) {
				if($item_id>0) {
					$obj->save($data);
				} else {
					$obj = $parent_item->add_child_item($data);
				}

				\output::ajax([
					'success'		=> true,
					'data'			=> $obj->get_data(),
//					'parent_item_id'=> $item_id ? false : $parent_obj->id,
				]);
				return;
			} else {
				$GLOBALS['lib']->smarty->assign('err', $err);
			}
		}

		$field_list = cat_db::get_field_list();
		unset($field_list['node_id']);
		$field_list = array_merge(['parent_cat'=>['type'=>'str', 'view_only'=>true]], $field_list);

		$data = $obj->get_data(['get_ref_name'=>'true']);
		unset($data['tree_id'], $data['left'], $data['right'], $data['level'], $data['node_id']);
		$data['parent_cat'] = $parent_item->cat_name;

		\output::ajax([
			'edit_data'	=> [
				'hidden_field_list'	=> ['parent_item_id'=>$parent_item_id],
				'field_list'		=> $field_list,
				'data'				=> $data,
				'item_name'			=> 'news_category',
				'lang'				=> \output::lang_prepare(['model_name'=> '\\news\\cat_db', 'list'=>['news_category', 'parent_cat']]),
//				'enum'				=> cat_db::get_enum(),

//				'field_localisation'=> cat_db::get_localisation_fields(),
//				'data_localisation'	=> $obj->get_localisation(),
//				'lang_list'			=> $GLOBALS['lib']->lang->list,
//				'lang_cur'			=> $GLOBALS['lib']->lang->value,
			],
		]);
	}

	function delete_ajax() {
		$item_id = empty($_REQUEST['item_id']) ? -1 : $_REQUEST['item_id'];
		$obj = new cat_db($item_id);
		if(!$obj->access('edit'))
			no_access();

		$parent_id = $obj->get_parent_item()['id'];
		$obj->delete();

		\output::ajax([
			'success'		=> true,
			'parent_item_id'=> $parent_id,
		]);
	}

	function move_ajax() {
		$action			= $_REQUEST['action'];
		$item_id		= (int)$_REQUEST['item_id'];
		$target_id		= (int)$_REQUEST['target_id'];

		$obj = new cat_db($item_id);
		if(!$obj->access('edit'))
			no_access();

		$res = false;

		if ($action=='into')
			$res = $obj->move_item_to($target_id);

		if ($action=='before')
			$res = $obj->move_item_before($target_id);

		if ($action=='after') {
			$target_obj = new cat_db($target_id);
			$next_target = $target_obj->get_next_item();
			if ($next_target) {
				$res = $obj->move_item_before($next_target['id']);
			} else {
				$res = $obj->move_item_to($target_obj->get_parent_item()['id']);
			}
		}

		\output::ajax([
			'success'	=> $res===true,
			'msg'		=> $res===true ? '' : lang($res),
		]);
	}
}
