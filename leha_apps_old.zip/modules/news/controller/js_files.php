<?php
\output::add_files([
	'news/js/news.js',
	$GLOBALS['conf']['wysiwyg']['tinymce_url'],
	'news/js/news_cat.js',
	'core/js/settings.js',
	'news/js/news_settings.js',
]);
