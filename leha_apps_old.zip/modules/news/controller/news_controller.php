<?php
namespace news;

class news_controller extends \controller {
//	protected static $access_name = ['root', 'cron', 'admin', 'manager'];
	static $model = '\\news\\news_db';

	public function start() {
		require 'modules/news/controller/js_files.php';
		parent::start();
	}

	function list_lang() {
		return ['news_category_list', 'settings'];
	}

	function edit_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new news_db($item_id);
		if (!$obj->access('edit'))
			no_access();

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if($action=='save') {
			$data = $_REQUEST['data'];
			$err = $obj->validate($data);
			if (empty($err))
				$obj->save($data);

			\output::ajax([
				'success'		=> empty($err),
				'err'			=> $err,
			]);
			return;
		} else {
			if (!$item_id){
				$obj->set_data(['public_time'=>time()]);
			}
		}

		$field_list = news_db::get_field_list();
		$field_list['content']['type'] = 'tinymce';

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'news',
				'lang'				=> \output::lang_prepare(['model_name'=> '\\news\\news_db', 'list'=>['news', 'insert_img', 'select_img']]),
			],
		]);
	}
}