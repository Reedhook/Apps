<?php
namespace news;

class site_controller extends \controller {
	protected static $cat_id = -1;
	protected static $setting_cat = null;
	protected static $tree = null;
	protected static $cat_map = -1;

	function __construct() {
		parent::__construct();

		static::$cat_id = setting_db::get_setting('news_cat_id');
		static::$setting_cat = new cat_db(static::$cat_id, ['empty_if_not_exists'=>true]);
	}

	function start() {
		$news_id = setting_db::get_setting('main_news_id');

		if (empty($news_id)) {
			$cat_id_list = array_column(static::$setting_cat->get_branch(true), 'id');
			if ($cat_id_list) {
				$list = news_db::get_list(['filters'=>['published'=>1, 'cat_id'=>$cat_id_list], 'order'=>'public_time', 'dir'=>'DESC', 'limit'=>1]);
				$news_id = count($list)>0 ? $list[0]['id'] : false;
			}
		}

		if ($news_id)
			return $this->show_news($news_id);

		echo 'there are no news today';
	}

	function news() {
		$id = !empty($_REQUEST['request_line']) ? array_shift($_REQUEST['request_line']) : -1;
		$this->show_news($id);
	}

	function cat() {
		$cat_id = empty($_REQUEST['request_line'][0]) ? -1 : array_shift($_REQUEST['request_line']);
		$cat_o = new cat_db($cat_id);

		if ($this->cat_access($cat_o)) {

			$GLOBALS['lib']->smarty->assign('cat', $cat_o->get_data());
			$GLOBALS['lib']->smarty->assign('parent_path', $cat_o->get_item_path(static::$setting_cat->get_data()));
			$GLOBALS['lib']->smarty->assign('children_cat_list', $cat_o->get_branch(false));
			$GLOBALS['lib']->smarty->assign('news_list', news_db::get_list(['filters'=>['cat_id'=>$cat_o->id]]));
		}

		\output::smarty('modules/news/view/show_cat.tpl');
	}

	function page($news) {
		$GLOBALS['lib']->smarty->assign('data', $news->get_data());
		$GLOBALS['lib']->smarty->assign('seo_title', $news->title);
		$GLOBALS['lib']->smarty->assign('seo_description', $news->seo_description);
		$GLOBALS['lib']->smarty->assign('seo_keywords', $news->seo_keywords);

		\output::smarty('modules/news/view/page.tpl');
	}

	function page_rnd() {
		$cat_id = setting_db::get_setting('rnd_cat_id');
		if ($cat_id) {
			$cat = new cat_db($cat_id);
			$cat_id_list = array_column($cat->get_branch(true), 'id');
			$list = news_db::get_list(['filters'=>['cat_id'=>$cat_id_list], 'order'=>'rnd', 'limit'=>'1']);
			if (count($list)===1) {
				$news = new news_db();
				$news->construct_by_data($list[0]);
				return $this->page($news);
			}
		} else {
			throw new \Exception('empty setting - rnd_cat_id');
		}
		throw new \Exception('no news in rnd_cat');
	}

	function page_ajax($id=null) {
		$item_id = empty($_REQUEST['request_line']) ? (empty($_REQUEST['item_id']) ? -1 : $_REQUEST['item_id']) : array_shift($_REQUEST['request_line']) ;
		$news = new news_db($item_id);
		if ($news->published) {
			$data = $news->get_data();
		} else {
			$data = [
				'title'		=> 'not published',
				'content'	=> 'not published',
				'published'	=> false,
			];
		}
		\output::ajax([
			'success'	=> true,
			'news'		=> $data,
		]);
	}

	protected function show_news($id) {
		$news = new news_db($id);

		if(!$news->access('view'))
			no_access();

		$cat = new cat_db($news->cat_id);
		if ($this->cat_access($cat)) {
			$GLOBALS['lib']->smarty->assign('cat', $cat->get_data());
			$GLOBALS['lib']->smarty->assign('parent_path', $cat->get_item_path(static::$setting_cat->get_data()));
		}

		$GLOBALS['lib']->smarty->assign('news', $news->get_data());
		$GLOBALS['lib']->smarty->assign('seo_title', $news->title);
		$GLOBALS['lib']->smarty->assign('seo_description', $news->seo_description);
		$GLOBALS['lib']->smarty->assign('seo_keywords', $news->seo_keywords);

		\output::smarty('modules/news/view/show_news.tpl');
	}

	protected function cat_access($cat) {
		return
			$cat->access('view')
			&& $cat->tree_id === static::$setting_cat->tree_id
			&& $cat->left >= static::$setting_cat->left
			&& $cat->right <= static::$setting_cat->right;
	}
}