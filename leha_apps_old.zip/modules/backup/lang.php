<?php
$GLOBALS['lib']->lang->add([
'en'	=> [
	'backup'			=> 'backup',
	'backup_settings'	=> 'backup settings',
	'db_backup_mail'	=> 'backap send to email',
	'db_delete_after_sent'=>'delete file after send',
	'backup_db'			=> 'backup data base',
	'db_create'			=> 'create database backup',
	'db_backup_mail'	=> 'send db backup to:',
	'db_delete_after_sent'=>'delete db backup after sent',
	],
'ru'	=> [
	'backup'			=> 'резервирования данных',
	'backup_settings'	=> 'настройки резервирования данных',
	'db_backup_mail'	=> 'щтправлять копию на почту',
	'db_delete_after_sent'=>'удалять файл после отправки',
	'backup_db'			=> 'резервировани базы данных',
	'db_create'			=> 'создать резервнкю копию базы данных',
	'db_backup_mail'	=> 'Email для копии БД',
	'db_delete_after_sent'=>'удалять после отправки',
	],
]);
