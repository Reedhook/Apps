<?php
namespace backup;
require_once 'modules/core/controller/settings_controller.php';

class settings_controller extends \settings_controller {
	static $model	= '\\backup\\setting_db';

	function start() {
		require 'modules/backup/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('backup').' - '.lang('settings', false));
		$GLOBALS['lib']->smarty->assign('js_class', 'backup_settings_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_lang() {
		return array_merge(parent::list_lang(), [
			'backup'
		]);
	}

}