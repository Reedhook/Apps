<?php
\output::add_files([
	'backup/js/backup.js',
	'core/js/settings.js',
	'backup/js/backup_settings.js',
]);
