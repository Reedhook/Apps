<?php
namespace backup;

class backup_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {
		require 'modules/backup/controller/js_files.php';
		$GLOBALS['lib']->smarty->assign('title', lang('backup_db'));
		$GLOBALS['lib']->smarty->assign('js_class', 'backup_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];

		list($pagination, $records) = db_report_db::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'		=> $records,
				'pagination'	=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'		=> db_report_db::get_columns(),
				'lang'			=> \output::lang_prepare(['model_name'=>'\\backup\\db_report_db', 'list'=>['settings', 'prev', 'next', 'download', 'backup']]),
				'filters_model'	=> db_report_db::get_filters(),
				'enum'			=> db_report_db::get_enum(),
			]),
		]);
	}

	function create_ajax() {
		\output::ajax([
			'success'	=> db_report_db::create_db_dump(),
			'msg'		=> db_report_db::$err,
		]);
	}
	function delete_ajax() {
		$item_id_list = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : -1;

		if (!is_array($item_id_list))
			$item_id_list = [$item_id_list];

		foreach ($item_id_list as $item_id) {
			$obj = new db_report_db($item_id);
			if(!$obj->access('edit'))
				throw new \Exception('no access');
			$obj->delete();
		}

		\output::ajax([
			'success'	=> true,
		]);
	}
	function download() {
		$item_id = isset($_REQUEST['request_line'][0]) ? array_shift($_REQUEST['request_line']) : -1;

		$obj = new db_report_db($item_id);
		if(!$obj->access('edit'))
			throw new \Exception('no access');

		if ($obj->archive && file_exists($obj->archive)) {
			header('Content-type: application/zip');
			header("Content-Disposition: attachment; filename=\"".pathinfo($obj->archive)['basename']."\"");
			readfile($obj->archive);
			return;
		}
		echo "archive file doesn't exist";
	}

}