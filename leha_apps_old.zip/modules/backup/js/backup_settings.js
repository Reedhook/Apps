function backup_settings_class() {
	settings_class.call(this);

	this.list_url = 'backup/settings/list_ajax'
	this.edit_url = 'backup/settings/edit_ajax'

	this.create_action_icons = function() {
		return backup_action_icons.call(this, 'backup_settings')
	}
}
function backup_settings_list_show(data, event) {
	new backup_settings_class().show(data)
}
