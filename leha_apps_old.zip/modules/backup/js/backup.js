function backup_class() {
	table_call_class.call(this)

	this.data.title_icon = 'file-archive-o'
	this.data.filter_title_width = 80
	this.list_url	= 'backup/backup/list_ajax'
	this.edit_url	= 'backup/backup/create_ajax'
	this.del_url	= 'backup/backup/delete_ajax'
	this.download_url= 'backup/backup/download/'

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function (field_name, record, el) {
		td_formatter_icons_parent.call(this, field_name, record, el)

		el.children[0].children.splice(0, 2,
			record.archive ? {
				tagName: 'a',
				properties: {
					href: script_url + this.download_url + record.id,
					target: '_blank',
					title: this.lang('download'),
				},
				className: ['btn', 'icon', 'download'],
			} : null,
		)
	}

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function() {
		return create_action_icons_parent.call(this).concat(backup_action_icons.call(this, 'backup'))
	}

	this.edit = async function () {
		let btn_classList = this.structure.btn_create.el.classList
		if (btn_classList.contains('wait'))
			return

		btn_classList.remove('plus')
		btn_classList.add('wait')

		let response_data = await yozh_fetch({
			url: script_url + this.edit_url,
			data: {},
		})

		if (!response_data.success)
			yozh_notify({text: response_data.msg})

		btn_classList.remove('wait')
		btn_classList.add('plus')
		this.list()
	}
}
function backup_list_show(data, event){
	if (event) data.call_btn = event.target
	new backup_class().show(data)
}


function backup_action_icons(current=false) {
	return [
		current==='backup' ? null : {
			tagName: 'a',
			className: ['btn', 'icon', 'file-archive-o'],
			attributes: {
				href: script_url + 'backup/backup',
				title: this.lang('backup'),
			},
			events: {link_click: backup_list_show.bind(null, {title: this.lang('backup')})},
		},
		current==='backup_settings' ? null : {
			tagName: 'a',
			className: ['btn', 'icon', 'cog'],
			attributes: {
				href: script_url + 'backup/settings',
				title: this.lang('settings')
			},
			events: {link_click: backup_settings_list_show.bind(null, {
					title: this.lang('backup')+' - '+this.lang('settings', true),
				})}
		},
	]
}