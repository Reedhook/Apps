<?php
namespace backup;
use mysql_xdevapi\Exception;

class db_report_db extends \table_db{
	protected static $table_name = 'backup_db_report';
	protected static $field_list = [
		'created'		=> ['type'=>'datetime'],
		'size'			=> ['type'=>'int'],
		'email'			=> ['type'=>'str'],
		'archive'		=> ['type'=>'str'],
	];
	protected static $columns = [
		'id'		=> ['sorted'=>true, 'className'=>'a-right w50'],
		'created'	=> ['sorted'=>true, 'js_formatter'=>'td_formatter_str'],
		'size'		=> ['sorted'=>true, 'js_formatter'=>'td_formatter_str'],
		'email'		=> ['sorted'=>true],
		'archive'	=> ['sorted'=>true],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
			'created_min'	=> ['type'=>'date_group_from',	'date_group'=>'created', 'clear'=>true, 'title'=>['created', 'from']],
			'created_max'	=> ['type'=>'date_group_to',	'date_group'=>'created', 'clear'=>true, 'title'=>['created', 'to']],
			'month'			=> ['type'=>'date_group_month',	'date_group'=>'created', 'slim'=>true],
			'year'			=> ['type'=>'date_group_year',	'date_group'=>'created', 'slim'=>true],
		]
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	function save($save_data = [], $options = []) {
		if (!$this->id)
			$save_data['created'] = time();
		return parent::save($save_data, $options);
	}

	protected static function post_process(&$list, $options=[]){
		foreach($list as $k=>$r){
			$list[$k]['created_str']	= $GLOBALS['lib']->date_time->to_format($r['created'], true);
			$list[$k]['size_str']		= bytes_format($r['size']);
		}
	}

	static $err = '';
	static function create_db_dump() {
		set_time_limit(0);

		static::$err = '';
		$dir = $GLOBALS['conf']['files']['storage'].'dumps/';
		if (!$GLOBALS['lib']->file->create_dir($dir, ['htaccess'=>false]))
			throw new \Exception('create dir error: '.$dir);

		$file_name = $dir.date('Y-m-d_H-m-s').'.sql';

		$command = $GLOBALS['conf']['db']['type']==='mysqli' ?
			"mysqldump ".
				"--user={$GLOBALS['conf']['db']['user']} ".
				"--password={$GLOBALS['conf']['db']['pass']} ".
				"--host={$GLOBALS['conf']['db']['host']} ".
				"{$GLOBALS['conf']['db']['name']} > {$file_name}\n"
			: ($GLOBALS['conf']['db']['type']==='pg' ?
			"PGPASSWORD={$GLOBALS['conf']['db']['pass']}\n".
			"export PGPASSWORD\n".
			"pg_dump ".
				"-h {$GLOBALS['conf']['db']['host']} ".
				"-p {$GLOBALS['conf']['db']['port']} ".
				"-U {$GLOBALS['conf']['db']['user']} ".
				"-W ".
				"{$GLOBALS['conf']['db']['name']} > {$file_name}\n"
			."unset PGPASSWORD\n"
			: false);

		if ($command===false) {
			static::$err = 'unknown db type';
			return false;
		}
		exec($command);

		$file_name_zip = $file_name.".zip";
		exec("zip -j {$file_name_zip} {$file_name}");

		unlink($file_name);

		if ($file_name===false) {
			static::$err = 'create dump error';
			return false;
		}

		$settings = setting_db::get_settings();
		$o = new db_report_db();
		$o->size = filesize($file_name_zip);

		if (!empty($settings['db_backup_mail'])) {
			$send = $GLOBALS['lib']->mail->real_send([
				'from_mail'	=> $GLOBALS['conf']['mail']['smtp_username'],
				'to_mail'	=> $settings['db_backup_mail'],
				'subject'	=> $GLOBALS['conf']['site']['site_url'].' database dump',
				'body'		=> date("Y-m-d H:i:s"),
				'attachment'=> [['file'=>$file_name_zip, 'name'=>pathinfo($file_name_zip)['filename']]],
			]);
			$o->email = $send ? $settings['db_backup_mail'] : $o->email = $GLOBALS['lib']->mail->get_err_msg();
		}

		if ($settings['db_delete_after_sent']) {
			unlink($file_name_zip);
		} else {
			$o->archive = $file_name_zip;
			chmod($file_name_zip, 0777);
		}

		$o->save();

		return true;
	}

	function delete() {
		if (!empty($this->archive))
			@unlink($this->archive);
		return parent::delete();
	}
}