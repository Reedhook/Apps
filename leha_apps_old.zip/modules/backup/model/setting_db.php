<?php
namespace backup;

class setting_db extends \setting_db {
	protected static $setting_group = 'backup';
	protected static $setting_list = [];

	static $setting_map = [
//		'backup'				=> ['type'=>'group'],
		'db_backup_mail'		=> ['type'=>'str',		'value'=>''],
		'db_delete_after_sent'	=> ['type'=>'checkbox',	'value'=>0],
	];
}