<?php
require_once 'modules/core/system.php';
require_once 'lib/lib_manager.php';
require_once 'modules/core/controller/controller.php';

class controller_manager {

	static function start() {
		$GLOBALS['lib'] = new lib_manager();
		$GLOBALS['lib']->site_stat->begin();
		$GLOBALS['lib']->db->connect();
		$GLOBALS['lib']->session->start();
		$GLOBALS['lib']->auth->start();

		require_once 'modules/core/lang.php';
		require_once 'conf/prepare.php';

		static::module_execute_request();
	}

	static function module_execute_request() {
		$GLOBALS['request_url'] = implode('/', $_REQUEST['request_line']);
		if(isset($_REQUEST['module'])){
			$module = $_REQUEST['module'];
		} elseif(!empty($_REQUEST['request_line'][0])) {
			$module = array_shift($_REQUEST['request_line']);
		} else {
			static::prepare_default_module();
			$module = $_REQUEST['module'];
		}

		$seo_url = include 'conf/seo_url.php';
		if (isset($seo_url[$module])) {
			$map = $seo_url[$module];
			$module = $map[0];
			$controller = $map[1];
			$method = isset($map[2]) ? $map[2] : null;
			return static::module_execute($module, $controller, $method);
		}

		if (isset($_REQUEST['controller'])) {
			$controller = $_REQUEST['controller'];
		} elseif(!empty($_REQUEST['request_line'][0])) {
			$controller = array_shift($_REQUEST['request_line']);
		} else {
			$controller = null;
		}

		if (isset($_REQUEST['method'])){
			$method = $_REQUEST['method'];
		} elseif(!empty($_REQUEST['request_line'][0])) {
			$method = array_shift($_REQUEST['request_line']);
		} else {
			$method = null;
		}

		static::module_execute($module, $controller, $method);
	}

	static function module_execute($module, $controller, $method=null) {
		$controller_name = $controller.'_controller';
		$controller_file = "modules/{$module}/controller/{$controller_name}.php";
		if (!file_exists($controller_file)) {
			if (\news\news_db::start_seo_url($module))
				return;

			$GLOBALS['exception_err'] = [
				'err'	=> 'controller error',
				'msg'	=> "can\'t find controller: " . $controller_file,
			];
			throw new \Exception('custom exception');
		}

		require_once $controller_file;

		$namespace_class_name = "\\{$module}\\".$controller_name;
		$controller_name = class_exists($namespace_class_name) ? $namespace_class_name : $controller_name;

		if (!class_exists($controller_name)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'controller error',
				'msg'	=> 'unknown controller: '.$controller_name,
			];
			throw new \Exception('custom exception');
		}

		$controller_o = new $controller_name();

		if(empty($method))
			$method = $controller_o::$default_method;

		if(!method_exists($controller_o, $method)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'controller error',
				'msg'	=> "unknown method {$controller_name}::{$method}",
			];
			throw new \Exception('custom exception');
		}

//		$reflection = new ReflectionMethod($controller_o, $method);
//		if (!$reflection->isPublic()) {
		if (!is_callable([$controller_o, $method])) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'controller error',
//				'msg'	=> "used method is not public. {$controller_name}::{$method}",
				'msg'	=> "used method is not callable. {$controller_name}::{$method}",
			];
			throw new \Exception('custom exception');
		}

		$GLOBALS['controller'] = ['module'=>$module, 'controller'=>$controller, 'method'=>$method];
		return $controller_o->$method();
	}

	static function prepare_default_module($role=null) {
		$role = $role ? $role : $GLOBALS['user']['role'];
		$run = explode('/', $GLOBALS['conf']['site']['default_url_'.$role]);

//		$_REQUEST['request_line'] = $run;
		$_REQUEST['module']		= $run[0];
		$_REQUEST['controller']	= isset($run[1]) ? $run[1] : '';
		$_REQUEST['method']		= isset($run[2]) ? $run[2] : '';
	}
}
