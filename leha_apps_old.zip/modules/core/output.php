<?php
class output {
	static protected $file_list = [
		'core/js/yozh_tools.js',
		'core/js/system.js',
		'site/js/site.js',

		'core/js/table.js', 'core/js/form_editor.js',
		'core/js/change_log.js',
		'user/js/user.js', 'user/js/user_group.js', 'user/js/user_group_link.js',
		'core/js/file.js',
		'core/js/player.js',
	];
	static function file_list_out() {
		return array_map(function($file_name) {
			return [
				'src'	=> strpos($file_name, 'http')===0 ? $file_name : $GLOBALS['conf']['site']['script_url'].'modules/'.$file_name,
				'type'	=> substr($file_name, strrpos($file_name, '.')+1),
			];
		}, static::$file_list);
	}
	static function add_files($file_name_list) {
		static::$file_list = array_merge(static::$file_list, array_diff($file_name_list, static::$file_list));
	}
	static function clear_files() {
		static::$file_list = [];
	}

	static function smarty($template, $admin_access=null, $skin=null, $page='index', $options=[]) {
		if (is_null($admin_access))
			$admin_access = in_array($GLOBALS['user']['role'], ['root', 'admin']);

		if (empty($skin)) {
			$skin = $_SESSION['skin'] ?? \site\setting_db::get_setting(/*$admin_access ? 'skin_admin' : */'skin');

			if (empty($skin))
				$skin = 'admin';//$admin_access ? 'admin' : 'default';
		}

		$GLOBALS['lib']->smarty->assign('conf', $GLOBALS['conf']);
		$GLOBALS['lib']->smarty->assign('skin', $skin);
		if (empty($options['no_menu']))
			$GLOBALS['lib']->smarty->assign('menu_tree', static::menu($admin_access));
		$GLOBALS['lib']->smarty->assign('file_list', static::file_list_out());
		$GLOBALS['lib']->smarty->assign('user', $GLOBALS['user']);
//		$GLOBALS['lib']->smarty->assign('dateformat', $GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]);
		$GLOBALS['lib']->smarty->assign('settings', \site\setting_db::get_settings());
//		$GLOBALS['lib']->smarty->assign('lang_list', $GLOBALS['lib']->lang->list);
		$GLOBALS['lib']->smarty->assign('lang', $GLOBALS['lib']->lang->value);

		$GLOBALS['lib']->smarty->assign('js_vars', [
			'script_url'	=> $GLOBALS['conf']['site']['script_url'],
			'site_url'		=> $GLOBALS['conf']['site']['site_url'],
			'date_format'	=> $GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['php']['date'],
			'datetime_format'=> $GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['php']['datetime'],
			'user_id'		=> $GLOBALS['user']['id'],
			'user_role'		=> $GLOBALS['user']['role'],
			'locale'		=> $GLOBALS['lib']->lang->value,
		]);

		static::extensions();

		$GLOBALS['lib']->smarty->assign('body', $GLOBALS['lib']->smarty->fetch($template));

		header('Content-Type: text/html; charset= utf-8');
		$GLOBALS['lib']->smarty->display("skins/{$skin}/view/{$page}.tpl");

		if ($stat_info_data = $GLOBALS['lib']->site_stat->report())
			echo "<script type='text/javascript'>\nstat_info.build()\nstat_info.add(".json_encode($stat_info_data, JSON_FORCE_OBJECT).")\n</script>";
	}

	static function twig($template, $admin_access=false, $skin=null, $page='index', $context=[]) {
/*		$context['conf'] = $GLOBALS['conf'];
		$context['menu_tree'] = static::menu($admin_access);
		$context['file_list'] = static::file_list_out();
		$context['user'] = isset($GLOBALS['user']) ? $GLOBALS['user'] : [];
		$context['settings'] = \site\setting_db::get_settings();
		$context['lang'] = $GLOBALS['lib']->lang->value;
		$context['js_vars'] = [
			'script_url'	=> $GLOBALS['conf']['site']['script_url'],
			'site_url'		=> $GLOBALS['conf']['site']['site_url'],
			'date_format'	=> $GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['php']['date'],
			'user_id'		=> $GLOBALS['user']['id'],
			'user_role'		=> $GLOBALS['user']['role'],
		];
*/
		static::smarty($template, $admin_access, $skin, $page, $context);
	}

	static function ajax($data) {
		$data['current_user_id'] = $GLOBALS['user']['id'];
		if ($stat_info = $GLOBALS['lib']->site_stat->report('ajax'))
			$data['stat_info'] = $stat_info;

		header('Content-Type: application/json; charset=utf-8');
		echo json_encode($data);
	}

	static function menu($admin_access) {
		require_once 'conf/menu.php';
		require_once 'conf/menu_admin.php';

		$current_url = [
			$GLOBALS['request_url'],
			$GLOBALS['controller']['module'].'/'.$GLOBALS['controller']['controller'].'/'.$GLOBALS['controller']['method']
		];
		if ($GLOBALS['controller']['method']==='start')
			$current_url[] = $GLOBALS['controller']['module'].'/'.$GLOBALS['controller']['controller'];

		$menu_tree = static::menu_access(array_merge($GLOBALS['menu_admin'], $GLOBALS['menu']), $GLOBALS['user']['role'], $current_url)[0];

		return $menu_tree;
	}
	static function menu_access($menu_tree, $role, $current_url = [], &$counter=0) {
		$branch = [];
		$current = false;

		foreach ($menu_tree as $k=>$i){
			if (!empty($i['access']) && !in_array($role, $i['access']))
				continue;

			$item_current = in_array($i['url'] ?? '', $current_url);
			$current = $current || $item_current;

			$branch[$k] = [
				'title'		=> $i['title'],
				'no_lang'	=> $i['no_lang'] ?? null,
				'className'	=> $i['className'] ?? false,
				'icon'		=> $i['icon'] ?? false,
				'url'		=> isset($i['url']) ? ((strpos($i['url'], '://')===false?$GLOBALS['conf']['site']['script_url']:'').$i['url']) : '',
				'target'	=> $i['target'] ?? null,
				'current'	=> $item_current,
				'menu_item_id'=>$counter ++,
			];

			if (!empty($i['child'])) {
				if (!isset($menu_tree[$k]['sub']))
					$i['sub'] = [];
				list($module, $controller, $method) = explode('/', $i['child']);
				$i['sub'] = array_merge(
					controller_manager::module_execute($module, $controller, $method),
					$i['sub']
				);
			}

			if (!empty($i['sub']) && count($menu_tree[$k]['sub'])>0) {
				list($branch[$k]['sub'], $branch[$k]['current']) = static::menu_access($i['sub'], $role, $current_url, $counter);
				$current = $current || $branch[$k]['current'];
			}

		}
		return [$branch, $current];
	}

	static function extensions() {
//		if ($GLOBALS['user']['id']>0) {// messages count
//			$GLOBALS['lib']->smarty->assign('current_message_count', \message\group_user_db::current_message_count());
//		}
	}

	static function lang_prepare($options=[]) {
		$lang = [];

		static::lang_list([
			'add', 'create', 'edit', 'info', 'view', 'delete', 'edit_history', 'del_history', // buttons
			'select', 'selected', 'to_mark',
			'filters', 'search', 'reset',
			'save', 'yes', 'no', 'to_clear',
			'notification', 'confirmation', 'warning', 'error', 'ok', 'cancel', 'continue', 'record_will_be_deleted',
			'records', 'page_no', 'go_to_page', 'records_per_page', 'all', // pagination
			'previous_page', 'next_page', 'records_per_page',
		], $lang);

		if (!empty($options['model_name'])) {
			$item_name = substr((new \ReflectionClass($options['model_name']))->getShortName(), 0, -3); // class name without '_db'
			$lang[$item_name] = lang($item_name, false);
			$lang['model_name'] = $options['model_name'];

			static::lang_list(array_keys($options['model_name']::get_system_fields()), $lang);

			static::lang_list(array_keys($options['model_name']::get_field_list()), $lang);
			static::lang_list(array_column($options['model_name']::get_field_list(), 'title'), $lang);
			static::lang_list(array_column($options['model_name']::get_field_list(), 'description'), $lang);

			foreach ($options['model_name']::get_json_map() as $l) {
				static::lang_list(array_keys($l), $lang);
				static::lang_list(array_column($l, 'title'), $lang);
				static::lang_list(array_column($l, 'description'), $lang);
			}

			static::lang_list($options['model_name']::get_enum(), $lang, true);

			if (method_exists($options['model_name'], 'get_localisation_fields'))
				static::lang_list(array_keys($options['model_name']::get_localisation_fields()), $lang);

			static::lang_list(array_keys($options['model_name']::get_columns()), $lang);
			static::lang_list(array_column($options['model_name']::get_columns(), 'title'), $lang);

			static::lang_list(array_keys($options['model_name']::get_filters()), $lang);
			static::lang_list(array_column($options['model_name']::get_filters(), 'title'), $lang);
		}

		if (!empty($options['list']))
			static::lang_list($options['list'], $lang);

		return $lang;
	}

	protected static function lang_list($list, &$lang, $no_key=false) {
		foreach ($list as $k=>$i)
			if (is_array($i)) {
				static::lang_list($i, $lang, $no_key);
			} else if (!empty($i) && is_string($i)) {
				$lang[$no_key || is_int($k) ? $i : $k] = lang($i, false);
			}
	}
}
