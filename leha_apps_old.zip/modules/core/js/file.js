function file_list_class() {
	table_call_class.call(this);

	this.data.call_width = 1200
	this.data.title_icon = 'save'

	this.list_url	= 'core/file/list_ajax'
	this.edit_url	= 'core/file/edit_ajax'
	this.del_url	= 'core/file/delete_ajax'

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, el) {
		td_formatter_icons_parent.call(this, field_name, record, el)

		let mime_type = record.mime_type ? record.mime_type.split('/')[0] : false,
			play = document.player &&
			document.player.current_player &&
			document.player.current_player.track.id===record.id ? 1 : 0


		el.children[0].children.splice(3, 0,
			{
				tagName: 'a',
				attributes: {
					href: record.url,//+'/attachment',
					target: '_blank',
					title: this.lang('download'),
				},
				className: ['btn', 'icon', 'download'],
			},
			mime_type==='image' ? {
				className: 'btn icon eye',
				properties: {title: this.lang('view'), tabindex: 0},
				events: {clickenter: this.viewer.bind(this, record)},
			} : (mime_type==='audio' || mime_type==='video' ? {
				className: ['btn', 'icon', play ? 'pause' : 'play'],
				attributes: {
//					title:		play ? this.lang('pause') : this.lang('play'),
					btn_play:	true
				},
				events: {click: this.play.bind(this, record)},
			} : {className: 'btn icon empty'})
		)
	}

//	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function() {
//		let action_icons = create_action_icons_parent.call(this)
		return [
//			{
//				className: ['btn', 'icon'],
//				styles: {backgroundColor: 'rgba(0, 0, 255, 0.1)'},
//				properties: {title: this.lang('protected')},
//			},
			this.structure.upload_btn = {
				className: ['btn', 'icon', 'upload'],
				children: {
					tagName: 'input',
					properties: {type: 'file', multiple: 'multiple', title: this.lang('upload')},
					events: {change: this.upload.bind(this)}
				}
			},
			this.structure.upload_btn_protected = {
				className: ['btn', 'icon', 'upload', 'blue'],
				children: {
					tagName: 'input',
					properties: {type: 'file', multiple: 'multiple', title: this.lang(['upload', 'protected']), protected: true},
					events: {change: this.upload.bind(this)}
				}
			}
		]
	}

	this.upload = function(ev) {
		let protected = ev.target.hasOwnProperty('protected'),
			btn = this.structure['upload_btn'+(protected?'_protected':'')].el
		if (btn.classList.contains('wait'))
			return

		btn.classList.remove('plus')
		btn.classList.add('wait')

		yozh_ajax({
			url:		script_url + 'core/file/upload_ajax',
			data: {data: {protected: protected}},
			files:		ev.target.files,
			on_success_fn: function(response_data) {
				btn.classList.remove('wait')
				btn.classList.add('plus')
				this.list({})
			}.bind(this),
			on_err_fn: function() {
			}.bind(this)
		})
		ev.target.value = ''
	}

	this.record_name = function(record) {
		return '['+record.id+'] '+record.original_name
	}

	let call_btn_return_parent = this.call_btn_return
	this.call_btn_return = function (records, event) { // если список вызван от простой кнопки
		call_btn_return_parent.call(this, records, event)

		let input_block = this.data.call_btn.closest('.input-block') || this.data.call_btn.parentNode

		let el = input_block.querySelector('.download')
		if (el) {
			el.classList.remove('disabled')
			el.href = records[Object.keys(records)[0]].url
			el.target = '_blank'
		}
	}

	this.viewer = function(record) {
		let viewer = image_viewer({show_on_create: false}),
			current = -1,
			img_list = this.data.records.map((r, i)=>{
				if (r.id===record.id)
					current = i
				return record.mime_type && record.mime_type.split('/')[0]==='image' ? {
					url: r.url,
					title: {className: ['flex-block', 'between5'], children: [{className: 'w100', text: r.file_size_str}, {text: this.record_name(r)}]},
					actions: [
						{
							tagName: 'a',
							attributes: {
								href: r.url+'/attachment',
								target: '_blank',
								title: this.lang('download'),
							},
							className: ['btn', 'icon', 'download'],
						},
						this.data.select_mode===1 ? {
							className: ['btn', 'icon', 'hand-pointer-o', 'orange'],
							title: this.lang('select'),
							events: {clickenter: ()=>{
								viewer.popup.close()
								this.return_record(r)
							}}
						} : null,
					],
				} : null
			})
		Object.assign(viewer, {current: current, img_list: img_list})
		viewer.show_image(current)
	}

	//-- image_mode ----------------------------------------------------------------------------------------------------
	this.data.image_mode = false

	let build_structure_parent = this.build_structure
	this.build_structure = function(popup_mode) {
		let structure = build_structure_parent.call(this, popup_mode)
		if (this.data.image_mode) {
			this.structure.table_box.className.push('flex-grow', 'flex-block', 'wrap', 'left', 'top', 'pt10', 'pl10')
			this.data.filters.mime_type = 'image'
		}
		return structure
	}

	let build_table_parent = this.build_table
	this.build_table = function() {
		if (this.data.image_mode) {
			this.data.filters_model.mime_type.type = 'hidden'
			return this.build_table_image_mode()
		} else {
			return build_table_parent.call(this)
		}
	}

	this.build_table_image_mode = function () {
		let tr_list = this.data.records.map((record)=>{ // перебираем строки
			let tr = {
				className: ['mr10', 'mb10', 'relative'],
				attributes: {record_id: record.id},
				styles: {
					width: '220px',
					height: '200px',
					backgroundSize: 'contain',
					backgroundPosition: '50% 50%',
					backgroundRepeat: 'no-repeat',
					backgroundImage: 'url('+record.url+')',
				},
				children: ['original_name', 'functions'].map((field_name)=>{
					return Object.assign(this.build_td(record, field_name), {tagName: null})
				}),
			}
			tr.children[0].className.push('hover_invisible')
			tr.children[0].children[0].children.styles = {backgroundColor: 'rgba(0,0,0,0.5)', padding: '5px', color: '#fff'}
			tr.children[1].className = []
			tr.children[1].styles = {position: 'absolute', right: '2px', bottom: '2px'}

			return tr
		})

		return tr_list
	}
	// play section ----------------------------------------------------------------------------------------------------
	this.play = function(record) {
		if (!document.player)
			new player({})

		document.player.addEventListener('playerChangeStatus', this.on_play_status_change_bind)
		document.player.play_track(this._record_to_track(record))
	}

	this.on_play_status_change_bind = function (event) {
		let status = event.status,
			track = event.track,
			btn = this.structure.table_box.el.querySelector('tr[record_id="'+track.id+'"] td[field_name="functions"] .btn[btn_play]')

		if (btn) {
			btn.classList.add(status === 'play' ? 'pause' : 'play')
			btn.classList.remove(status === 'play' ? 'play' : 'pause')
		}
	}.bind(this)

	this._record_to_track = function (record) {
		return {
			id: record.id,
			file_type: record.mime_type.split('/')[0],
			url: record.url,
			name: record.original_name,
		}
	}

}

function file_list_show(data, event) {
	if (event) data.call_btn = event.target
	new file_list_class().show(data)
}

var field_file_upload = function (options= {}) {
	if (event.target.files.length===0)
		return

	let row = event.target.closest('.table-row')
	row.wait()

	yozh_ajax({
		url:		script_url + 'core/file/upload_ajax',
		files:		event.target.files,
		data:		{data: options.data||{}},
		on_success_fn: function(response_data) {
			if (Object.keys(response_data.result_list).length===0){

			} else {
				if (!response_data.result_list[0].status) {
					yozh_notify({
						title_className: ['icon', 'icon-left-h30', 'exclamation', 'red'],
						text_className: 'p20',
						text: response_data.result_list[0].err_msg,
					})
				} else {
					row.querySelector('input').value = response_data.result_list[0].id
					row.querySelector('.input').innerHTML = response_data.result_list[0].name
					let a_download = row.querySelector('a.download')
					if (a_download) {
						a_download.classList.remove('disabled')
						a_download.href = response_data.result_list[0].url
						a_download.target = '_blank'
					}
				}
			}
			event.target.value = ''
			row.wait(false)
			return
		},
	})
}
