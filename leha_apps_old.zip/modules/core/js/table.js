// рисует таблицу по списку из ajax
function table_class () {

	this.structure = {
		table_frame:	null, // div, в котором лежат pager_box и table_box
		header_line:	null,
		header_title:	null,
		pager_box:		null, // div над таблицей, в нём div с кнопками навигации и опционально информационный div
//		table_line:		null,
		table_box:		null, // div, в котором лежит таблица
	}

	this.data = {
		columns:		{},
		pagination:		{},
		records:		[],
		enum:			{},
		lang:			{},
		custom_data:	{},

		title:			'',	// заголовок окна
		title_icon:		null,
	}

	this.tooltip = null

	this.show = async function(show_data={}) {
		Object.assign(this.data, show_data)

		if (!this.structure.table_frame)
			this.structure.table_frame = {el: document.body}
		el_add_children(this.structure.table_frame.el, this.build_structure())

		await this.list({})
	}

	this.build_structure = function() {
		return [
			this.structure.header_line = {
				className: ['flex-block'],
				children: [
					this.structure.header_title = { // заголовок окна
						className: ['table-row', 'flex-grow', 'relative', 'ellipsis'].concat(this.data.title_icon ? ['icon', 'icon-left', this.data.title_icon] : null),
						children: [{
							tagName: 'h1',
							text: this.data.title,
						}],
					},
					this.structure.pager_box = {
						className: ['table-row', 'flex-block', 'row-reverse', 'between'],
					},
				],
			},
			this.structure.table_box = {
				className: ['table', 'scroll', 'shadow'],
			},
		]
	}

	//------------------------------------------------------------------------------------------------------------------
	this.lang = function(name, noCaps=false) {
		return lang (this.data.lang, name, noCaps)
	}

	//------------------------------------------------------------------------------------------------------------------
	this.get_pagination_data = function() {
		return {
			order:		this.data.pagination.order || null,
			dir:		this.data.pagination.dir || null,
			page_no:	this.data.pagination.page_no || null,
			page_size:	this.data.pagination.page_size || null,
		}
	}
	this.set_page_no = function(page_no) {
		if (page_no<=0)
			page_no = 0
		if (page_no>=this.data.pagination.page_count)
			page_no = this.data.pagination.page_count-1
		this.list({page_no: page_no})
	}
	this.set_page_size = function (page_size) {
		this.list({page_size: page_size, page_no: 0})
	}

	//-- build ---------------------------------------------------------------------------------------------------------
	this.build_th = function (field_name) {
		let column = this.data.columns[field_name],
			dir = column.sorted ? (this.data.pagination.order===field_name ? this.data.pagination.dir.toLowerCase() : null) : null
		return {
			tagName: 'th',
			attributes: {field_name: field_name.length>0 ? field_name : null},
			className: column.className ? (typeof(column.className)==='string' ? column.className.split(' ') : column.className) : [],
			styles: {}, //column.styles ? column.styles : null,
			children: [
				{
					className: ['flex-block', 'between2', 'right', ...(column.th_icon ? ['icon', 'icon-left',  column.th_icon] : [])],
					attributes: column.th_icon ? {title:  (this.lang(column.hasOwnProperty('title') ? column.title : field_name))} : null,
					children: [
						column.th_icon ? null : {
							className: ['flex-grow'],
							text: this.lang(column.hasOwnProperty('title') ? column.title : field_name)
						},
						column.sorted ? {
							className: ['btn', 'icon', 'sort'+(dir?'-'+dir:''), 'no-border', 'white'],
							events: {'click': this.list.bind(this, {order: field_name, dir: dir==='asc' ? 'desc' : 'asc', page_no: 0})}
						} : null
					]
				},
			]
		}
	}
	this.build_head_row = function() {
		return {
			tagName:	'tr',
			children:	Object.keys(this.data.columns).map(this.build_th.bind(this))
		}
	}

	this.build_td = function (record, field_name) {
		let column = this.data.columns[field_name]
		return {
			tagName: 'td',
			attributes: {field_name: field_name.length>0 ? field_name : null},
			className: column.className ? (typeof(column.className)==='string' ? column.className.split(' ') : Array.from(column.className)) : [],
			styles: column.styles ? column.styles : {},
			events: {},
			text: typeof(record[field_name])!=='undefined' ? record[field_name] : null
		}
	}
	this.build_tr = function (record) {
		return {
			tagName: 'tr',
			className: [],
			attributes: {record_id: record.id},
			children: Object.keys(this.data.columns).map(this.build_td.bind(this, record)),
		}
	}
	this.build_rows = function() {
		let tr_list = this.data.records.map(this.build_tr.bind(this))

		// add empty rows
		let min_row_count = this.data.pagination.page_size==='all' ? 10 : Math.min(this.data.pagination.page_size, 10)
		if (tr_list.length<min_row_count) {
			let tr_empty = {
				tagName: 'tr',
				children: Object.keys(this.data.columns).map((field_name)=>{
					let column = this.data.columns[field_name]
					return {
						tagName: 'td',
						className: column.className ? (typeof(column.className)==='string' ? column.className.split(' ') : column.className) : [],
						html: '&nbsp;'
					}
				})
			}
			while (tr_list.length<min_row_count)
				tr_list.push(tr_empty)
		}

		return tr_list
	}

	this.build_pagination = function (pagination) {
		let	page_go			= ()=>{
			let p = parseInt(this.structure.page_go.el.value)
			p = isNaN(p) || p===0 ? 0 : p-1
			this.set_page_no.call(this, p)
		}

		return {
			className: ['flex-block', 'between10'],
			children: [
				{className: 'nowrap', text: this.lang('records')+': '+pagination.records_count},
//				pagination.page_size==='all' || pagination.page_count<2 ? null : {className: 'nowrap', text: this.lang('page')+' '+(Number(pagination.page_no)+1)+' '+this.lang('page_from')+' ' + pagination.page_count},
				pagination.page_size==='all' || pagination.page_count<2 ? null : {
					className: ['flex-block'],
					children: this.build_pagination_buttons(pagination)
				},
				pagination.page_count>5 ? {
					className: ['w60', 'flex-block'],
					children: [
						this.structure.page_go = {
							tagName: 'input',
							className: ['a-center', 'right-flat'],
							attributes: {
								type: 'text',
								value: pagination.page_no+1,
								title: this.lang('go_to_page'),
							},
							events: {keyup: (e)=>{if (e.keyCode===13) page_go()}}
						},
						{
							className: ['btn', 'icon', 'angle-right', 'left-flat'],
							attributes: {
								title: this.lang('go_to_page'),
								tabindex: 0,
							},
							events: {clickenter: page_go}
						}
					]
				} : null,
				pagination.page_size_values ? {
					children: {
						tagName: 'select',
						className: 'w50',
						events: {change: (ev)=>{this.set_page_size(ev.target.value)}},
						attributes: {title: this.lang('records_per_page')},
						children: Object.keys(pagination.page_size_values).map((i)=>{return {
							tagName: 'option',
							text: this.lang(pagination.page_size_values[i]),
							attributes: Object.assign(
								{value: pagination.page_size_values[i]},
								pagination.page_size==pagination.page_size_values[i] ? {selected: true} : null
							)
						}
						})
					}
				} : null,
			]
		}
	}
	this.build_pagination_buttons = function(pagination, o={}) {
		let r = o.r || 1,						// radius size
			c = Number(pagination.page_no),		// current page no
			t = Number(pagination.page_count),	// total pages
			l = t-1,							// last page no
			button_line = [],
			b = (n, className=null)=>{button_line.push({ // build button structure and put it to button_line
				className: ['btn', 'icon', n===c ? 'disabled' : null, className],
				events: {clickenter: n===c ? null : this.set_page_no.bind(this, n)},
				attributes: {tabindex: n===c ? -1 : 0},
				text: n+1,
			})}

		let s = 1, e = t-2 // start an end no of between-buttons (if short list)
		if (t > 3+r*2) { // long list
			if (c<1+(1+r)) { // current at the beginning
				s = 1
				e = 1 + r*2
			} else if (c>l-(1+r)) { // current at the end
				s = l - (1 + r*2)
				e = l - 1
			} else { // current between the beginning and end
				s = c - r,
				e = c + r
			}
		}

		b(0, c>1+r ? 'mr5' : 'mr2') // first button
		for (let n=s; n<=e; n++) // between-buttons
			b(n, n===e && n<l-1 ? 'mr5' : 'mr2')
		b(l) // last button

		return button_line
	}

	this.update_list = function() {
		// clear pagination
		while (this.structure.pager_box.el.firstChild)
			this.structure.pager_box.el.firstChild.remove()

		// build pagination
		el_add_children(this.structure.pager_box.el, this.build_pagination(this.data.pagination))

		// clear table
		while(this.structure.table_box.el.firstChild)
			this.structure.table_box.el.firstChild.remove()

		// clear table
		el_add_children(this.structure.table_box.el, this.build_table())

		if (!this.tooltip)
			this.tooltip = new yozh_tooltip()
		this.tooltip.set(this.structure.table_frame.el)
	}
	this.build_table = function(){
		return {
			tagName: 'table',
			children: [
				{
					tagName: 'thead',
					children: [this.build_head_row()],
				},
//				{
//					tagName: 'tfoot',
//					children: []
//				},
				this.structure.table_tbody = {
					tagName: 'tbody',
					children: this.build_rows()
				}
			]
		}
	}

	//-- list ----------------------------------------------------------------------------------------------------------
	this.list_url = null
	this.first_request = true
	this.list = async function(padination_data={}) {
		this.structure.table_frame.el.wait()

		let request_data = {pagination: {filters: {}}}

		if (this.first_request) {
			request_data.build_data = 1
			this.first_request = false
		}

		Object.assign(request_data.pagination, this.get_pagination_data())

		for (let i in request_data.pagination)
			if (padination_data.hasOwnProperty(i))
				request_data.pagination[i] = padination_data[i]

		let response_data = await yozh_fetch({
			url: script_url + this.list_url,
			data: request_data,
		})

		if (response_data.success) {
			// обновить this.data
			Object.keys(response_data.table).forEach((i)=>{
				if (this.data.hasOwnProperty([i]))
					this.data[i] = response_data.table[i]
			})

			this.update_list()
		} else {
		}
		this.structure.table_frame.el.wait(false)
	}
}

// добавляет форматирование строк, td, th
// форматирование td functions
function table_formatter_class () {
	Object.assign(this.structure, {
		selected_count:	null,	// если multi_select, это div, в котором отображается количество отмеченных записей
		select_all:		null,	// если multi_select, это checkbox, для выбора всех записей на странице
		action_box:		null,	// div, в котором хранится кнопки (создать, история удалений, и прочие)
		btn_create:		null,	// кнопка в action_box
		btn_remove_history:null,// кнопка в action_box
	})

	Object.assign(this.data, {
		multi_select: false,
		selected_records: {}, // выбранные записи {id: record, ...}
		selected_records_count: 0,
	})

	let show_parent = this.show
	this.show = async function(show_data={}) {
		await show_parent.call(this, show_data)
		this.build_actions()
	}

	let update_list_parent = this.update_list
	this.update_list = function() {
		update_list_parent.call(this)

		if (this.data.multi_select)
			this.show_selected_records()
	}

	let build_structure_parent = this.build_structure
	this.build_structure = function() {
		build_structure_parent.call(this)
		return [
			this.structure.header_line = {
				className: ['flex-block'],
				children: [
					this.structure.header_title,
					this.structure.action_box = {
						className: ['table-row', 'flex-block', 'between2'],
					}
				],
			},
			this.structure.pager_box,
			this.structure.table_box,
		]
	}

	this.admin_access = ['root', 'admin'].indexOf(user_role)!==-1
	this.root_access = user_role==='root'

	this.record_name = function(record) {
		return '['+record.id+'] '+record.name
	}

	//-- actions -------------------------------------------------------------------------------------------------------
	this.create_action_icons = function() {
		let change_log_delete_filters = Object.assign({change_type_str: 'delete'}, this.action_history_filters())
		return [
			this.structure.btn_create = {
				className: ['btn', 'icon', 'plus'],
				attributes: {
					title: this.lang('create'),
					tabindex: 0,
				},
				events: {clickenter: this.edit.bind(this)}
			},
			this.structure.btn_remove_history = this.admin_access && this.data.lang.model_name ? {
				tagName: 'a',
				className: ['btn', 'icon', 'trash-o', '-history'],
				attributes: {
					title: this.lang('del_history'),
					target: '_blank',
					href: script_url + 'core/change_log/start/' + encodeURIComponent(JSON.stringify(change_log_delete_filters)),
				},
				events: {link_click: change_log_list_show.bind(null, {
					filters: change_log_delete_filters,
					title: this.data.title + ' - ' + this.lang('del_history')
				})}
			} : null,
		]
	}
	this.action_history_filters = function () {
		return {model: this.data.lang.model_name}
	}
	this.build_actions = function() {
		if (!this.structure.action_box)
			return
		el_add_children(this.structure.action_box.el, this.create_action_icons())
		this.tooltip.set(this.structure.action_box.el)
	}

	//-- tr ------------------------------------------------------------------------------------------------------------
	let build_tr_parent = this.build_tr
	this.build_tr = function (record) {
		let tr_structure = build_tr_parent.call(this, record)
		this.row_formatter(record, tr_structure)
		return tr_structure
	}

	this.row_classes = {red: 'red', green: 'green', blue: 'blue', orange: 'orange', disabled: 'disabled'}
	this.row_formatter = function (record, row_structure) {
		for (let i in this.row_classes)
			if (record.hasOwnProperty(i))
				if (to_bool(record[i]))
					row_structure.className.push(this.row_classes[i])
	}

	//-- th ------------------------------------------------------------------------------------------------------------
	let build_th_parent = this.build_th
	this.build_th = function (field_name) {
		let th_structure = build_th_parent.call(this, field_name)

		if (field_name==='functions' && this.data.multi_select) // multi_select
			th_structure.children = [{
				className: ['flex-block', 'between2', 'right'],
				children: [
					this.structure.selected_count = {
						className: ['flex-grow', 'a-center', 'input', 'white', 'fs16'/*, 'w-max50'*/],
//						text: this.data.selected_records_count,
						attributes: {title: this.lang(['selected', 'records'])},
						children: [
							{},
							{
								className: ['btn', 'circle', 'slim', 'icon', 'remove', 'red'],
								attributes: {title: this.lang(['to_clear'])},
								events: {
									clickenter: (e)=>{e.stopPropagation(); this.clear_selected_records()},
									mouseover: (e)=>{e.stopPropagation()},
									mouseout: (e)=>{e.stopPropagation()},
								},
							},
						]
					},
					{
						tagName: 'label',
						className: 'checkbox white',
						children: [
							this.structure.select_all = {
								tagName: 'input',
								attributes: {type: 'checkbox'},
								events: {clickenter: this.select_all_records.bind(this)}
							},
							{
								attributes: {title: this.lang(['to_mark', 'all'])},
							}
						],
					},
				]
			}]

		return th_structure
	}

	//-- td ------------------------------------------------------------------------------------------------------------
	let build_td_parent = this.build_td
	this.build_td = function (record, field_name) {
		let td_structure = build_td_parent.call(this, record, field_name)

		if (typeof(this.data.columns[field_name].js_formatter)!=='undefined')
			this[this.data.columns[field_name].js_formatter] (field_name, record, td_structure)

		return td_structure
	}

	this.td_formatter_str = function(field_name, record, td_structure) {
		td_structure.text = record[field_name+'_str']
	}
	this.td_formatter_str_ellipsis = function(field_name, record, td_structure) {
		this.td_formatter_ellipsis(field_name+'_str', record, td_structure)
	}
	this.td_formatter_ref = function(field_name, record, td_structure) {
		if (!record[field_name])
			return
		this.td_formatter_ellipsis(field_name+'_str', record, td_structure)

		td_structure.className.push('pointer')
		td_structure.events = {click: window[this.data.columns[field_name].js_call].bind(null, {
			filters: {id: record[field_name]},
			title: this.lang(field_name),
		}, {})}
	}

	this.td_formatter_enum = function(field_name, record, td_structure) {
		td_structure.text = record[field_name] ? this.lang(this.data.enum[field_name][record[field_name]]) : ''
	}

	this.td_formatter_yes_no = function(field_name, record, td_structure) {
		td_structure.text = this.lang(to_bool(record[field_name]) ? 'yes' : 'no')
	}

	this.td_formatter_ellipsis = function(field_name, record, td_structure) {
		delete td_structure.text
		td_structure.children = [{
			className: ['td_ellipsis'],
			children: [
				{
					className: ['ellipsis', 'w100p'],
					text: record[field_name],
				}
			]
		}]
	}
	this.td_formatter_color = function(field_name, record, td_structure) {
		if (record.color || record[field_name+'_color'])
			td_structure.styles.backgroundColor = record.color || record[field_name+'_color']
	}
	this.td_formatter_str_color = function(field_name, record, td_structure) {
		td_structure.text = record[field_name+'_str']
		this.td_formatter_color(field_name, record, td_structure)
	}
	this.td_formatter_color_ellipsis = function(field_name, record, td_structure) {
		this.td_formatter_color(field_name, record, td_structure)
		this.td_formatter_ellipsis(field_name, record, td_structure)
	}
	this.td_formatter_str_color_ellipsis = function(field_name, record, td_structure) {
		this.td_formatter_color(field_name, record, td_structure)
		this.td_formatter_str_ellipsis(field_name, record, td_structure)
	}
	//-- td editors ----------------------------------------------------------------------------------------------------
	this.td_formatter_edit_field = function(field_name, record, td_structure) {// edit str field -------------------
		td_structure.className.push('pointer')
		td_structure.events.click = this.edit_field_show.bind(this, 'str', field_name, record, td_structure)
	}
	this.td_formatter_edit_field_enum = function(field_name, record, td_structure) {// edit enum field -----------------
		this.td_formatter_enum(field_name, record, td_structure)
		td_structure.className.push('pointer')
		td_structure.events.click = this.edit_field_show.bind(this, 'enum', field_name, record, td_structure)
	}
	this.td_formatter_edit_field_bool = function(field_name, record, td_structure) {// edit bool field -----------------
		this.td_formatter_yes_no(field_name, record, td_structure)
		td_structure.className.push('pointer')
		td_structure.events.click = this.edit_field_save.bind(this, field_name, record, !to_bool(record[field_name]))
	}
	this.td_formatter_edit_field_ref = function(field_name, record, el) {// edit ref field -----------------------------
		Object.assign(el, {
			className: ['pointer'],
			children: null,
			text: record[field_name+'_str'],
			events: {click: window[this.data.columns[field_name].js_call].bind(null, {
					title: this.lang('select')+' '+this.lang(field_name),
					select_fn: (record_list) => {
						let value = Object.keys(record_list)[0]
						if (value!==record[field_name])
							this.edit_field_save(field_name, record, Object.keys(record_list)[0])
					},
					select_mode: 1,
				}, {})}
		})
	}

	this.edit_field_show = function(type, field_name, record, td_structure, event) {
		let children = td_structure.text || td_structure.children

		event.yozh_row_no_select = true // по клику не выбирать строку (в режиме выбора)

		event.edit_mode = td_structure.el // добавляем событию метку, что бы не срабатывало document.onclick
		if (td_structure.el.edit_mode) // если редактор уже создан
			return
		td_structure.el.edit_mode = true // добавляем флаг, что редактор уже создан

		let _edit_field_hide = function (event) { // функция закрытия редактора
			if (event.edit_mode && event.edit_mode===td_structure.el) // если закрытие пришло с меткой из редактора
				return
			document.removeEventListener('click', _edit_field_hide)
			while (td_structure.el.firstChild)
				td_structure.el.firstChild.remove()
			el_add_children(td_structure.el, children)
			delete td_structure.el.edit_mode
		}.bind(this)

		while (td_structure.el.firstChild)
			td_structure.el.firstChild.remove()

		let input = {}
		if (type==='enum') {
			input = {
				tagName: 'select',
				children: Object.keys(this.data.enum[field_name]).map((v)=>{
					return {
						tagName: 'option',
						text: this.lang(this.data.enum[field_name][v]),
						properties: Object.assign({value: v}, v===record[field_name] ? {selected: true} : null),
					}
				}),
				events: {change: (event)=>{
						document.removeEventListener('click', _edit_field_hide)
						this.edit_field_save(field_name, record, input.el.value)
					}}
			}
		} else {
			input = {
				tagName: 'input',
				className: 'a-right',
				attributes: {
					type: 'text',
					value: record[field_name],
				},
				events: {keydown: (e)=>{
						if (e.keyCode===13) {
							document.removeEventListener('click', _edit_field_hide)
							this.edit_field_save(field_name, record, input.el.value, e)
						} else if (e.keyCode===27) {
							_edit_field_hide(e)
						}
					}}
			}
		}
		el_add_children(td_structure.el, input)
		input.el.focus()

		document.addEventListener('click', _edit_field_hide)
	}

	this.edit_field_save = async function(field_name, record, value, event) {
		if (event)
			event.yozh_row_no_select = true // не выбирать запись (в режиме выбора)

		let response_data = await yozh_fetch({
			url: script_url + this.edit_field_url,
			data: this.edit_field_data_compile(field_name, record, value),
		})

		if (response_data.success) {
			this.list()
		} else {
			if (response_data.err) {
				yozh_notify({
					title_className: ['icon', 'icon-left', 'exclamation', 'red'],
					text: response_data.err ? {children: Object.keys(response_data.err).map(function (i) {
							return {
								className: 'table-row color',
								text: response_data.err[i],
							}
						})} : {
						className: 'table-row color',
						text: 'unknown error'
					}
				})
			}
		}
	}
	this.edit_field_data_compile = function (field_name, record, value) {
		return {field_name: field_name, item_id: record.id, value: value}
	}

	//-- icons ---------------------------------------------------------------------------------------------------------
	this.td_formatter_icons = function(field_name, record, td_structure) {
		let change_log_filters = {model: this.data.lang.model_name, record_id: record.id}

		if (!td_structure.events)
			td_structure.events = {}

		td_structure.events.click = (e)=>{e.yozh_row_no_select = true},

		td_structure.children = [{
			className: ['flex-block', 'between2', 'right'],
//			events: {click: function(e) {e.stopPropagation()}},
			children: [
				this.edit_url ? {
					attributes: {title: this.lang('edit'), tabindex: 0},
					className: ['btn', 'icon', 'edit'],
					events: {click: this.edit.bind(this, record)}
				} : null,
				this.admin_access ? {
					tagName: 'a',
					className: ['btn', 'icon', 'history'],
					attributes: {
						title: this.lang('edit_history'),
						target: '_blank',
						tabindex: 0,
						href: script_url + 'core/change_log/start/' + encodeURIComponent(JSON.stringify(change_log_filters)),
					},
					events: {link_click: change_log_list_show.bind(null, {
							filters: change_log_filters,
							title: this.record_name(record) + ' - ' + this.lang('edit_history')
						})}
				} : null,
				this.del_url ? {
					attributes: {title: this.lang('delete'), tabindex: 0},
					className: ['btn', 'icon', 'del', 'red'],
					events: {click: this.del.bind(this, record)}
				} : null,
				this.data.multi_select ? {
					tagName: 'label',
					className: 'checkbox',
					children: [
						{
							tagName: 'input',
							attributes: Object.assign ({
								type: 'checkbox',
								select_record: true,
								value: record.id,
							}, typeof this.data.selected_records[record.id] !== 'undefined' ? {checked: true} : {}),
							properties: {
								record: record,
							},
							events: {change: this.select_record.bind(this, record/*, td_structure*/)}
						}, {}
					],
				} : null
			]
		}]
	}
	this.edit_width = 800
	this.edit_field_title_width = 200
	this.edit_url = null
	this.edit = function(record, e) {
//		if (e)
//			e.stopPropagation()

		edit_popup({
			width:	this.edit_width,
			url:	script_url + this.edit_url,
			data:	this.edit_data_compile(record),
			fn_after_save: (response_data, s)=>{this.list(); return true},
			form: {field_title_width: this.edit_field_title_width},
			tooltip: this.tooltip,
		})
	}
	this.edit_data_compile = function(record) {
		return {
			item_id: record instanceof Object && record.hasOwnProperty('id') ? record.id : ''
		}
	}

	this.del_url = null
	this.del = function(record, e, options) {
//		if (e)
//			e.stopPropagation()

		yozh_notify({
			title:				this.lang('confirmation'),
			title_className:	['icon', 'icon-left-h30', 'exclamation', 'c-red'],
			html:				this.lang('record_will_be_deleted')+'<br />'+this.lang('continue')+'?',
			text_className:		'p20',
			confirm_mode:		true,
			ok_className:		['btn', 'red'],
			on_ok:				async function () {
				this.structure.table_frame.el.wait()

				let response_data = await yozh_fetch({
					url: script_url + this.del_url,
					data: options && options.data_compiler instanceof Function ? options.data_compiler(record) : this.del_data_compile(record),
				})

				if (response_data.success) {
					if (options && options.on_success)
						options.on_success()
					this.list({})
				} else {
					this.structure.table_frame.el.wait(false)
					yozh_notify({text: response_data.err_msg})
				}
			}.bind(this),
			cancel_text: this.lang('cancel')
		})
	}
	this.del_data_compile = function(record) {
		return {item_id: record.id}
	}
	//-- multiselect ---------------------------------------------------------------------------------------------------
	this.select_record = function (record/*, tr_structure*/) { // выбрать / отменить выбор одной записи
//		let checkbox = tr_structure.qelquerySelector('input[select_record]'),
		let checkbox = this.structure.table_box.el.querySelector('tr[record_id="'+record.id+'"] input[select_record]'),
			checked = checkbox.checked //event.target.checked
		checked ? this.data.selected_records[record.id] = record : delete this.data.selected_records[record.id]
		this.show_selected_records()
	}
	this.select_all_records = function (event) { // выбрать / отменить выбор всех записей на текущей странице
		let checked = this.structure.select_all.el.checked
		for (let i of this.structure.table_box.el.querySelectorAll('input[select_record]')) {
			i.checked = checked
			checked ? this.data.selected_records[i.value] = i.record : delete this.data.selected_records[i.value]
		}
		this.show_selected_records()
	}
	this.show_selected_records = function() {
		let record_checkbox_select_list = this.structure.table_box.el.querySelectorAll('input[select_record]'),
			select_all_fl = record_checkbox_select_list.length>0
		for (let i of record_checkbox_select_list)
			if (!i.checked) {
				select_all_fl = false
				break
			}
		this.structure.select_all.el.checked = select_all_fl

		this.data.selected_records_count = Object.keys(this.data.selected_records).length
		this.structure.selected_count.children[0].el.innerHTML = this.data.selected_records_count
	}
	this.clear_selected_records = function() {
		this.data.selected_records=[]
		this.structure.select_all.el.checked = false
		for (let i of this.structure.table_box.el.querySelectorAll('input[select_record]'))
			i.checked = false
		this.show_selected_records()
	}
}

async function edit_popup(options = {
	width: 600,				// ширина окна
	url: null,				// url, который возвращает json {edit_data: {data, field_list, lang}}
	data: null,				// отправляемые данные, например: {item_id: int}
	fn_before_show: null,	// вызывается перед компилированием структуры формы в dom (structure, popup, response_data)
	fn_after_show: null,	// вызывается после отображения формы (structure, popup, response_data)

	save_url: null,			// не обязательно. если нет, используется url
	fn_save: null,			// не обязательно
	fn_before_save: null,	// для корректировки отправляемых данных (data)
	fn_after_save: null,	// выполняется после успешного сохранения (data)
	tooltip: null,
}) {
	let s = {
			popup: yozh_popup({width: options.width || 600})
		},
		response_data = await yozh_fetch({
			url: options.url,
			data: options.data || {},
		})
	Object.assign(s, build_edit_form(Object.assign({return_structure: true}, options.form?options.form:null, response_data.edit_data)))

	s.fn_save = options.fn_save || (async (s, ev)=>{
			s.popup.frame.el.wait(true)

			let data = get_form_data(s.form.el)
			if (options.fn_before_save instanceof Function)
				options.fn_before_save(data)

			let response_data = await yozh_fetch({
				url: options.save_url || options.url,
				data: data
			})

			if (response_data.success) {
				// если существует fn_after_save, то форма закрывается, если fn_after_save возвращает true
				if (!(options.fn_after_save instanceof Function) || options.fn_after_save(response_data, s))
					s.popup.close()
			} else {
				form_show_errors(s.form.el, response_data)
			}
			s.popup.frame.el.wait(false)
		})

	if (s.btn_save)
		s.btn_save.events = {clickenter: ()=>{s.fn_save(s)}}

	if (s.btn_ok)
		s.btn_ok.events = {clickenter: (ev)=>{s.popup.close(ev)}}

	if (options.fn_before_show instanceof Function)
		options.fn_before_show(s, response_data)

	s.popup.set(s.form)
	if (s.header)
		move_handle(s.popup.frame.el, s.header.el)
	s.popup.show()

	if (options.tooltip)
		options.tooltip.set(s.form.el)

	if (options.fn_after_show instanceof Function)
		options.fn_after_show(s, response_data)
}

function table_filter_class() {

	Object.assign(this.structure, {
		filters:		{},
		filter_form:	null,	// форма поиска
		filter_box:		null,	// div, в котором хранится filter_form
		two_col:		null,	// два столбца (фильтр и таблица)
	})

	Object.assign(this.data, {
		filters:	{},		// фильтры для первого запроса запроса
		filters_model:		{},	// структура для построения формы фильтров
		filters_ref_name:	{}, // имена ref фильтров (при построении формы фильтров)
		filter_title_width:	120,// ширина для названия фильтров
		filters_panel_hide:	false, // прятать панель поиска при первом показе
	})

	let show_parent = this.show
	this.show = async function(show_data={}) {
		await show_parent.call(this, show_data)
		this.build_filters()
	}


	let build_structure_parent = this.build_structure
	this.build_structure = function() {
		build_structure_parent.call(this)
		this.structure.pager_box.className.push('flex-grow')

		return [
			this.structure.header_line,
			this.structure.pager_line = {
				className: ['flex-block', 'between10'],
				children: [
					{
						className: ['table-row'],
						children: [
							this.structure.filters_btn = { // кнопка формы поиска
								className: ['btn', 'icon', 'filter'],
								attributes: {tabindex: 0},
								events: {clickenter: ()=>{this.structure.two_col.el.classList.toggle('two_col_first_hide')}}
							}
						]
					},
					this.structure.pager_box,
				],
			},
			this.structure.two_col = {
				className: ['two_col', 'flex-grow', 'flex-block', 'h0', window.innerWidth<801 || this.data.filters_panel_hide ? 'two_col_first_hide' : null],
				children: [
					this.structure.filter_box = { // форма поиска
						className: ['two_col_first', 'pr10'],
						children: [this.structure.filter_form = {// форма поиска
							tagName: 'form',
							className: ['w300', 'shadow', 'flex-block', 'column', 'popup-bg'],
							styles: {maxHeight: '100%', minHeight: '90px'},
							attributes: {
								method: 'post',
								action: 'javascript: void(0)',
							},
							events: {
								submit: this.form_filter_submit.bind(this)
							}
						}]
					},
					{
						className: ['two_col_second', 'flex-grow', 'w0'/*, 'flex-block', 'column', 'h100p'*/],
						children: [this.structure.table_box],
					}
				]
			},
		]
	}

	let list_parent = this.list
	this.list = async function(padination_data={}) {
		padination_data.filters = this.get_filters()
		await list_parent.call(this, padination_data)
	}

	this.get_filters = function () {
		return this.first_request ? this.data.filters : get_form_data(this.structure.filter_form.el)
	}

	this.build_filters = function() {
		if (!this.structure.filter_box)
			return

		let filters_list = []
		for(let i in this.data.filters_model) {
			let field_type = this.data.filters_model[i].type,
				value = (this.data.pagination && this.data.pagination.filters && this.data.pagination.filters[i] ? this.data.pagination.filters[i] : false) // сначала берём данные из возвращенных от сервера фильтров
					|| (this.data.filters && this.data.filters[i] ? this.data.filters[i] : false) // берем данные из фильтров построения формы
					|| this.data.filters_model[i].value // значение по умолчанию фильтра
					|| ''

			if (this['filter_'+field_type] instanceof Function) {
				filters_list.push({
					className: ['input-block', 'table-row', 'color', 'flex-block', 'between5', field_type==='hidden' ? 'c-gray': null, this.data.filters_model[i].slim?'slim':null],
					children: [
						{
							className: ['w'+this.data.filter_title_width, 'a-right', 'nowrap', 'overflow'].concat(this.data.filters_model[i].description ? ['icon', 'icon-right-h30', 'info', 'icon-color-disabled'] : null),
							attributes: this.data.filters_model[i].description ? {title: this.lang(this.data.filters_model[i].description)} : null,
							text: this.lang(this.data.filters_model[i].hasOwnProperty('title') ? this.data.filters_model[i].title : i),
						},
						this['filter_'+field_type](i, value)
					]
				})
			}
		}

		el_add_children(this.structure.filter_form.el, [
			{
				className: ['table-header'],
				children: [{
					className: ['table-row'],
					text: this.lang('filters'),
				}],
			},
			{
				className: ['flex-grow', 'scroll'],
				children: filters_list,
			},
			{
				className: ['table-header'],
				children: [{
					className: ['table-row', 'flex-block', 'right', 'between5'],
					children: [
						{
							className: ['btn', 'icon', 'refresh', 'orange'],
							attributes: {
								title: this.lang('reset'),
								tabindex: 0,
							},
							events: {clickenter: function() {this.filters_form_reset(); this.form_filter_submit()}.bind(this)}
						},
						{
							className: ['btn', 'icon', 'search'],
							children: {
								tagName: 'input',
								className: 'hover_invisible pointer',
								attributes: {
									type: 'submit',
									value: "",
									title: this.lang('search')
								},
							}
						}
					]
				}],
			},
		])

		this.tooltip.set(this.structure.filter_form.el)
	}

	this.clear_filter = function(i) {
		let el = this.structure.filter_form.el.elements[i],
			block = el.closest('.input-block')

		for(let j of block.querySelectorAll('input'))
			j.value=''

		el = block.querySelector('.input')
		if (el) el.innerHTML=''

		el = block.querySelector('.download')
		if (el) {
			el.classList.add('disabled')
			el.href = 'javascript:void(0);'
			el.target = '_self'
		}
		this.form_filter_submit(this)
	}

	this.filters_form_reset = function() {
		this.structure.filter_form.el.reset()
		for (let el of this.structure.filter_form.el.querySelectorAll('[value-first]')) {
			if (el.tagName.toLowerCase()==='input') {
				el.value = el.getAttribute('value-first')
			} else {
				el.innerHTML = el.getAttribute('value-first')
			}
		}
		for (let el of this.structure.filter_form.el.querySelectorAll('[reset-fn]'))
			el.reset()
	}

	this.form_filter_submit = function() {
//		if (this.data.popup_mode)
//			this.structure.two_col.el.classList.add('two_col_first_hide')
		this.list({page_no: 0})
		return false
	}


	//-- filters -------------------------------------------------------------------------------------------------------
	this.filter_hidden = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		if (typeof(value)==="boolean")
			value = value ? 1 : 0
		return {
			className: ['flex-grow', 'ellipsis'],
			children: [
				this.structure.filters[i] = {
					tagName: 'input',
					attributes: {
						type: 'hidden',
						name: i,
						value: value
					}
				},
				{
					className: ['input', slim],
					text: this.data.filters_ref_name && this.data.filters_ref_name[i] ? this.data.filters_ref_name[i] : value
				}
			]
		}
	}
	this.filter_int = this.filter_str = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/],
			children: [
				this.structure.filters[i] = {
					tagName: 'input',
					className: [slim],
					attributes: {
						type: 'text',
						name: i,
						value: value,
						autocomplete: 'off',
					}
				},
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: this.clear_filter.bind(this, i)},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	this.filter_like = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		value = (this.data.filters && this.data.filters[i+'_like'] ? this.data.filters[i+'_like'] : false) ||
			this.data.filters_model[i].value
			|| ''
		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/],
			children: [
				{
					tagName: 'input',
					className: [slim],
					attributes: {
						type: 'text',
						name: i+'_like',
						value: value,
						autocomplete: 'off',
					}
				},
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: this.clear_filter.bind(this, i+'_like')},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	this.filter_checkbox = this.filter_bool = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		return {
			tagName: 'label',
			className: ['checkbox', slim],
			attributes: {tabindex: 0},
			children: [
				{
					tagName: 'input',
					attributes: Object.assign({type: 'checkbox', name: i, value: 1, tabindex: -1}, value ? {checked: true}: {}),
					events: {change: this.list.bind(this)}
				}, {}
			]
		}
	}
	this.filter_ref = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			js_call = this.data.filters_model[i].js_call,
			js_call_filters = this.data.filters_model[i].js_call_filters || this.data.filters_model[i].filters || null,
			input_hidden, input_div

		if (js_call==='model_table_db_list_show') {
			if (!js_call_filters)
				js_call_filters = {}
			js_call_filters.model = this.data.filters_model[i].ref
		}

		if (!window[js_call] || !(window[js_call] instanceof Function))
			console.log('unknown js_call - ' + js_call)

		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/, 'w0', slim],
			children: [
				input_hidden = ce({
					tagName: 'input',
					attributes: {
						type: 'hidden',
						name: i,
						value: value,
						'value-first': value,
					},
					properties: {change: this.form_filter_submit.bind(this)},
				}),
				input_div = ce({
					className: ['flex-grow', 'input', 'pointer', 'ellipsis', 'link', slim],
					text: this.data.filters_ref_name[i] ? this.data.filters_ref_name[i] : value,
					attributes: {
						'value-first': this.data.filters_ref_name[i] ? this.data.filters_ref_name[i] : value,
						tabindex: 0,
					},
					events: {
						clickenter: window[js_call].bind(null, Object.assign({
							title: this.lang('select')+' '+this.lang(i),
							select_mode: this.data.filters_model[i].multi_select ? 2 : 1
						}, js_call_filters ? {filters: js_call_filters} : null))
					}
				}),
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: function() {
							input_hidden.value = ''
							input_div.innerHTML=''
							this.form_filter_submit()
						}.bind(this)},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	this.filter_yes_no_radio = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		return {
			className: ['flex-grow'],
			children: [{
				className: ['flex-block', 'column-3', 'between-5'],
				children: ['all', 'yes', 'no'].map((k)=>{return {
					tagName: 'label',
					className: ['radio-btn'],
					children: [
						{
							tagName: 'input',
							attributes: Object.assign({
								type: 'radio',
								name: i,
								value: k,
							}, value===k || (!value && k==='all') ? {checked: true} : null),
							events: {clickenter: this.form_filter_submit.bind(this)},
						},
						{
							className: ['btn', slim],
							text: this.lang(k),
						}
					]
				}})
			}]
		}
	}
	this.filter_radio = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			l = Object.keys(this.data.filters_model[i].select).length
		return {
			className: ['flex-grow'],
			children: [{
				className: ['flex-block', 'column-'+l, 'between-5'],
				children: Object.keys(this.data.filters_model[i].select).map((k)=>{return {
					tagName: 'label',
					className: ['radio-btn'],
					children: [
						{
							tagName: 'input',
							attributes: Object.assign({
								type: 'radio',
								name: i,
								value: k,
							}, value===k || (!value && k==='all') ? {checked: true} : null),
							events: {clickenter: this.form_filter_submit.bind(this)},
						},
						{
							className: ['btn', slim],
							text: this.lang(this.data.filters_model[i].select[k]),
						}
					]
				}})
			}]
		}
	}
	this.filter_enum_multi = function (i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			s = {items: {}},
			select_all = (checked)=>{
//				let checked = !to_bool(s.all.el.getAttribute('checked'))
//				s.all.el.setAttribute('checked', checked)
//				if (checked) {
//					s.all.el.classList.remove('transparent')
//				} else {
//					s.all.el.classList.add('transparent')
//				}
				for (let i in s.items)
					s.items[i].el.checked = checked
				this.form_filter_submit()
			}
		return {
			className: ['flex-grow'],
			children: [{
				className: ['flex-block', 'between2', 'wrap'],
				children: [
					{
						className: ['btn', 'orange', slim],
						text: this.lang('all')+' +',
//						attributes: {checked: false},
						events: {clickenter: select_all.bind(this, true)}
					},
					{
						className: ['btn', 'blue', slim],
						text: this.lang('all')+' -',
//						attributes: {checked: false},
						events: {clickenter: select_all.bind(this, false)}
					},
				].concat(Object.keys(this.data.enum[i]).map((k)=>{return {
					tagName: 'label',
					className: ['radio-btn', 'mb2'],
					children: [
						s.items[k] = {
							tagName: 'input',
							attributes: Object.assign({
								type: 'checkbox',
								name: i+'['+k+']',
								value: k,
							}, value.indexOf(k)>-1 ? {checked: true} : null),
							events: {clickenter: this.form_filter_submit.bind(this)},
						},
						{
							className: ['btn', slim],
							text: this.lang(this.data.enum[i][k]),
						}
					]
				}}))
			}]
		}
	}
	this.filter_select_ = function(i, value, select_list) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			already_translated = this.data.filters_model[i].lang,
			add_all = this.data.filters_model[i].add_all
		return {
			tagName: 'select',
			className: ['flex-grow', slim],
			attributes: {name: i},
			children: [add_all ? {tagName: 'option', attributes: {value: 'all'}, text: this.lang('all')} : null].concat(
				Object.keys(select_list).map(function(f) {return ce({
					tagName: 'option',
					attributes: Object.assign({value: f}, f===value ? {selected: true} : null),
					text: already_translated ? select_list[f] : this.lang(select_list[f]),
				})}.bind(this))
			),
			events: {change: this.form_filter_submit.bind(this)},
		}
	}
	this.filter_select = function(i, value) {
		return this.filter_select_(i, value, this.data.filters_model[i].select || {})
	}
	this.filter_yes_no = function(i, value) {
		return this.filter_select_(i, value, {all: 'all', yes: 'yes', no: 'no'})
	}
	this.filter_enum = function(i, value) {
		return this.filter_select_(i, value, Object.assign({all: 'all'}, this.data.enum[i]))
	}
	this.filter_select_record = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			select_list = this.data.filters_model[i].select || {},
			key = this.data.filters_model[i].key || 'id',
			name = this.data.filters_model[i].name || 'name'

		return {
			tagName: 'select',
			className: ['flex-grow', slim],
			attributes: {name: i},
			children: [{[key]: 'all', [name]: this.lang('all')}].concat(select_list).map(function(record) {
				return ce({
					tagName: 'option',
					attributes: Object.assign({value: record[key]}, record[key]===value ? {selected: true} : null),
					text: (this['filter_select_record_'+i] instanceof Function) ? this['filter_select_record_'+i](record) : record[name],
				})}.bind(this)),
			events: {change: this.form_filter_submit.bind(this)}
		}
	}
	this.filter_date = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			input
		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/],
			children: [
				{
					className: ['flex-grow', 'flex-block'],
					children: [
						input = {
							tagName: 'input',
							className: ['right-flat', slim],
							attributes: {
								type: 'text',
								name: i,
								value: value,
								autocomplete: 'off',
							},
						},
						{
							className: ['btn', 'icon', 'calendar', 'left-flat'],
							events: {
								click: (e)=>{yozh_calendar_popup(e, {
									value: input.el.value,
									on_select: (d)=>{input.el.value=date_to_format(d); this.form_filter_submit()}
								})}
							},
						}
					]
				},
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: this.clear_filter.bind(this, i)},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	this.filter_year_month = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null
		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/],
			children: [
				{
					className: ['flex-grow', 'flex-block'],
					children: [
						input = {
							tagName: 'input',
							className: ['right-flat', slim],
							attributes: {
								type: 'text',
								name: i,
								value: value,
								autocomplete: 'off',
							},
						},
						{
							className: ['btn', 'icon', 'calendar', 'left-flat'],
							events: {
								click: (e)=>{yozh_calendar_popup(e, {
									value: input.el.value,
									select_type: 'month',
									on_select: (d)=>{input.el.value=date_to_format(d, 'Y-m'); this.form_filter_submit()}
								})}
							},
						}
					]
				},
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: this.clear_filter.bind(this, i)},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	//-- фильтры для работы с группой дат (дата от, дата до, день, неделя, месяц, год) ---------------------------------
	this.filter_date_group_input = function(i, value, day_position) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			current = value ? format_to_date(value) : false,
			move_date = function (d_month) { // сдвигает текущую дату
				if (!current)
					return
				current = new Date(current.getFullYear(), current.getMonth()+d_month+(day_position==='to'?1:0), day_position==='to' ? 0 : 1)
				prepare_date()
			},
			prepare_date = ()=>{ // отобразить текущую дату, применить к зависимостям, обновить список
				input.el.value = current ? date_to_format(current) : ''

				if (day_position==='from' && current)
					for (let j of this.structure.filter_form.el.querySelectorAll('[date-group-'+this.data.filters_model[i].date_group+']'))
						if (j!==input.el)
							j.update_date(current, 'day')

				this.form_filter_submit()
			},
			update_date = function (d, parent_size) {
				if (parent_size==='day_one')
					current = d
				if (parent_size==='week') {
					current = day_position==='to'
						? new Date(d.getFullYear(), d.getMonth(), d.getDate()+6)	// sunday
						: d // monday
				}
				if (parent_size==='month')
					current = day_position==='to' ? new Date(d.getFullYear(), d.getMonth()+1, 0) : new Date(d.getFullYear(), d.getMonth(), 1)
				if (parent_size==='year')
					current = day_position==='to' ? new Date(d.getFullYear()+1, 0, 0) : new Date(d.getFullYear(), 0, 1)
				input.el.value = current ? date_to_format(current) : ''
			},
			input

		return {
			className: 'flex-grow flex-block between5',
			children: [
				{
					className: ['btn', 'icon', 'angle-left', slim],
					attributes: {
						tabindex: 0,
						title: '- '+this.lang('month', true),
					},
					events: {clickenter: move_date.bind(this, -1)}
				},
				{
					className: ['flex-grow', 'flex-block'],
					children: [
						input = {
							tagName: 'input',
							className: ['right-flat', slim],
							attributes: {
								type: 'text',
								name: i,
								value: value,
								autocomplete: 'off',
								['date-group-'+this.data.filters_model[i].date_group]: true,
								'date-group-role': day_position,
								'reset-fn': true
							},
							properties: {
								update_date: update_date,
								reset: ()=>{current = value ? format_to_date(value) : false}
							}
						},
						{
							className: ['btn', 'icon', 'calendar', 'left-flat', slim],
							events: {
								click: (e)=>{yozh_calendar_popup(e, {
									value: current,
									select_type: day_position==='from'?'first_day':(day_position==='to'?'last_day':'day'),
									first_day: day_position==='to' ? format_to_date(this.structure.filter_form.el.querySelector('[date-group-'+this.data.filters_model[i].date_group+'][date-group-role="from"]').value) : null,
									last_day: day_position==='from' ? format_to_date(this.structure.filter_form.el.querySelector('[date-group-'+this.data.filters_model[i].date_group+'][date-group-role="to"]').value) : null,
									on_select: (d)=>{current=d; prepare_date()}
								})}
							},
						}
					]
				},
				{
					className: ['btn', 'icon', 'angle-right', slim],
					attributes: {
						tabindex: 0,
						title: '+ '+this.lang('month', true),
					},
					events: {clickenter: move_date.bind(this, 1)}
				},
				this.data.filters_model[i].clear ? {
					className: ['btn', 'icon', 'remove', 'red', slim],
					attributes: {tabindex: 0},
					events: {clickenter: ()=>{current='';prepare_date()}}
				} : null
			]
		}
	}
	this.filter_date_group_from = function(i, value) {
		return this.filter_date_group_input(i, value, 'from')
	}
	this.filter_date_group_to = function(i, value) {
		return this.filter_date_group_input(i, value, 'to')
	}
	this.filter_date_group_day = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			current = new Date(), // значение фильтра
			current_format = function() {return date_to_format(current)}, // возвращает дату в формате
			move_date = function(delta) { // сдвигает текущую дату
				current = new Date(current.getFullYear(), current.getMonth(), current.getDate()+delta)
				prepare_date()
			},
			prepare_date = ()=>{ // отобразить текущую дату, применить к зависимостям, обновить список
				btn.el.innerHTML = current_format()
				for (let j of this.structure.filter_form.el.querySelectorAll('[date-group-'+this.data.filters_model[i].date_group+']'))
					if (j!==btn.el)
						j.update_date(current, 'day_one')
				this.form_filter_submit()
			},
			update_date = function (d, parent_size) {
				current = d
				btn.el.innerHTML = current_format()
			},
			btn

		return {
			className: 'flex-grow flex-block between5',
			children: [
				{
					className: ['btn', 'icon', 'angle-left', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('prev') + ' ' + this.lang('day', true),
					},
					events: {clickenter: move_date.bind(this, -1)}
				},
				btn = {
					className: ['flex-grow', 'btn', slim],
					text: current_format(),
					attributes: {
						title: this.lang('display')+' '+this.lang('day', true),
						['date-group-'+this.data.filters_model[i].date_group]: true,
						tabindex: 0,
					},
					properties: {update_date: update_date},
					events: {clickenter: prepare_date},
				},
				{
					className: ['btn', 'icon', 'calendar', slim],
					attributes: {title: this.lang('select')+' '+this.lang('day', true)},
					events: {
						click: (e)=>{yozh_calendar_popup(e, {
							value: current,
							on_select: (d)=>{current=d; prepare_date()}
						})}
					}
				},
				{
					className: ['btn', 'icon', 'angle-right', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('next') + ' ' + this.lang('day', true),
						tabindex: 0,
					},
					events: {clickenter: move_date.bind(this, 1)}
				},
			]
		}
	}
	this.filter_date_group_week = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			monday = (d)=>{
				let wod = (d.getDay() + 6)%7 //week of day; 0-monday, ..., 6-sunday
				return new Date(d.getFullYear(), d.getMonth(), d.getDate()-wod) // monday
			},
			current = monday(new Date()), // значение фильтра
			current_format = function() { // возвращает дату в формате недели
				if (!current)
					return '';
				let sunday = new Date(current.getFullYear(), current.getMonth(), current.getDate()+6)
				return date_to_format(current) + ' - ' + sunday.getDate()
			},
			move_date = function(d_week) { // сдвигает текущую дату
				current = new Date(current.getFullYear(), current.getMonth(), current.getDate() + (d_week*7))
				prepare_date()
			},
			prepare_date = ()=>{ // отобразить текущую дату, применить к зависимостям, обновить список
				btn.el.innerHTML = current_format()
				for (let j of this.structure.filter_form.el.querySelectorAll('[date-group-'+this.data.filters_model[i].date_group+']'))
					if (monday && j!==btn.el)
						j.update_date(current, 'week')
				this.form_filter_submit()
			},
			update_date = function (d, parent_size) {
				current = monday(d)
				btn.el.innerHTML = current_format()
			},
			btn

		return {
			className: 'flex-grow flex-block between5',
			children: [
				{
					className: ['btn', 'icon', 'angle-left', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('prev') + ' ' + this.lang('week', true),
					},
					events: {clickenter: move_date.bind(this, -1)}
				},
				btn = {
					className: ['flex-grow', 'btn', slim],
					text: current_format(),
					attributes: {
						title: this.lang('display')+' '+this.lang('week', true),
						['date-group-'+this.data.filters_model[i].date_group]: true,
						tabindex: 0,
					},
					properties: {update_date: update_date},
					events: {clickenter: prepare_date},
				},
				{
					className: ['btn', 'icon', 'calendar', slim],
					attributes: {title: this.lang('select')+' '+this.lang('week', true)},
					events: {
						click: (e)=>{yozh_calendar_popup(e, {
							value: current,
							on_select: (d)=>{current = monday(d); prepare_date()}
						})}
					}
				},
				{
					className: ['btn', 'icon', 'angle-right', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('next') + ' ' + this.lang('week', true),
					},
					events: {clickenter: move_date.bind(this, 1)}
				},
			]
		}
	}
	this.filter_date_group_month = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			current = new Date(), // значение фильтра
			current_format = function() {return current ? date_to_format(current, 'm.Y') : ''}, // возвращает дату в формате месяца
			move_date = function(d_month) { // сдвигает текущую дату
				current = new Date(current.getFullYear(), current.getMonth()+d_month, 1)
				prepare_date()
			},
			prepare_date = ()=>{ // отобразить текущую дату, применить к зависимостям, обновить список
				btn.el.innerHTML = current_format()
				for (let j of this.structure.filter_form.el.querySelectorAll('[date-group-'+this.data.filters_model[i].date_group+']'))
					if (current && j!==btn.el)
						j.update_date(current, 'month')
				this.form_filter_submit()
			},
			update_date = function (d, parent_size) {
				current = new Date(d.getFullYear(), parent_size==='year'?0:d.getMonth(), 1)
				btn.el.innerHTML = current_format()
			},
			btn

		return {
			className: 'flex-grow flex-block between5',
			children: [
				{
					className: ['btn', 'icon', 'angle-left', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('prev') + ' ' + this.lang('month', true),
					},
					events: {clickenter: move_date.bind(this, -1)}
				},
				btn = {
					className: ['flex-grow', 'btn', slim],
					text: current_format(),
					attributes: {
						title: this.lang('display')+' '+this.lang('month', true),
						['date-group-'+this.data.filters_model[i].date_group]: true,
						tabindex: 0,
					},
					properties: {update_date: update_date},
					events: {clickenter: prepare_date},
				},
				{
					className: ['btn', 'icon', 'calendar', slim],
					attributes: {title: this.lang('select')+' '+this.lang('month', true)},
					events: {
						click: (e)=>{yozh_calendar_popup(e, {
							value: current,
							select_type: 'month',
							on_select: (d)=>{current=d; prepare_date()}
						})}
					}
				},
				{
					className: ['btn', 'icon', 'angle-right', slim],
					attributes: {
						tabindex: 0,
						title: this.lang('next') + ' ' + this.lang('month', true),
					},
					events: {clickenter: move_date.bind(this, 1)}
				},
			]
		}
	}
	this.filter_date_group_year = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			current = new Date(),
			current_format = function() {return date_to_format(current, 'Y')}, // возвращает дату в формате месяца
			move_date = function(delta) { // сдвигает текущую дату
				current = new Date(current.getFullYear()+delta, 0, 1)
				prepare_date()
			},
			prepare_date = ()=>{
				btn.el.innerHTML = current_format()

				for (let j of this.structure.filter_form.el.querySelectorAll('[date-group-'+this.data.filters_model[i].date_group+']'))
					if (j!==btn.el)
						j.update_date(current, 'year')
				this.form_filter_submit()
			},
			update_date = function (d, parent_size) {
				current = new Date(d.getFullYear(), 0, 1)
				btn.el.innerHTML = current_format()
			},
			btn

		return {
			className: 'flex-grow flex-block between5',
			children: [
				{
					className: ['btn', 'icon', 'angle-left', slim],
					attributes: {
						tabindex: 0,
						title: this.lang(['prev', 'year']),
					},
					events: {clickenter: move_date.bind(this, -1)}
				},
				btn = {
					className: ['btn', 'flex-grow', slim],
					text: current_format(),
					events: {clickenter: move_date.bind(this, 0)},
					attributes: {
						title: this.lang(['display', 'year']),
						['date-group-'+this.data.filters_model[i].date_group]: true,
					},
					properties: {update_date: update_date}
				},
				{
					className: ['btn', 'icon', 'calendar', slim],
					attributes: {title: this.lang(['select', 'year'])},
					events: {
						click: (e)=>{yozh_calendar_popup(e, {
							value: current,
							select_type: 'year',
							on_select: (d)=>{current=d; prepare_date()}
						})}
					}
				},
				{
					className: ['btn', 'icon', 'angle-right', slim],
					attributes: {
						tabindex: 0,
						title: this.lang(['next', 'year']),
					},
					events: {clickenter: move_date.bind(this, 1)}
				},
			]
		}
	}

}

function table_popup_class() {
	Object.assign(this.data, {
		popup_mode:			false,
		call_width:			1200,
		select_mode:		false,	// 1 одну запись, 2 много записей
		select_fn:			null,	// вызываем функцию и передаем туда выбранные записи (список объектов, даже если не multi_select )
		call_btn:			null,	// кнопка, по которой было вызвано this.show
	})

	let show_parent = this.show
	this.show = async function(show_data={}) {
		if (!this.structure.table_frame) {
			this.data.popup_mode = true
			this.popup = yozh_popup({
				width: this.data.call_width,
				fn_after_close: () => { if (this.tooltip) { this.tooltip.tooltip_box.remove(); delete this.tooltip;}}
			})
			this.popup.content.el.classList.add('flex-grow', 'flex-block', 'column', 'h100p')
			this.structure.table_frame = this.popup.content
		}

		if (show_data.select_mode>1)
			show_data.multi_select = true

		await show_parent.call(this, show_data)

		if (this.popup) {
			move_handle(this.popup.frame.el, this.structure.header_title.el)
			this.popup.show()
		}
	}

	let build_structure_parent = this.build_structure
	this.build_structure = function() {
		let structure = build_structure_parent.call(this)

		if (this.data.popup_mode) {
			this.structure.header_line.className.push('table-header', 'pr30')

			// header_title
			this.structure.header_title.text = this.data.title
			delete this.structure.header_title.children

			// two_col
			this.structure.two_col.className.push('overflow')
			this.structure.two_col.className.splice(this.structure.two_col.className.indexOf('h0'), 1)
		}

		return structure
	}

	//-- select --------------------------------------------------------------------------------------------------------
	let build_tr_parent = this.build_tr
	this.build_tr = function (record) {
		let s = build_tr_parent.call(this, record)

		if (this.data.select_mode>0) {
			if (!s.events)
				s.events = {}
			s.events.click = (e)=>{
				if (!e.yozh_row_no_select) {
					if (this.data.select_mode===1) {
						this.return_record(record)
					} else {
						let chekbox = s.el.querySelector('input[select_record]')
						chekbox.checked = !chekbox.checked
						this.select_record(record/*, s*/)
					}
				}
				delete e.yozh_row_no_select
			}
		}

		return s
	}
	let build_td_parent = this.build_td
	this.build_td = function(record, field_name) {
		let td_structure = build_td_parent.call(this, record, field_name)

		if (field_name!=='functions' && this.data.select_mode>0) {
			td_structure.className.push('pointer')
			delete td_structure.events.click
			delete td_structure.events.clickenter
			delete td_structure.events.link_click
			delete td_structure.events.wheelclick
			delete td_structure.events.mousedown
			delete td_structure.events.mouseup
/*
			if (this.data.select_mode===1) {
				td_structure.events.click = this.return_record.bind(this, record)
			} else {
				td_structure.events.click = () => {
					let checbox = td_structure.el.closest('tr').querySelector('input[select_record]')
					checbox.checked = !checbox.checked
					this.select_record(record/*, td_structure* /)
				}
			}
*/		}

		return td_structure
	}

	let build_th_parent = this.build_th
	this.build_th = function (field_name) {
		let th_structure = build_th_parent.call(this, field_name)

		if (field_name==='functions')
			if (this.data.select_mode===2) { // select_mode - multiple
				this.structure.selected_count.className = ['flex-grow', 'a-center', 'btn', 'icon', 'icon-right-h24', 'hand-pointer-o', this.data.selected_records_count ? 'orange' : 'disabled']
				this.structure.selected_count.events = {clickenter: this.return_records.bind(this)}
				this.structure.selected_count.attributes.title = this.lang('select')
			}

		return th_structure
	}

	let show_selected_records_parent = this.show_selected_records
	this.show_selected_records = function() {
		show_selected_records_parent.call(this)

		if (this.data.select_mode===2)
			if (this.data.selected_records_count>0) {
				this.structure.selected_count.el.classList.remove('disabled')
				this.structure.selected_count.el.classList.add('orange')
			} else {
				this.structure.selected_count.el.classList.remove('orange')
				this.structure.selected_count.el.classList.add('disabled')
			}
	}

	this.call_btn_return = function (record_list, event) { // если список вызван от простой кнопки (функция по-умолчанию)
		let input_block = this.data.call_btn.closest('.input-block') || this.data.call_btn.parentNode,
			a = Object.keys(record_list),
			l = a.length,
			el

		if (el = input_block.querySelector('input[type="hidden"]')) {
			el.value = a.map((i)=>{return record_list[i].id}).join(',')
			if (el.change instanceof Function)
				el.change()
		}

		if (el = input_block.querySelector('.input.link')) {
			el.innerHTML = a.map((i)=>{return this.record_name(record_list[i])}).join(', ')
			el.focus()
		}

		if (el = input_block.querySelector('.btn.info'))
			l > 0 ? el.classList.remove('disabled') : el.classList.add('disabled')

		if (el = input_block.querySelector('a.btn.download')) {
			if (l > 0 && a[0].url) {
				el.href = a[0].url
				el.target = '_blank'
				el.classList.remove('disabled')
			} else {
				el.href = 'javascript: void(0)'
				el.target = '_self'
				el.classList.add('disabled')
			}
		}

		if (el = input_block.querySelector('.btn.remove'))
			l > 0 ? el.classList.remove('disabled') : el.classList.add('disabled')
	}

	this.return_record = function (record, event) { // вернуть одну запись
		this.popup.close(event)

		if (this.data.select_fn instanceof Function) {
			this.data.select_fn({[record.id]: record}, event)
			return
		}

		if (this.data.call_btn)
			this.call_btn_return({[record.id]: record}, event)
	}

	this.return_records = function (event) { // вернуть несколько записей
		if (!this.data.selected_records_count)
			return

		this.popup.close(event)

		if (this.data.select_fn instanceof Function) {
			this.data.select_fn(this.data.selected_records, event)
			return
		}

		if (this.data.call_btn)
			this.call_btn_return(this.data.selected_records, event)
	}
}

function table_call_class() {
	table_class.call(this)
	table_formatter_class.call(this)
	table_filter_class.call(this)
	table_popup_class.call(this)
	if (typeof custom_table_class !== 'undefined')
		custom_table_class.call(this)
}