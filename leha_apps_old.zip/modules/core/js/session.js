function session_class() {
	table_call_class.call(this)

	this.data.title_icon = 'user'
	this.list_url	= 'core/session/list_ajax'
	this.edit_url	= 'core/session/edit_ajax'
	this.del_url	= 'core/session/delete_ajax'
	this.clear_url	= 'core/session/clear_ajax'

	this.data.multi_select = true

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		let action_icons = create_action_icons_parent.call(this)
		action_icons.splice(0, 1)
		action_icons.push(
			this.root_access ? {
				className: ['btn', 'icon', 'remove'],
				attributes: {title: this.lang('clear_old')},
				events: {clickenter: this.clear.bind(this)}
			}:null
		)
		return action_icons;
	}

	//-- multi delete --------------------------------------------------------------------------------------------------
	let build_th_parent = this.build_th
	this.build_th = function (field_name, el) {
		let td_structure =  build_th_parent.call(this, field_name)
		if (field_name==='functions') // multi_select
			td_structure.children[0].children.splice(1, 0, {
				className: ['btn', 'icon', 'del', 'red'],
				events: {clickenter: this.del_list.bind(this)}
			})
		return td_structure
	}
	this.del_list = function(e) {
		let record_id_list = Object.keys(this.data.selected_records)
		if (record_id_list.length===0)
			return
		this.del(null, e, {
			data_compiler: function(data){return {item_id: record_id_list}},
			on_success: function(){this.data.selected_records = {}; this.data.selected_records_count=0;}.bind(this)
		})
	}

	//------------------------------------------------------------------------------------------------------------------
	this.clear = function () {
		yozh_fetch({
			url: script_url+this.clear_url,
			on_success_fn: function(response_data, textStatus) {
				this.list()
			}.bind(this)
		})
	}
}

function session_list_show(data, event) {
	if (event) data.call_btn = event.target
	new session_class().show(data)
}
