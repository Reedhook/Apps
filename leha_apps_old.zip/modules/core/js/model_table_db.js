function model_table_db_class() {
	table_call_class.call(this)

	this.data.call_icon = 'list'
	this.edit_url	= 'core/model_table_db/edit_ajax'
	this.del_url	= 'core/model_table_db/delete_ajax'
	this.list_url	= 'core/model_table_db/list_ajax'
	this.edit_field_url	= 'core/model_table_db/edit_field_ajax'

	let td_formatter_icons_parent = this.td_formatter_icons
	this.td_formatter_icons = function(field_name, record, el) {
		td_formatter_icons_parent.call(this, field_name, record, el)

		if (!this.admin_access)
			el.children[0].children.splice(0, 3, {className: 'btn icon empty'}, {className: 'btn icon empty'}, {className: 'btn icon empty'})
	}

	let create_action_icons_parent = this.create_action_icons
	this.create_action_icons = function () {
		return this.admin_access ? create_action_icons_parent.call(this) : []
	}

	let edit_data_compile_parent = this.edit_data_compile
	this.edit_data_compile = function(record) {
		return Object.assign(
			edit_data_compile_parent.call(this, record),
			{model: this.data.filters.model}
		)
	}

	let del_data_compile_parent = this.del_data_compile
	this.del_data_compile = function(record) {
		return Object.assign(
			del_data_compile_parent.call(this, record),
			{model: this.data.filters.model}
		)
	}

	let edit_field_data_compile_parent = this.edit_field_data_compile
	this.edit_field_data_compile = function (field_name, record, value) {
		return Object.assign(
			edit_field_data_compile_parent.call(this, field_name, record, value),
			{model: this.data.filters.model}
		)
	}
}

function model_table_db_list_show(data, event){
	if (event) data.call_btn = event.target
	new model_table_db_class().show(data)
}
