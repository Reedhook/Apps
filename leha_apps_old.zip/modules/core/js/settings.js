function settings_class() {
	table_call_class.call(this)

	this.data.call_width = 800
	this.data.title_icon = 'cog'

	this.build_structure = function() {
		let structure = [
			this.structure.header_line = {
				className: ['flex-block', 'between', 'bottom'],
				children: [
					this.structure.header_title = { // заголовок окна
						className: ['flex-grow', 'table-row', 'ellipsis'].concat(this.data.title_icon ? ['icon', 'icon-left', this.data.title_icon] : null),
						children: [{
							tagName: 'h1',
							text: this.data.title,
						}],
					},
					this.structure.action_box = {
						className: ['table-row', 'flex-block', 'between2'],
					}
				],
			},
		]

		if (this.data.popup_mode) {
			this.structure.header_line.className.push('table-header', 'pr30')

			// header_title
			this.structure.header_title.className.push('table-row')
			if (this.data.title_icon)
				this.structure.header_title.className.push('icon-left-h30')

			structure.push(this.structure.table_box={
				className: ['scroll'],
			})
		} else {
			this.structure.header_title.tagName = 'h1'

			if (this.data.title_icon)
				this.structure.header_title.className.push('icon-left')

			structure.push({
				className: ['flex-grow', 'h0', 'mauto', 'w-max800'],
				children: [
							this.structure.table_box={
								className: ['shadow', 'scroll', 'w100p']
							}
				]
			})
		}

		return structure
	}
	this.update_list = function() {
		// clear table
		while(this.structure.table_box.el.firstChild)
			this.structure.table_box.el.firstChild.remove()

		// clear table
		el_add_children(this.structure.table_box.el, this.build_table())

		if (!this.tooltip)
			this.tooltip = new yozh_tooltip()
		this.tooltip.set(this.structure.table_frame.el)
	}
	this.build_table = this.build_rows = function() {
		return this.data.records.map(this.build_tr.bind(this))
	}
	this.build_tr = function (record) {
		let change_log_filters = record.id>0 ? Object.assign({record_id: record.id}, this.action_history_filters()) : null

		record.structure = {}
		return record.structure.row = {
			className: ['table-row', record.type==='group'?'header':'color', 'flex-block', 'between5', 'input-block'],
			children: [
				{
					className: ['flex-grow', 'flex-block', 'between5'],
					children: [
						{
							className: ['flex-grow'],
							text: this.lang(record.name)
						},
						record.notification ? {
							className: ['btn', 'circle', 'icon', 'info'],
							attributes: {tabindex: 0},
							events: {clickenter: ()=>yozh_notify({text: record.notification})}
						} : null,
					]
				}
			].concat(record.type==='group'?null:[
				{
					className: ['w200'],
					text: record.name
				},
				{
					className: ['w200', 'flex-block', 'between5'],
					children: [
						record.structure.view_input = {
							className: ['flex-grow', 'pointer', record.type==='ref'?'link': null].concat(record.type==='text'?['textarea']:['input', 'ellipsis']),
							text: record.value_str,
							attributes: {tabindex: 0},
							events: {clickenter: this.edit.bind(this, record)}
						},
						record.type==='ref'?{
							className: ['btn', 'icon', 'remove', 'red'],
							attributes: {tabindex: 0},
							events: {clickenter: this.edit_save.bind(this, record, {data: {
								action: 'save',
								name: record.name,
								value: 0,
							}})}
						} : null,
						record.structure.history_btn = record.id>0 ? {
							tagName: 'a',
							className: ['btn', 'icon', 'history'],
							attributes: {
								title: this.lang('edit_history'),
								target: '_blank',
								href: script_url+'core/change_log/start/'+encodeURIComponent(JSON.stringify(change_log_filters)),
							},
							events: {link_click: change_log_list_show.bind(null, {
								filters: change_log_filters,
								title: this.lang(record.name) +' - ' + this.lang('edit_history')
							})}
						} : {className: ['btn', 'icon', 'history', 'disabled']}
					],
				}
			]),
		}
	}

	this.create_action_icons = function() {
		return []
	}

	this.edit = async function(record) {
		if (record.type==='ref') {
			if (record.js_call==='model_table_db_list_show') {
				if (!record.js_call_filters)
					record.js_call_filters = {}
				if (!record.js_call_filters.model)
					record.js_call_filters.model = record.ref
			}

			window[record.js_call]({
				title: 'Select',
				filters: record.js_call_filters || null,
				select_fn: async (records)=> {
					this.edit_save(record, {data: {
						action:	'save',
						name:	record.name,
						value:	records ? Object.keys(records)[0] : null
					}})
				},
				select_mode: 1,
			})
			return
		}

		let popup = yozh_popup({width: 400}),
			response_data = await yozh_fetch({
				url: script_url + this.edit_url,
				data: {name: record.name,},
			}),
			edit_data = response_data.edit_data,
			structure = {}
		edit_data.input_list = {}

		structure.form = {
			tagName: 'form',
			className: 'flex-block column h100p',
			attributes: {method: 'post', action: 'javascript: void(0)'},
		}
		structure.form.children = [
			{
				tagName: 'input',
				attributes: {type: 'hidden', name: 'action', value: 'save'}
			},
			{
				tagName: 'input',
				attributes: {type: 'hidden', name: 'name', value: edit_data.name}
			},
			structure.header = {
				className: 'table-header',
				children: {
					className: 'table-row',
					text: edit_data.lang[edit_data.name]
				}
			},
			{
				className: "flex-grow flex-block column scroll",
				children: {
					className: 'table-row color input-block',
					children: build_edit_form_input(edit_data, 'value')
				}
			},
			{
				className: ['table-row', 'header', 'flex-block', 'right'],
				children: [
					structure.btn_save = {
						className: 'btn',
						attributes: {tabindex: 0},
						text: this.lang('save'),
						events: {clickenter: this.edit_save.bind(this, record, {popup: popup, form: structure.form})},
					}
				]
			}
		]

		popup.set(structure.form)
		move_handle(popup.frame.el, structure.header.el)

		popup.show()
	}

	this.edit_save = async function(record, o) {
		if (o.popup)
			o.popup.frame.el.wait()

		let response_data = await yozh_fetch({
			url: script_url + this.edit_url,
			data: o.data || get_form_data(o.form.el) || {},
		})

		if (response_data.success) {
			this.show_new_value(record, response_data.value_str)
			if (o.popup)
				o.popup.close()
		} else {
			if (o.form)
				form_show_errors(o.form.el, response_data)
			if (o.popup)
				o.popup.frame.el.wait(false)
		}
	}

	this.get_filters = function () {
		return {}
	}
	this.show_new_value = function (record, value) {
		while (record.structure.view_input.el.firstChild)
			record.structure.view_input.el.firstChild.remove()
		el_add_children(record.structure.view_input.el, value)
	}
}
