function player(options={}) {
	this.document_player_name = options.document_player_name || 'player'
	document[this.document_player_name] = this

	this.current_player = false		// плеер, который сейчас играет
	this.broadcast_channel = new BroadcastChannel('broadcast_channel_player')
	this.broadcast_channel.addEventListener('message', ({data, origin}) => {
		if (data.status==='play')
			this.player_pause(this.current_player)
	})

	this.play = function () { // play/pause
		if (this.current_player) {
			if (this.current_player.paused) {
				this.player_play(this.current_player)
			} else {
				this.player_pause(this.current_player)
			}
		}
	}

	this.pause = function() {
		if (this.current_player)
			if (!this.current_player.paused)
				this.player_pause(this.current_player)
	}

	this.close = async function() { // закрыть плеер
		if (this.current_player) {
			this.player_delete(this.current_player)
		}
		this.player_box.el.remove()
		delete document[this.document_player_name]
		this.broadcast_channel.close()
		delete this.broadcast_channel
	}

	// track {id, url, file_type[audio|video|radio|image|waiting], name, author, duration_sec(image), waiting_time(waiting)}
	this.play_track = function (track) {
		if (this.current_player) {
			if (this.current_player.track.id===track.id) {
				this.play()
				return
			}

			this.player_delete(this.current_player)
			delete this.current_player
		}

		this.current_player = this.player_create(track) // создать плеер
		this.player_play(this.current_player) // и начать его проигрывать
	}

	this.build_dom = function () {
		this.btn = {}
		this.player_box = {
			parentNode: this.parentNode || document.body,
			className: 'player',
			children: [
				this.visual_box = {
					className: 'visual-box',
				},
				{
					className: 'panel-box',
					children: [this.panel_box = {
						className: ['player-panel'],
						children: [
							{
								className: 'flex-block between10',
								children: [
									this.btn.like = {
										className: 'btn icon heart-o display-none',
										events: {click: this.like_track.bind(this)},
									},
//									this.btn_prev = {
//										className: 'btn icon step-backward disabled',
//										events: {click: this._btn_prev.bind(this)},
//									},
									this.btn.play = {
										className: 'btn icon play disabled',
										events: {click: this.play.bind(this)},
									},
//									this.btn.next = {
//										className: 'btn icon step-forward display-none',
//										events: {click: this._btn_next.bind(this)},
//									},
									{
										className: "flex-grow flex-block between relative",
										children: [
											{
												className: "flex-block between10",
												children: [
												this.btn.track_name = {},
													this.btn.track_author_name = {className: 'flex-grow'},
												]
											},
											this.btn.time_value = {},
											this.btn.time_line = {
												className: 'line-box flex-grow',
												children: [this.btn.time_line_cursor = {className: 'value-cursor'}],
												events: {click: this._time_line_down.bind(this)}
											},
										]
									},
									this.btn.mute = {
										className: 'btn icon volume-up disabled',
										events: {click: this._btn_mute.bind(this)},
									},
									{
										className: "relative w80",
										children: [
											this.btn.volume_value = {},
											this.btn.volume_line = {
												className: 'line-box hover',
												children: [this.btn.volume_line_cursor = {className: 'value-cursor'}],
												events: {mousedown: this._volume_line_down.bind(this)}
											},
										],
									}

								],
							},
							{
								className: 'popup-close',
								events: {click: this.close.bind(this)}
							}
						]
					}],
				},
			]
		}

		this.customize_build_dom()
		ce(this.player_box)

		this.addEventListener = this.player_box.el.addEventListener.bind(this.player_box.el)
		this.removeEventListener = this.player_box.el.removeEventListener.bind(this.player_box.el)
	}
	this.customize_build_dom = function() {

	}
/*	this._btn_prev = function() {
		if (!this.current_player)
			return
		if (this.current_player.track.file_type==='radio')
			return
		if (this.get_prev_track instanceof Function)
			this.get_prev_track(this.track, this.order, this.play_track.bind(this))
	}
*/	this._btn_next = async function () {
		if (!this.current_player)
			return

		if (['radio', 'waiting'].indexOf(this.current_player.track.file_type)!==-1)
			return

		if (this.get_next_track instanceof Function) {
			let track = await this.get_next_track(this.current_player)
			if (track) {
				this.play_track(track)
			}
		}

	}
	//-- volume --------------------------------------------------------------------------------------------------------
	this._time_line_down = function(event) {
		if (this.current_player)
			this.current_player.currentTime = parseInt(this.current_player.duration*(event.offsetX/this.btn.time_line.el.offsetWidth))
	}

	this._show_time = function (player) {
		let k = 0
		//,pos_old = this.btn.time_line_cursor.el.offsetWidth,


		if (player.track.hasOwnProperty('waiting_time')) {
//			player.wave_position += .2
//			if (player.wave_position > Math.PI*2)
//				player.wave_position = 0
			k = 0//.5 - Math.cos(player.wave_position)*.5
		} else if(player.duration>0) {
			k = player.currentTime/player.duration
		}

		let pos_new = (this.btn.time_line.el.offsetWidth*k).toFixed(2)
//		if (Math.abs(pos_new-pos_old)>this.btn.time_line.el.offsetWidth/4) {
//			this.btn.time_line_cursor.el.classList.remove('smoothly')
//		} else {
//			this.btn.time_line_cursor.el.classList.add('smoothly')
//		}
		this.btn.time_line_cursor.el.style.width = pos_new + 'px'


		this.btn.time_value.el.innerHTML = this.int_to_time(player.currentTime) +
			(player.duration ? '/' + this.int_to_time(player.duration) : '')
	}

	//-- volume --------------------------------------------------------------------------------------------------------
	this._btn_mute = function () {
		if (!this.current_player)
			return
		if (this.current_player.track.file_type==='audio' || this.current_player.track.file_type=='video' || this.current_player.track.file_type==='radio') {
			this.current_player.muted = !this.current_player.muted
		}
		this._show_volume()
	}

	this._volume_line_mouse_event = function(e) {
		let x = e.target.getBoundingClientRect().left + e.offsetX - this.btn.volume_line.el.getBoundingClientRect().left

		if (this.current_player) {
			var v = x/(this.btn.volume_line.el.offsetWidth)
			if (v<0)
				v=0
			if (v>1)
				v=1
			this.current_player.volume = v
			this._show_volume(this.current_player)
		}
	}

	this._volume_line_down = function(e) {
		document.addEventListener('mouseover', this._volume_line_over)
		document.addEventListener('mouseup', this._volume_line_up)
		document.addEventListener('mouseleave', this._volume_line_up)
		this._volume_line_mouse_event(e)
	}
	this._volume_line_over = function(e) {
		this._volume_line_mouse_event(e)
	}.bind(this)
	this._volume_line_up = function(e) {
		document.removeEventListener('mouseover', this._volume_line_over)
		document.removeEventListener('mouseup', this._volume_line_up)
		document.removeEventListener('mouseleave', this._volume_line_up)
	}.bind(this)

	this._show_volume = function (player) {
		var muted = true
		if (this.current_player.track.file_type==='audio' || this.current_player.track.file_type=='video' || this.current_player.track.file_type==='radio') {
			muted = this.current_player.muted
		}

		if (muted) {
			this.btn.mute.el.classList.remove('volume-up')
			this.btn.mute.el.classList.add('volume-off')
			this.btn.volume_value.el.classList.add('c-disabled')
		} else {
			this.btn.mute.el.classList.remove('volume-off')
			this.btn.mute.el.classList.add('volume-up')
			this.btn.volume_value.el.classList.remove('c-disabled')
		}

		this.btn.volume_line_cursor.el.style.width = (this.btn.volume_line.el.offsetWidth * this.current_player.volume).toFixed(2)+'px'
		this.btn.volume_value.el.innerHTML = Math.round(this.current_player.volume*100)+'%'
	}
	//------------------------------------------------------------------------------------------------------------------

	this.show_track_info = function() {
		if (this.current_player.title_shown_fl)
			return

		this.btn.track_name.el.innerHTML = this.current_player.track.name || ''
		this.btn.track_author_name.el.innerHTML = this.current_player.track.author || ''

		this.current_player.title_shown_fl = true
	}

	this.int_to_time = function (n) {
		if (isNaN(n))
			n = 0
		if (n === Infinity)
			return '&infin;'
		n = Math.round(n)
		var s = n%60,
			i_totoal = Math.round((n-s)/60)
		i = i_totoal%60,
			h = Math.round((i_totoal-i)/60)
		return (h>0?(h<10?'0'+h:h)+':':'')+(i<10?'0'+i:i)+':'+(s<10?'0'+s:s)
	}
//	this.time_to_int = function (s) {
//		var l = s.split(':')
//		return parseInt(l[0])*3600 + parseInt(l[1])*60 + parseInt(l[2])
//	}

	this.like_track = async function () {
		if (this.current_player || this.current_player.track.on_like instanceof Function) {
			this.current_player.track.on_like()
//			this.current_player.track.like = await this.current_player.track.on_like()
//			this.show_btn()
		}
	}

	this.on_change_status = function (player) {// изменяем статус кнопок
		this.dispatch_status({
			status: player.paused ? 'pause' : 'play',
			track: player.track,
		})

		if (this.current_player && this.current_player===player)
			this.show_btn()
	}
	this.dispatch_status = function (data) {
		let playerChangeStatusEvent = new Event('playerChangeStatus', {bubbles: true, cancelable: true})
		Object.assign(playerChangeStatusEvent, data)
		this.player_box.el.dispatchEvent(playerChangeStatusEvent)
		if (this.broadcast_channel)
			this.broadcast_channel.postMessage(JSON.parse(JSON.stringify(data)))
	}

	this.show_btn = function () {// изменяем статус кнопок
		let status = this.current_player && this.current_player.paused ? 'pause' : 'play'
/*		if (this.current_player
			&& ['radio', 'waiting'].indexOf(this.current_player.track.file_type)!==-1
		) {
			this.btn.prev.el.classList.add('disabled')
			this.btn.next.el.classList.add('display-none')
		} else if (this.get_next_track instanceof Function) {
			this.btn.prev.el.classList.remove('disabled')
			this.btn.next.el.classList.remove('display-none')
		}
*/
		if (status === 'play') {
			this.btn.play.el.classList.remove('play', 'disabled')
			this.btn.play.el.classList.add('pause')
		} else {
			this.btn.play.el.classList.remove('pause', 'disabled')
			this.btn.play.el.classList.add('play')
		}

		this.btn.mute.el.classList.remove('disabled')

/*		let cl = this.btn.like.el.classList
		if (this.current_player && this.current_player.track.on_like instanceof Function) {

			cl.remove('display-none')
			let like = Number(this.current_player.track.like)
			if (like===0) {
				cl.add('heart')
				cl.add('c-black')
				cl.remove('heart-o')
			} else if (like===-1) {
				cl.add('heart-o')
				cl.remove('heart')
				cl.remove('c-black')
			} else if (like>0) {
				cl.add('heart')
				cl.remove('heart-o')
				cl.remove('c-black')
			}

		} else {
			cl.add('display-none')
		}
*/	}

	this.player_create = function (track, options={}) {
		let player_properties = {
			autoplay: false,
			volume: options.hasOwnProperty('volume') ? options.volume : (this.current_player ? this.current_player.volume : 1),
			preload: 'auto',
			track: track,
		}

		if (!player_properties.track)
			return false

		player_properties.src = track.url || false

		let player_events = {
//			loadeddata:	this._track_loadeddata.bind(this),
			error:		this.on_error.bind(this),
			play:		this.on_play.bind(this),
			pause:		this.on_pause.bind(this),
			ended:		this.on_ended.bind(this),
			timeupdate:	this.on_timeupdate.bind(this),
		}

		if (player_properties.track.file_type==='audio' || player_properties.track.file_type==='video')
			return ce({
				className: 'display-none',
				parentNode: this.visual_box.el,
				tagName: player_properties.track.file_type,
				events: player_events,
				properties: player_properties
			})
		if (player_properties.track.file_type==='radio')
			return ce({
				className: 'display-none',
//				parentNode: iframe.ownerDocument.body,
				parentNode: this.visual_box.el,
				tagName: 'audio',
				events: player_events,
				properties: player_properties
			})
		if (player_properties.track.file_type==='image')
			return div_to_player(ce({
				className: 'display-none',
//				className: 'image_player',
				parentNode: this.visual_box.el,
				styles: {backgroundImage: 'url('+track.url+')', width: '100%', height: '100%'},
				events: player_events,
				properties: player_properties
			}))
		if (player_properties.track.file_type==='waiting') {
			//player_properties.track.waiting_time = format_to_date('22.04.2022 15:00:00', {format: datetime_format})
			if (!player_properties.track.hasOwnProperty('waiting_time'))
				return false
//			player_properties.wave_position = 0
			return div_to_player(ce({
				className: 'display-none',
				parentNode: this.visual_box.el,
				events: player_events,
				properties: player_properties
			}))
		}

		return false
	}

	//-- методы для работы с плеерами ----------------------------------------------------------------------------------
	this.player_play = function (player) {// запускает и показывает плеер
		if (player.track.file_type==='audio' || player.track.file_type==='video' || player.track.file_type==='radio') {
			// chrome errors https://developers.google.com/web/updates/2017/06/play-request-was-interrupted
			let playPromise = player.play()
			if (playPromise !== undefined) {
				playPromise.then(_ => {// Automatic playback started! Show playing UI.
				}).catch(error => {// Auto-play was prevented // Show paused UI.
				})
			}
		} else {
			player.play()
		}

		this.player_show(player)
	}

	this.player_show = function(player) {// показывает плеер
		if (this.is_visual(player)) {
			player.classList.remove('display-none')
			this.player_box.el.classList.add('visual-mode')
		} else {
			this.player_box.el.classList.remove('visual-mode')
		}

//		if (player.track.file_type==='video')
//			player.style.display = 'block'
//		if (player.track.file_type==='image' && player.div)
//			player.div.style.display = 'block'
	}
	this.is_visual = function(player) {
		return player.track.file_type==='video' || player.track.file_type==='image'
	}

	this.player_pause = function(player) {
		player.pause()

		if (player.track.file_type==='radio') {
			player.preload = 'none'
			player.src = false
			this.on_change_status(player)
		}

//		if (player.track.file_type==='video')
//			this.player_box.el.classList.remove('visual-mode')
//		if (player.track.file_type==='image')
//			if (player.div)
//				this.player_box.el.classList.remove('visual-mode')
	}

	this.player_delete = function (player) {
		player.pause()
		player.remove()
	}

	this.player_set_volume = function(player, volume) { // устанавливает звук для плеера
		if (['audio', 'radio', 'video'].indexOf(player.track.file_type)!==-1)
			if (player.volume!=volume)
				player.volume = volume
	}

	//-- events --------------------------------------------------------------------------------------------------------
	this.on_error = function (e) {
		var player = e.target
		if (player.error.code === 4) {
			alert ('upload file error')
		} else {
			if (!player.error.code || player.error.code!==2)
				console.log(player.error)
		}
	}

/*	this._track_loaded_data = function (e) { // срабатывает, когда файл подгрузился к плееру
		var player = e.target
		if (player.options.play_on_load)
			player.play()
	}
*/
	this.on_play = function (e) { // срабатывает, когда плеер начал играть
		this.on_change_status(e.target)
		this.show_track_info()
	}

	this.on_pause = function (e) { // событие плеера на паузу
		var player = e.target
		this.on_change_status(player)
	}

	this.on_ended = function (e) {
		var player = e.target
		player.timeupdating_fl = false
		player.currentTime = 0
		this.on_timeupdate(e)

//		this._btn_next()
//		this.player_delete(player)
	}

	this.on_timeupdate = function (e) { // вызывается во время проигрывания
//		var now = new Date().getTime()/1000
		var player = e.target
		if (player.timeupdating_fl)
			return
		player.timeupdating_fl = true
		player.timeLeft = player.duration - player.currentTime

		if (this.current_player===player) {
			this._show_time(player) // показать время для плеера
			this._show_volume() // показать громкость плеера
		}

		player.timeupdating_fl = false
	}

	//-- init ----------------------------------------------------------------------------------------------------------
	this.init = function () {
		this.build_dom()
	}

	if (!options.no_init)
		this.init()
}

function div_to_player(el) {
	Object.assign(el, {
		duration:		el.track.duration_sec,
		currentTime:	0,
		muted:			true,
		volume:			0,
		paused:			true,

		interval_id:	false,

		play:			function () {
			this.paused = false
			this.interval_time = new Date().getTime() // время, когда последний раз выполнялся setInterval
			if (!this.interval_id) {
				this.interval_id = setInterval(function () {
//					this.left_time = this.interval.time_end_js - new Date()
					let t = new Date().getTime()
					this.currentTime += (t-this.interval_time)/1000
					this.interval_time = t

					if (this.track.waiting_time) { //-- waiting ----------------------------------------------------
						this.duration = (this.track.waiting_time - t)/1000

						if (this.duration<=0) {
							clearInterval(this.interval_id)
							this.interval_id = null

							this.duration = 0
							this.paused = true
							this.dispatch_event('pause')
							this.dispatch_event('ended')
						} else {
							this.dispatch_event('timeupdate')
						}
					} else { //-- usual player -------------------------------------------------------------------------
						if (this.duration>0 && this.currentTime>=this.duration) {
							clearInterval(this.interval_id)
							this.interval_id = null

							this.currentTime = 0
							this.paused = true
							this.dispatch_event('pause')
							this.dispatch_event('ended')
						} else {
							this.dispatch_event('timeupdate')
						}
					}
				}.bind(this), 1000)
			}
			this.dispatch_event('play')
		},
		pause:			function () {
			if (this.paused) {
			} else {
				if (this.interval_id)
				clearInterval(this.interval_id)
				this.interval_id = false
				this.paused = true
				this.dispatch_event('pause')
			}
		},
		dispatch_event: function (event_name, data={}) {
			let custom_event = new Event(event_name, {bubbles: true, cancelable: true})
//			custom_event.target = this.div
			Object.assign(custom_event, data)
			this.dispatchEvent(custom_event)
		}
	})
	return el
}
