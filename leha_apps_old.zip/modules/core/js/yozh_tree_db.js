function yozh_tree_db (owner_o, options) {
	this.tree_o = null;

	this.get_node = function(node_data) {
		if (node_data==this.tree_o) // only for add root element
			return node_data;

		if (node_data instanceof Element) {
			if (node_data.classList.contains('yozh-tree-node'))
				return node_data;
			return node_data.closest('.yozh-tree-node');
		}
		if (typeof (node_data)=='number') {
			return this.tree_o.querySelector('[item_id="'+node_data+'"]');
		}
		if (typeof (node_data)=='string') {
			return this.tree_o.querySelector('[item_id="'+node_data+'"]');
		}
		if (typeof (node_data.item_id)!=='undefined') {
			return this.tree_o.querySelector('[item_id="'+node_data.item_id+'"]');
		}
	}

	this.create_node = function(parent_node, data) {
		if (typeof(data.level)==='undefined')
			data.level = parent_node.classList.contains('level-even') ? 1 : 2
		var draggable = data.level>0 && options.draggable;
		var node = {
			parentNode: this.get_node(parent_node),
			className: [
				'yozh-tree-node',
				data.level%2==0 ? 'level-even' : null,
				options.expanded ? 'node-expanded' : null
			],
			attributes: {'item_id': data.id},
			properties: {},
			children: (options.custom_fn ? options.custom_fn(data) : []).concat([
				{
					className: ['yozh-tree-node-handler', draggable ? 'draggable': null],
					properties: {draggable: draggable},
					events: {
						dragstart: options.draggable ? this.dragStart.bind(this) : null,
						dragend: options.draggable ? this.dragEnd.bind(this) : null
					},
				},
				draggable ? {className: 'yozh-tree-drag-target-insert-before'} : null,
				options.draggable ? {className: 'yozh-tree-drag-target-append-child'} : null,
				{
					className: 'icon-node-expand',
					events: {click: this.expand_node.bind(this, data.id, undefined)}
				},
			])
		}

		if (options.node_fn)
			options.node_fn(node, data)
//console.log(node)
		node = ce(node)
		if (data.children)
			this.add_children(node, data.children);
		return node;
	}

	this.add_children = function(item_id, data_list) {
		var node = this.get_node(item_id);
		for (var i in data_list)
			this.create_node(node, data_list[i])

		if (typeof(i)!=='undefined' && !node.hasAttribute('expand-checked'))
			node.setAttribute('expand-checked', 1)
	}

	this.expand_node = function(item_id, expand) {
		var node = this.get_node(item_id);
		if (typeof(expand)==='undefined') {
			node.classList.toggle('node-expanded');
		} else {
			if (expand) {
				node.classList.add('node-expanded');
			} else {
				node.classList.remove('node-expanded');
			}
		}

		if (node.classList.contains('node-expanded')) {
			if (!node.hasAttribute('expand-checked') && options.children_list_fn) {
				node.setAttribute('expand-checked', 1)
				options.children_list_fn(item_id);
			}
		}
	}

	this.delete_node = function(item_id) {
		var node = this.get_node(item_id);
		node.parentNode.removeChild(node);
	}

	this.init = function() {
//console.log(this)
		this.tree_o = owner_o;
		this.tree_o.classList.add('yozh-tree-db');
//		this.tree_o.addEventListener('dragenter',	function(ev) {ev.preventDefault(); return false;});
//		this.tree_o.addEventListener('dragover',	function(ev) {ev.preventDefault(); return false;});
//		this.tree_o.addEventListener('dragleave',	function(ev) {ev.preventDefault(); return false;});
		if (options.data_node)
			this.create_node(this.tree_o, options.data_node);
	}

	this.set_level_even = function(node) {
		if (node.parentNode.classList.contains('level-even')) {
			node.classList.remove('level-even');
		} else {
			node.classList.add('level-even');
		}
		for (var i=0, l=node.children.length; i<l; i++)
			if (node.children[i].classList.contains('yozh-tree-node'))
				this.set_level_even(node.children[i]);
	}

	//-- drag-n-drop ---------------------------------------------------------------------------------------------------
	this.dragStart = function(ev) {
		this.tree_o.querySelectorAll('.yozh-tree-drag-target-insert-before').forEach(function(o){
			o.addEventListener('dragenter', this.dragEnterBind);
		}.bind(this));
		this.tree_o.querySelectorAll('.yozh-tree-drag-target-append-child').forEach(function(o){
			o.addEventListener('dragenter', this.dragEnterBind);
		}.bind(this));

		this.drag_item		= ev.target.closest('.yozh-tree-node');
		this.drag_item.classList.add('yozh-tree-node-over');
		this.action			= null;
		this.action_item	= null;

//		this.drag_item.classListhis.add('drop_active');
		ev.dataTransfer.effectAllowed = 'all';
//		ev.dataTransfer.dropEffect='none';
//		ev.dataTransfer.setData('index', 'text');
		var DragImage = this.drag_item.querySelector('.yozh-tree-node-title');
		ev.dataTransfer.setDragImage(DragImage, DragImage.offsetWidth/2, DragImage.offsetHeight/2);

//		if (!this.drag_padle)
//			this._create_drag_padle();
//		ev.dataTransfer.setDragImage(this.drag_padle, this.drag_padle.offsetWidth/2, this.drag_padle.offsetHeight/2);

//		ev.dataTransfer.dropEffect = "copy";
//		ev.preventDefault();
//		ev.stopPropagation();
		return true;
	}

	this.dragEnter = function (ev) {
		var node = this.get_node(ev.target),
			search = node;

		while (search && this.tree_o!=search) {// if node is drag_item or child of drag_item
			if (search==this.drag_item)
				return;
			search = search.parentNode;
		}

		if (ev.target.classList.contains('yozh-tree-drag-target-append-child')) {
			node.appendChild(this.drag_item);
			this.set_level_even(this.drag_item);
			this.action = 'appendTo';
			this.action_item = node;
		}

		if (ev.target.classList.contains('yozh-tree-drag-target-insert-before')) {
			node.parentNode.insertBefore(this.drag_item, node);
			this.set_level_even(this.drag_item);
			this.action = 'moveBefore';
			this.action_item = node;
		}

		ev.preventDefault();
		return true;
	}
	this.dragEnterBind = this.dragEnter.bind(this);

	this.dragEnd = function (ev) {
		this.tree_o.querySelectorAll('.yozh-tree-drag-target-insert-before').forEach(function(o){
			o.removeEventListener('dragenter', this.dragEnterBind);
		}.bind(this));
		this.tree_o.querySelectorAll('.yozh-tree-drag-target-append-child').forEach(function(o){
			o.removeEventListener('dragenter', this.dragEnterBind);
		}.bind(this));

		this.drag_item.classList.remove('yozh-tree-node-over');

		if (options.item_move_fn && this.action)
			options.item_move_fn({
				item_id:	this.drag_item.getAttribute('item_id'),
				action:		this.action,
				action_item_id:this.action_item.getAttribute('item_id')
			});
//		this.drag_item.classList.remove('drop_active');
		ev.stopPropagation();
		return false;
	}
	//------------------------------------------------------------------------------------------------------------------

	this.init();
}