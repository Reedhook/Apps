function change_log_class() {
	table_call_class.call(this)

	this.data.call_width = 1200
	this.data.title_icon = 'database'

	this.list_url	= 'core/change_log/list_ajax'
	this.view_url	= 'core/change_log/view_ajax'
//	this.restore_url= 'core/change_log/restore_ajax'

	this.td_formatter_icons = function(field_name, record, el) {
		let children = [
			Number(record.change_type)===3 ? {
				properties: {title: this.lang('edit_history')},
				className: ['btn', 'icon', 'edit', '-history'],
				events: {clickenter: change_log_list_show.bind(null, {
						filters: {model: record.model, record_id: record.record_id},
						title: this.lang(record.model.split("\\").at(-1).slice(0, -3)) +' [id: '+record.id+']' + (record.name?' '+record.name:'') + ' - ' + this.lang('edit_history')
					})}
			} : {className: 'btn icon empty'},
		]

		el.children = [{
			className: 'flex-block between2',
			children: children
		}]
	}

	this.td_formatter_data_list = function(field_name, record, el) {
		el.children = Object.keys(record[field_name]).map(function(i){
			return {className: 'flex-block between5', children: [{text: i+':'}, {text: record[field_name][i]}]}
		})
	}

	this.create_action_icons = function() {
		return []
	}

/*	this.view = function(record){
		this.view_popup = idler_popup({width: 800})

		yozh_fetch({
			url: script_url+this.view_url,
			data: this.edit_data_compile(record),
			on_success_fn: function(response_data, textStatus){
				this.view_popup.setContent(response_data.html)
			}.bind(this)
		})
	}

//	this.restore = function(record){
//		yozh_ajax({
//			url: script_url+this.restore_url,
//			data: {item_id: record.id, class_name: this.data.filters.class_name},
//			on_success_fn: function(response_data, textStatus){
//				this.list()
//			}.bind(this)
//		})
//	}
*/
}

function change_log_list_show(data, e) {
	(new change_log_class()).show(data, e.target)
}