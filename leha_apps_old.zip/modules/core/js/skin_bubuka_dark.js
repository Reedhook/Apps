function custom_table_class() {
	if (this.data.call_width!=='100%' || this.data.call_width<1200)
		this.data.call_width = 1200
	let show_parent = this.show
	this.show = async function(show_data={}) {
		await show_parent.call(this, show_data)
		for (let i of this.structure.action_box.el.querySelectorAll('.btn')) {
			i.classList.add('orange')
			i.classList.add('ico')

			let el_tooltip = i.hasAttribute('data-tooltip') ? i : (i.childNodes[0] && i.childNodes[0].hasAttribute('data-tooltip') ? i.childNodes[0] : false)
			if (el_tooltip) {
				el_add_children(i, el_tooltip.getAttribute('data-tooltip'))
				el_tooltip.removeAttribute('data-tooltip')
			}
		}
	}
	let build_structure_parent = this.build_structure
	this.build_structure = function() {
		let structure = build_structure_parent.call(this),
			k, swipe

//		this.structure.header_line.className.push('underline')
//		this.structure.header_line.className.push('table-header')

		if (this.data.popup_mode) {
			if (k=this.structure.header_line.className.indexOf('pr30'))
				this.structure.header_line.className.splice(k, 1, 'pr50') // меняем отступ в заголовке для кнопки закрытия окна
		} else {
			this.structure.header_line.className.push('underline') // подчеркиваем заголовок
		}

		if (k=this.structure.header_title.className.indexOf('icon-left-h24'))
			this.structure.header_title.className.splice(k, 1) // убираем иконку в заголовке
		if (k=this.structure.header_title.className.indexOf('icon'))
			this.structure.header_title.className.splice(k, 1) // убираем иконку в заголовке

		// фильтры вправо (меняем таблицу и фильтры местами)
		if (this.structure.two_col) {
			swipe = this.structure.two_col.children[0]
			if (k=swipe.className.indexOf('pr10'))
				swipe.className.splice(k, 1, 'ml20')
			swipe.className
			this.structure.two_col.children[0] = this.structure.two_col.children[1]
			this.structure.two_col.children[1] = swipe
		}

		// фильтры без фона
		this.structure.filter_form.className = ['w300', 'flex-block', 'column']

		// добавляем под таблицу вторую пагинацию
		this.structure.two_col.children[0].className.push('flex-block', 'column')
		this.structure.two_col.children[0].children = [
			{
				className: ['overflow'],
				children: [this.structure.table_box],
			},
			this.structure.pager_box2 = {
				className: ['table-row', 'flex-block', 'between'],
			},
		]

		// меняем местами пагинацию и кнопку фильтров
		swipe = this.structure.pager_line.children[0]
		this.structure.pager_line.children[0] = this.structure.pager_line.children[1]
		this.structure.pager_line.children[1] = swipe

		if (k=this.structure.pager_box.className.indexOf('row-reverse'))
			this.structure.pager_box.className.splice(k, 1) // первая пагинация слева

		this.structure.filters_btn.className.push('ico')
		this.structure.filters_btn.text = 'Фильтры' // подписываем кнопку фильтров

		if (this.data.popup_mode) { // добавляем отступы в попап режиме
			this.structure.pager_line.className.push('prl15')
			this.structure.two_col.className.push('prl15', 'pb15')
		}

		return structure
	}
	this.update_list = function() {
		// clear pagination 1
		while (this.structure.pager_box.el.firstChild)
			this.structure.pager_box.el.firstChild.remove()
		// build pagination 1
		el_add_children(this.structure.pager_box.el, this.build_pagination(this.data.pagination, 1))

		// clear pagination 2
		while (this.structure.pager_box2.el.firstChild)
			this.structure.pager_box2.el.firstChild.remove()
		// build pagination 2
		el_add_children(this.structure.pager_box2.el, this.build_pagination(this.data.pagination, 2))

		// clear table
		while(this.structure.table_box.el.firstChild)
			this.structure.table_box.el.firstChild.remove()

		// build table
		el_add_children(this.structure.table_box.el, this.build_table())

		if (!this.tooltip)
			this.tooltip = new yozh_tooltip()
		this.tooltip.set(this.structure.table_frame.el)

		if (this.data.multi_select)
			this.show_selected_records()
	}

	this.build_filters = function() {
		if (!this.structure.filter_box)
			return

		let filters_list = []
		for(let i in this.data.filters_model) {
			let field_type = this.data.filters_model[i].type,
				value = (this.data.pagination && this.data.pagination.filters && this.data.pagination.filters[i] ? this.data.pagination.filters[i] : false) // сначала берём данные из возвращенных от сервера фильтров
					|| (this.data.filters && this.data.filters[i] ? this.data.filters[i] : false) // берем данные из фильтров построения формы
					|| this.data.filters_model[i].value // значение по умолчанию фильтра
					|| ''

			if (this['filter_'+field_type] instanceof Function) {
				filters_list.push({
					className: [/*'table-row', 'color', 'flex-block', 'between5'*/, 'input-block', field_type==='hidden' ? 'c-gray': null, this.data.filters_model[i].slim?'slim':null],
					children: [
						{
							className: [/*'w'+this.data.filter_title_width, 'a-right',*/ 'edit-title', 'nowrap', 'overflow'].concat(this.data.filters_model[i].description ? ['icon', 'icon-right-h18', 'info', 'icon-color-disabled'] : null),
							attributes: this.data.filters_model[i].description ? {title: this.lang(this.data.filters_model[i].description)} : null,
							text: this.lang(this.data.filters_model[i].hasOwnProperty('title') ? this.data.filters_model[i].title : i),
						},
						this['filter_'+field_type](i, value)
					]
				})
			}
		}

		this.structure.filter_form.el.classList.add('p16')
		el_add_children(this.structure.filter_form.el, [
/*			{
				text: this.lang('filters'),
				className: ['table-row', 'header']
			},*/
			{
				className: ['flex-grow', 'scroll'],
				children: filters_list,
			},
			{
				className: ['input-block', 'flex-block', 'right', 'between5'],
				children: [
					{
						className: ['btn', 'orange' , 'icon', 'ico', 'refresh'],
						text: this.lang('reset'),
						attributes: {

							tabindex: 0,
						},
						events: {clickenter: function() {this.filters_form_reset(); this.form_filter_submit()}.bind(this)}
					},
					{
						className: ['btn', 'orange', 'icon', 'ico', 'search'],
						children: [
							{
								text: this.lang('search')
							},
							{
								tagName: 'input',
								className: 'hover_invisible pointer',
								attributes: {
									type: 'submit',
									value: "",
								},
							}
						]
					}
				]
			},
		])

		this.tooltip.set(this.structure.filter_form.el)
	}
	this.filter_ref = function(i, value) {
		let slim = this.data.filters_model[i].slim ? 'slim' : null,
			js_call = this.data.filters_model[i].js_call,
			js_call_filters = this.data.filters_model[i].js_call_filters || this.data.filters_model[i].filters || null,
			input_hidden, input_div

		if (js_call==='model_table_db_list_show') {
			if (!js_call_filters)
				js_call_filters = {}
			js_call_filters.model = this.data.filters_model[i].ref
		}

		if (!window[js_call] || !(window[js_call] instanceof Function))
			console.log('unknown js_call - ' + js_call)

		return {
			className: ['flex-grow', 'flex-block', 'between5'/*, 'input-block'*/, slim],
			children: [
				input_hidden = ce({
					tagName: 'input',
					attributes: {
						type: 'hidden',
						name: i,
						value: value,
						'value-first': value,
					},
					properties: {change: this.form_filter_submit.bind(this)},
				}),
				input_div = ce({
					className: ['flex-grow', 'input', 'pointer', 'ellipsis', 'link', slim],
					text: this.data.filters_ref_name[i] ? this.data.filters_ref_name[i] : value,
					attributes: {
						'value-first': this.data.filters_ref_name[i] ? this.data.filters_ref_name[i] : value,
						tabindex: 0,
					},
					events: {
						clickenter: window[js_call].bind(null, Object.assign({
							title: this.lang('select')+' '+this.lang(i),
							select_mode: this.data.filters_model[i].multi_select ? 2 : 1
						}, js_call_filters ? {filters: js_call_filters} : null))
					}
				}),
				{
					className: ['btn', 'icon', 'red', 'remove', slim],
					events: {clickenter: function() {
							input_hidden.value = ''
							input_div.innerHTML=''
							this.form_filter_submit()
						}.bind(this)},
					attributes: {tabindex: 0},
				},
			]
		}
	}
	this.build_pagination = function (pagination, pager_no) {
		let	page_go			= ()=>{
			let p = parseInt(this.structure.page_go.el.value)
			p = isNaN(p) || p===0 ? 0 : p-1
			this.set_page_no.call(this, p)
		}

		return pager_no===1 ? {
			className: ['flex-block', 'between10', 'nowrap'],
			children: [
				{
					className: ['nowrap'],
					text: this.lang('records')+': '+pagination.records_count,
				},
//				pagination.page_size==='all' || pagination.page_count<2 ? null : {className: 'nowrap', text: this.lang('page')+' '+(Number(pagination.page_no)+1)+' '+this.lang('page_from')+' ' + pagination.page_count},
//				pagination.page_size==='all' || pagination.page_count<2 ? null : {
//					className: ['flex-block', 'between10'],
//					children: this.build_pagination_buttons(pagination)
//				},
/*				pagination.page_count>5 ? {
					className: ['flex-block', 'between5', 'nowrap'],
					children: [
						{
							className: 'nowrap',
							text: this.lang('go_to_page')+':',
						},
						{
							className: ['w90', 'flex-block'],
							children: [
								this.structure.page_go = {
									tagName: 'input',
									className: ['a-center', 'right-flat'],
									attributes: {
										type: 'text',
										value: pagination.page_no+1,
		//								title: this.lang('page_no'),
									},
									events: {keyup: (e)=>{if (e.keyCode===13) page_go()}}
								},
								{
									className: ['btn', 'icon', 'angle-right', 'left-flat'],
									attributes: {
		//								title: this.lang('page_no'),
										tabindex: 0,
									},
									events: {clickenter: page_go}
								}
							]
						}
					]
				} : null,
*/				pagination.page_size_values ? {
					className: ['flex-block', 'between5', 'nowrap'],
					children: [
						{
							className: 'nowrap',
							text: this.lang('records_per_page')+':',
						},
						{
							tagName: 'select',
							className: 'w50',
							events: {change: (ev)=>{this.set_page_size(ev.target.value)}},
//							attributes: {title: this.lang('records_per_page')},
							children: Object.keys(pagination.page_size_values).map((i)=>{return {
								tagName: 'option',
								text: this.lang(pagination.page_size_values[i]),
								attributes: Object.assign(
									{value: pagination.page_size_values[i]},
									pagination.page_size==pagination.page_size_values[i] ? {selected: true} : null
								)
							}
							})
						}
					]
				} : null,
			]
		} : (pagination.page_size==='all' || pagination.page_count<2 ? null : this.build_pagination_buttons(pagination))

	}
	this.build_pagination_buttons = function(pagination, o={}) {
		let r = o.r || 1,						// radius size
			c = Number(pagination.page_no),		// current page no
			t = Number(pagination.page_count),	// total pages
			l = t-1,							// last page no
			button_line = [],
			b = (n, className=null)=>{button_line.push({ // build button structure and put it to button_line
				className: ['btn', 'icon', n===c ? 'active' : 'gray', className],
				events: {clickenter: n===c ? null : this.set_page_no.bind(this, n)},
				attributes: {tabindex: n===c ? -1 : 0},
				text: n+1,
			})}

		let s = 1, e = t-2 // start an end no of between-buttons (if short list)
		if (t > 3+r*2) { // long list
			if (c<1+(1+r)) { // current at the beginning
				s = 1
				e = 1 + r*2
			} else if (c>l-(1+r)) { // current at the end
				s = l - (1 + r*2)
				e = l - 1
			} else { // current between the beginning and end
				s = c - r,
					e = c + r
			}
		}

		b(0/*, c>1+r ? 'mr10' : 'mr5'*/) // first button
		if (c>1+r)
			button_line.push({text: '...'})
		for (let n=s; n<=e; n++) { // between-buttons
			b(n/*, n===e && n<l-1 ? 'mr10' : 'mr5'*/)
			if (n===e && n<l-1)
				button_line.push({text: '...'})
		}
		b(l) // last button

		return [
			{
				className: ['btn', 'gray', c===0?'disabled':null],
				events: {clickenter: c===0 ? null : this.set_page_no.bind(this, c-1)},
				text: this.lang('previous_page'),
			},
			{
				className: ['flex-block', 'between10'],
				children: button_line,
			},
			{
				className: ['btn', 'gray', c===l?'disabled':null],
				events: {clickenter: c===l ? null : this.set_page_no.bind(this, c+1)},
				text: this.lang('next_page'),
			},
		]
	}
	let build_th_parent = this.build_th
	this.build_th = function (field_name) {
		let th_structure = build_th_parent.call(this, field_name)
		if (this.structure.selected_count)
			this.structure.selected_count.children[1].className = ['idler-popup-close']
		return th_structure
	}
}

function build_edit_form (options) {
	let field_title_width = options.field_title_width || 200,
		hidden_field_list = Object.assign({action: 'save', item_id: options.data.id||''}, options.hidden_field_list || null)

	options.input_list = {}

	if (!options.hasOwnProperty('input_name'))
		options.input_name = 'data'

	let localisation_options = options.field_localisation ? Object.assign({}, options, {
		field_list: options.field_localisation,
		data: options.data_localisation,
		field_type: 'localisation',
	}) : false

	let structure = {field_list: {}}
	structure.form = {
		tagName: 'form',
		className: 'flex-block column h100p',
		attributes: {method: 'post', action: 'javascript: void(0)'},
		children: Object.keys(hidden_field_list).map(function(i){ return options.input_list[i] = {
				tagName: 'input',
			attributes: {type: 'hidden', name: i, value: hidden_field_list[i]}
		}}).concat([
			structure.header = {
				className: ['table-header'].concat(options.title_className ? options.title_className : null),
				children: [
					{
						className: ['table-row'],
						text: options.title ||
							(options.form_view_only ? '' : (options.data.id ? lang(options.lang, 'edit') : lang(options.lang, 'create'))) +
							(options.item_name ? ' ' + lang(options.lang, options.item_name) : ''),
					}
				]
			},
			structure.field_panel = {
				className: ['flex-grow', 'flex-block', 'column', 'scroll', 'p16'],
				children: (options.header_rows ? options.header_rows : [
					options.data.id ? {
						className: ['input-block', 'c-gray'],
						children: [
							{
								className: ['edit-title'],
								text: lang(options.lang, 'id') + ': '
							},
							{
								className: ['input'],
								text: options.data.id || ''
							}
						]
					} : null,
				]).concat(
					options.field_localisation ? Object.keys(options.field_localisation).map(function(f){return structure.field_list[f] = build_edit_form_row(localisation_options, f)}) : null,
//					options.field_list ? Object.keys(options.field_list).map(function(f){return build_edit_form_row(options, f)}) : null
					options.field_list ? build_edit_form_rows(options, structure.field_list) : null
				)
			},
			{
				className: ['table-header'],
				children: [
					structure.btn_panel = {
						className: ['table-row', 'flex-block', 'center', 'between5'],
						children: [
							options.form_view_only ? structure.btn_ok = {
								className: ['btn', 'orange'],
								attributes: {
									'data-action': 'ok',
									tabindex: 0,
								},
								text: lang(options.lang, 'ok')
							} : structure.btn_save = {
								className: ['btn', 'orange', 'icon', 'ico', 'check'],
								attributes: {
									'data-action': 'save',
									tabindex: 0,
								},
								text: lang(options.lang, 'save')
							}
						]
					},
				]
			}
		])
	}
	structure.input_list = options.input_list

	return options.return_structure ? structure : structure.form
}
function build_edit_form_rows (options, structure=false) {
	let rows = []
	for (let field_name in options.field_list) {
		if (!options.field_list[field_name])
			continue
		let field_type = /*options.field_type ||*/ options.field_list[field_name].type

		if (options.field_divider_list && options.field_divider_list[field_name]) {
			rows.push({
				className: ['table-row', 'header', 'nowrap', 'a-center'],
				text: lang(options.lang, options.field_divider_list[field_name])
			})
		}

		if (field_type==='json') {
			rows = rows.concat(build_edit_form_rows (Object.assign({}, options, {
				data:		options.data[field_name] || {},
				field_list:	options.json_map[field_name],
				lang:		options.lang || {},
				enum:		options.enum || {},
				input_name: options.input_name ? options.input_name + '[' + field_name  + ']' : field_name,
			}), structure))
		} else {
			let row_structure = build_edit_form_row (options, field_name)
			if (structure)
				structure[field_name] = row_structure
			rows.push(row_structure)
		}
	}
	return rows;
}
function build_edit_form_row (options, field_name) {
	let field_title_width = options.field_title_width || 200,
		r = options.field_list[field_name],// || options.field_localisation[field_name],
		title = r.title || field_name,
		translate = options.field_list[field_name].no_translate ? false : true,
		field_type = options.field_type
			|| (options.field_list && options.field_list[field_name] ? (options.field_list[field_name].ref ? 'ref' : options.field_list[field_name].type) : false)
			|| 'str'

	if (window['build_edit_form_row_'+field_type] && window['build_edit_form_row_'+field_type] instanceof Function)
		return window['build_edit_form_row_'+field_type](options, field_name)

	return {
		className: ['input-block', r.view_only || options.form_view_only? 'c-gray' : null],
		children: [
			{
				className: ['edit-title', 'overflow', 'nowrap'].concat(r.description ? ['icon', 'icon-right-h18', 'info', 'icon-color-disabled'] : null),
				attributes: r.description ? {title: translate ? lang(options.lang, r.description) : r.description} : null,
				text: (translate ? lang(options.lang, title) : title)+ ': ',
			},
			build_edit_form_input(options, field_name)
		]
	}
}

//-- header menu -------------------------------------------------------------------------------------------------------
function menu_show_sub(span) { // показать фрейм меню (при нажатии на span в кнопке меню)
	let item = span.parentNode, // текущая (нажатая) кнопка меню
		item_id = item.getAttribute('menu_item_id'), // id текущего пункта menu
		item_line = item.closest('.line-menu'), // див с остальными кнопками (где текущая кнопка)
		frame = item.closest('.line-menu-frame'), // текущий фрейм (где текущая кнопка)
		header = item.closest('header'), // див со всеми фреймами
		frame_branch = [] // список id фреймов, которые должны быть отображены

	// получаем всю ветку отображаемых фреймов
	let i = frame
	while (i) {
		if (i.hasAttribute('menu_item_id')) {
			frame_branch.push(i.getAttribute('menu_item_id'))
			i = i.closest('line-menu-frame')
		}
	}

	for(let i of item_line.querySelectorAll('.line-menu-item')) // перебираем кнопки в текущем фрейме
		if (i!=item)
			i.classList.remove('show') // отжимаем все кнопки, кроме текущей
	item.classList.toggle('show') // меняем состояние текущей кнопки

	if (item.classList.contains('show')) { // если кнопка нажата (не отжата)
		frame_branch.push(item_id) // добавляем в ветку отображаемых фреймов дочерний фрейм
	} else {
	}

	for (let i of header.querySelectorAll('.line-menu-frame')) { // перебираем все фреймы
		let frame_id = i.getAttribute('menu_item_id') // id фрейма
		if (frame_branch.includes(frame_id)) { // если фрейм в ветке отображаемых
			i.classList.add('show') // отображаем фрейм
			menu_scroll_show_nav(i) // отображаем или прячем кнопки навигации во фрейме
		} else {
			i.classList.remove('show') // прячем фрейм
		}
	}
}
function menu_scroll_show_nav(frame) { // показать навигацию во фрейме меню
	let line = frame.querySelector('.line-menu')
	if (line.clientWidth < line.scrollWidth) {
		let nav_div = frame.querySelector('.line-menu-scroller-nav')
		if (nav_div)
			nav_div.style.display = 'flex'
	}
}
function menu_scroll_prepare() { // показать навигацию во всех фреймах меню
	for (let i of document.body.querySelectorAll('header .line-menu-frame'))
		menu_scroll_show_nav(i)
}
yozh_DOMContentLoaded(menu_scroll_prepare)

function nav_scroll(btn) {
	let direction = btn.getAttribute('direction')==='left' ? -1 : 1,
		line = btn.parentNode.parentNode.querySelector('.line-menu'),
		start = line.scrollLeft,
		end = start + (line.offsetWidth - 100) * direction,
		step = 20,
		f = ()=>{

		}
	if (end<0)
		end = 0
	if (end > line.scrollWidth-line.offsetWidth)
		end = line.scrollWidth-line.offsetWidth

	let i = setInterval(()=>{
			line.scrollLeft += step*direction
			if (direction>0) {
				if (line.scrollLeft>=end)
					clearInterval(i)
			} else {
				if (line.scrollLeft<=end)
					clearInterval(i)
			}
		}, 10)
}

function custom_yozh_popup(options, o) {
	o.btn_close.className = ['idler-popup-close']
}
var build_edit_form_row_bool = /*build_input_checkbox =*/ function  (options, field_name) {
	let input_name = options.input_name ? options.input_name + '[' + field_name  + ']' : field_name,
		field_type = options.field_type
			|| (options.field_list && options.field_list[field_name] ? (options.field_list[field_name].ref ? 'ref' : options.field_list[field_name].type) : false)
			|| 'str',
		value = options.value
			|| (options.data ? options.data[field_name] : false)
			|| (options.field_list && options.field_list[field_name] && options.field_list[field_name].value ? options.field_list[field_name].value : false)
			|| '',
		view_only = options.form_view_only
			|| (options.field_list && options.field_list[field_name] && options.field_list[field_name].view_only ? true : false)
			|| false,
		r = options.field_list[field_name],
		title = r.title || field_name,
		translate = options.field_list[field_name].no_translate ? false : true

	return {
		className: ['input-block', 'input-box',],// input-box-checkbox flex-grow flex-block between10',
		children: {
			tagName: 'label',
			className: ['flex-grow', 'checkbox'],
			children: [
				options.input_list[field_name] = {
					tagName: 'input',
					attributes: Object.assign(
						{
							type: 'checkbox',
							name: input_name,
							value: 1,
						},
						value ? {checked: true}: null,
						view_only ? {disabled: true} : null
					)
				},
				{},
				{
					className: ['label-text'],
					text: (translate ? lang(options.lang, title) : title),
				}
			]
		}
	}
}

var edit_popup_parent = edit_popup
var edit_popup = async function (options) {
	if (!options.width || options.width!=='100%')
		options.width = 400
	edit_popup_parent(options)
}

function yozh_calendar_popup(e, options={}) {
	let width = 216,
		height = 244,
		left = options.left || false,
		top = options.top || false

	if (e instanceof Event && e.target) {
		if (e.target.yozh_calendar_popup_hide instanceof Function) {
			e.target.yozh_calendar_popup_hide()
			return
		}
		if ('value' in e.target) {
			if (!options.hasOwnProperty('value'))
				options.value = e.target.value

			if (!(options.on_select instanceof Function))
				options.on_select = (d)=>{e.target.value=date_to_format(d)}
		}

		let box = e.target.getBoundingClientRect()
		if (left===false) {
			left = box.left
			if (left + width + 4 > document.body.clientWidth)
				left = document.body.clientWidth - width - 4
		}
		if (top===false) {
			top = box.top + e.target.offsetHeight + 2
			if (top + height + 4 > document.body.clientHeight)
				top = document.body.clientHeight - height - 4
		}
	}

	if (typeof options.value==='string' || options.value instanceof String)
		options.value = format_to_date(options.value)

	if (left===false)
		left = (document.body.clientWidth - width)/2
	if (top===false)
		top = (document.body.clientHeight - top)/2

	let	yozh_calendar_popup_hide = ()=>{
			popup.el.remove()
			document.body.removeEventListener('click', document_click)
			delete e.target.yozh_calendar_popup_hide
		},
		document_click = (e)=>{
			if (e.event_popup===popup.el)
				return
			yozh_calendar_popup_hide()
		},
		calendar = yozh_calendar(Object.assign({}, options, {
			on_select: (date)=>{
				yozh_calendar_popup_hide()
				if (options.on_select instanceof Function)
					options.on_select(date)
			}
		})),
		popup = {
			className: ['shadow'],
			styles: {zIndex: 30, position: 'absolute', left: left+'px', top: top+'px'},
			children: calendar.build(),
			events: {click: (e)=>{e.event_popup=popup.el}}
		}

	el_add_children(document.body, popup)

	if (e instanceof Event) {
		e.event_popup = popup.el
		e.target.yozh_calendar_popup_hide = yozh_calendar_popup_hide
	}

	document.body.addEventListener('click', document_click)
}