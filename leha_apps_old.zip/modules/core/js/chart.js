function yozh_chart(canvas, data) {

//	if (typeof(canvas)==='string')
//		canvas = document.querySelector(canvas)
//	if (canvas.tagName!='canvas')
//		canvas = ce({parentNode: canvas, tagName: 'canvas', styles: {display: 'block', width: '100%', height: '400px'}})

	canvas.width = canvas.offsetWidth
	canvas.height = canvas.offsetHeight

	/*canvas.addEventListener('click', function(e){
		var image = new Image()
		image.src = canvas.toDataURL('image/png')
		var width = image.width
		var height = image.height
		window.open(image.src, "Image", "width="+width+",height="+height)
	})*/

	// draw cart
	var ctx = canvas.getContext('2d'),
		text_width = 0,
		max_value = 0,
		item_count = 0
	axes = {
		x: {},
		y: {},
	}
	ctx.font = 'normal 12px Verdana'
	ctx.textBaseline = "top"

	for(var i in data.list) {
		text_width = Math.max(text_width, ctx.measureText(data.list[i][data.options.title]).width)
		max_value = Math.max(max_value, Number(data.list[i][data.options.value]))
		item_count ++
	}
	text_width = Math.round(Math.min(text_width, Number((canvas.offsetWidth/3).toFixed())-20))

	ctx.strokeStyle = "#000000"
	ctx.lineWidth = 1

	//-- axis-y --------------------------------------------------------------------------------------------------------
	ctx.beginPath()
	ctx.moveTo(20.5+text_width, 10.5)
	ctx.lineTo(20.5+text_width, canvas.offsetHeight-20+.5)
	ctx.lineTo(canvas.offsetWidth-10+.5, canvas.offsetHeight-20+.5)
	ctx.stroke()

	var item_height = Number(((canvas.offsetHeight-30)/item_count).toFixed()),
		y = canvas.offsetHeight-(item_count*item_height+20)

	for (var i in data.list) {
		ctx.fillText(data.list[i][data.options.title], 10+text_width-ctx.measureText(data.list[i][data.options.title]).width, y+(item_height-12)/2)
		y += item_height
	}

	//-- axis-x --------------------------------------------------------------------------------------------------------
	var a = max_value, k = 1, step = 1, decimals=0
	if (a===0)
		return

	if (a>10)
		while (a>10)
			a = a/10, k = k*10
	if (a<=1) {
		decimals++
		while (a<=1)
			a = a*10, k = k/10, decimals++
	}

	if (a<2) {
		a = Number((Math.ceil(a*5)/5).toFixed(2))
		step = 0.25
		decimals = 2
	}
	if (a>=2 && a<4) {
		a = Number((Math.ceil(a*4)/4).toFixed(2))
		step = 0.5
		decimals = 1
	}
	if (a>=4 && a<6) {
		a = Number((Math.ceil(a*3)/3).toFixed(2))
		step = 1
	}
	if (a>=6 && a<8) {
		a = Number((Math.ceil(a*2)/2).toFixed(2))
		step = 1
	}
	if (a>=8) {
		a = 10
		step = 2
	}

	var v = 0, w = canvas.offsetWidth-30-text_width
	do {
		var str = Number((v*k).toFixed(decimals)),
			x = text_width+20.5 + Math.round((w/a)*v)

		ctx.beginPath()
		ctx.strokeStyle = "rgba(0,0,0,.1)"
		ctx.moveTo(x, 10)
		ctx.lineTo(x, canvas.offsetHeight-20)
		ctx.stroke()

		ctx.beginPath()
		ctx.strokeStyle = "#000000"
		ctx.moveTo(x, canvas.offsetHeight-22)
		ctx.lineTo(x, canvas.offsetHeight-16)
		ctx.stroke()

		ctx.fillStyle = '#000000'
		ctx.fillText(str.toLocaleString(), x - Math.round(ctx.measureText(str).width/2), canvas.offsetHeight-14)
		v+=step
	} while (v<=a)

	//-- charts --------------------------------------------------------------------------------------------------------
	var colors = ['rgba(255,0,0,.2)', 'rgba(0,255,0,.2)', 'rgba(0,0,255,.2)', 'rgba(255,255,0,.2)', 'rgba(255,0,255,.2)', 'rgba(0,255,255,.2)'],
		c = 0,
		y = canvas.offsetHeight-(item_count*item_height+20)

	for (var i in data.list) {
		ctx.fillStyle = colors[c]
		ctx.strokeStyle = colors[c]
		ctx.fillRect(20+text_width+1, y+5, Math.round((data.list[i][data.options.value]*w)/(a*k)), item_height-10)
		ctx.fillStyle = '#000000'
		ctx.fillText(data.list[i][data.options.text], text_width+30, Math.round(y+item_height/2-6))
		y += item_height
		c ++
		if (c>=colors.length)
			c = 0
	}
}