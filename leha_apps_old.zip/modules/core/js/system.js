function get_form_data(form) {
	let f = form instanceof Element ? form : document.forms[form],
		data = {};

	if (typeof(f)==='object' && f!==null) {
		for (let i=0, l=f.elements.length; i<l; i++) {
			let element = f.elements[i],
				name = element.name,
				value = null

			if (!name)
				continue

			if (element.tagName.toLowerCase()==='fieldset') {
				continue
			} else if (element.type==='checkbox') {
				value = element.checked ? element.value : '';
			} else if (element.type==='radio') {
				if (!element.checked)
					continue
				value = element.value;
			} else if (element.type==='select-multiple') {
				value = [];
				for (let o of form.elements[i].options)
					if (o.selected)
						value[value.length] = o.value;
			} else {
				value = element.value;
			}

			object_key_set_value(data, name, value)
		}
	}
	return data;
}

function set_form_params(form_name, params) {
	let f = typeof(form_name)=='object' ? form_name : document.forms[form_name];

	if (typeof(f)==='object' && f!==null) {
		for (let i in params) {
			let e = f.elements[i],
				type = e.type;

			if (e.tagName!='FIELDSET' && e.type!='checkbox' && e.type!='radio')
				e.value = params[i];


			if (e.type=='checkbox')
				e.checked = params[i];

			if (e.type=='radio' && e.value == params[i])
				e.checked = true;

/*			if (e.type=='select-multiple') {
				let values = [];
				for (let o=0; o<form.elements[i].options.length; o++)
					if (e.options[o].selected)
						values[values.length] = e[i].options[o].value;
				params[e.name] = values;
			}*/
		}
	}
}
/*
function form_reset(form) {
	form.reset()
	for (let el of form.querySelectorAll('[value-first]')) {
		if (el.tagName.toLowerCase()==='input') {
			el.value = el.getAttribute('value-first')
		} else {
			el.innerHTML = el.getAttribute('value-first')
		}
	}
	for (let el of form.querySelectorAll('[reset-fn]'))
		el.reset()
}
*/
function fill_select(select_o, data, selected, first_option){
	function add_option(value, title){
		let n = select_o.options.length,
			option = new Option(title, value, false, value==selected)
		select_o.options[n] = option;
	}
	select_o.options.length = 0;
	if(typeof(first_option)=='string')
		add_option('', first_option);
	for(let i in data)
		add_option(i, data[i]);
}
/*
function add_wait_div(obj, action){
	if(typeof(obj)!='object')
		obj = document.getElementById(obj);

	if (action==='hide') {
		if (obj.wait_div) {
			if (obj.wait_div.parentNode===obj)
				obj.removeChild(obj.wait_div);
			delete obj.wait_div
		}
		obj.classList.remove('blur')
	} else if (!obj.wait_div) {
		obj.wait_div = ce({className: 'div_wait waiting'})
		obj.appendChild(obj.wait_div);
		obj.classList.add('blur')
	}
}*/
HTMLElement.prototype.wait = function (fl=true) {
	if (fl) {
		if (this.wait_o)
			return
		this.appendChild(this.wait_o = ce({className: ['div_wait', 'waiting']}))
	} else {
		if (this.wait_o) {
			this.wait_o.remove()
			delete this.wait_o
		}
	}
}

// <label class="input file" data-file-name="{'select_file'|lang}"><input type="file" name="file" onchange="input_file()" /></label>
function input_file(e) {
	let i = e.target
	if (i.files.length>0)
		i.parentNode.setAttribute('data-file-name', i.files[0].name);
}
function clear_input_block(event) {
	let block = event.target.closest('.input-block') || event.target.parentNode
	if (block) {
		for(let i of block.querySelectorAll('input'))
			i.value=''

		let el = block.querySelector('.input')
		if (el) el.innerHTML=''

		el = block.querySelector('.download')
		if (el) {
			el.classList.add('disabled')
			el.href = 'javascript:void(0);'
			el.target = '_self'
		}
	}
}

var stat_info = function () {
	let s = {
		frame: null,
		counter: 0,
		build: ()=>{
			s.frame = {
				className: ['stat_info_box', 'visible', 'bg', 'border-1', 'br5'],
				children: [{
					className: ['h100p', 'flex-block', 'column'],
					children: [
						s.header = {
							className: ['flex-block', 'between10', 'table-row', 'slim', 'header', 'border-b'],
							children: [
								{className: ['w40', 'a-right'], text: 'stat:'},
								s.counter_frame = {className: ['flex-grow']},
							]
						},
						{
							className: ['flex-grow', 'scroll'],
							children: [s.list_frame = {
								className: ['flex-block', 'column', 'column-reverse']
							}]
						},
						{
							className: ['idler-popup-close', 'slim', 'btn', 'red', 'icon', 'remove'],
							events: {clickenter: s.show}
						}
					],
				}]
			}
			el_add_children(document.body, s.frame)
			move_handle(s.frame.el, s.header.el)
			document.addEventListener('yozhFetchResponse', function (e) {
				if (e.response_data && e.response_data.stat_info)
					s.add(e.response_data.stat_info)
			}.bind(this))
		},
		show: async ()=>{
			if (!s.frame)
				s.build()
			let response_data = await yozh_fetch({
				url: script_url + 'site/stat',
			})
			if (response_data.site_stat_show)
				s.frame.el.classList.add('visible')
			else
				s.frame.el.classList.remove('visible')
		},
		add: function (data) {
			if (!s.frame) {
				s.build()
				s.frame.el.classList.add('visible')
			}

			s.counter_frame.el.innerHTML = ++ s.counter

			let stst_info_report = ce({
				children: Object.keys(data).map(function (i) {return {
					className: ['flex-block', 'between10', 'table-row', 'slim', i==='request_time'?'header':'color'],
					children: [
						{className:['w40', 'a-right'], text: i==='request_time' ? null : i+':'},
						data[i] instanceof Object ? {className: 'w80', text: data[i].count || data[i].mem} : {className: ['flex-grow', 'ellipsis'], text: data[i]},
						data[i] instanceof Object ? {className: 'flex-grow', text: data[i].time_str} : null,
					]
				}})
			})

			s.list_frame.el.appendChild(stst_info_report)
		}
	}
	return s
}()
