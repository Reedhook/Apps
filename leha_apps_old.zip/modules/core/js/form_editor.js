// options = [data, field_list, (data_localisation, field_localisation, )(hidden_field_list, field_title_width, title, item_name, form_view_only)]
function build_edit_form (options) {
	let field_title_width = options.field_title_width || 200,
		hidden_field_list = Object.assign({action: 'save', item_id: options.data.id||''}, options.hidden_field_list || null)

	options.input_list = {}

	if (!options.hasOwnProperty('input_name'))
		options.input_name = 'data'

	let localisation_options = options.field_localisation ? Object.assign({}, options, {
			field_list: options.field_localisation,
			data: options.data_localisation,
			field_type: 'localisation',
		}) : false

	let structure = {field_list: {}}
	structure.form = {
		tagName: 'form',
		className: 'flex-block column h100p',
		attributes: {method: 'post', action: 'javascript: void(0)'},
		children: Object.keys(hidden_field_list).map(function(i){ return options.input_list[i] = {
				tagName: 'input',
				attributes: {type: 'hidden', name: i, value: hidden_field_list[i]}
			}}).concat([
			structure.header = {
				className: ['table-header'].concat(options.title_className ? options.title_className : null),
				children: [
					{
						className: ['table-row'],
						text: options.title ||
							(options.form_view_only ? '' : (options.data.id ? lang(options.lang, 'edit') : lang(options.lang, 'create'))) +
							(options.item_name ? ' ' + lang(options.lang, options.item_name) : ''),
					}
				],
			},
			structure.field_panel = {
				className: ['flex-grow', 'flex-block', 'column', 'scroll'],
				children: (options.header_rows ? options.header_rows : [
					options.data.id ? {
						className: 'table-row color flex-block between5 c-gray',
						children: [
							{
								className: 'w' + field_title_width + ' a-right',
								text: lang(options.lang, 'id') + ': '
							},
							{
								text: options.data.id || ''
							}
						]
					} : null,
				]).concat(
					options.field_localisation ? Object.keys(options.field_localisation).map(function(f){return structure.field_list[f] = build_edit_form_row(localisation_options, f)}) : null,
//					options.field_list ? Object.keys(options.field_list).map(function(f){return build_edit_form_row(options, f)}) : null
					options.field_list ? build_edit_form_rows(options, structure.field_list) : null
				)
			},
			{
				className: ['table-header'],
				children: [
					structure.btn_panel = {
						className: ['table-row', 'flex-block', 'right', 'between5'],
						children: [
							options.form_view_only ? structure.btn_ok = {
								className: ['btn'],
								attributes: {
									'data-action': 'ok',
									tabindex: 0,
								},
								text: lang(options.lang, 'ok')
							} : structure.btn_save = {
								className: ['btn'],
								attributes: {
									'data-action': 'save',
									tabindex: 0,
								},
								text: lang(options.lang, 'save')
							}
						]
					},
				],
			}
		])
	}
	structure.input_list = options.input_list

	return options.return_structure ? structure : structure.form
}
function build_edit_form_rows (options, structure=false) {
	let rows = []
	for (let field_name in options.field_list) {
		if (!options.field_list[field_name])
			continue
		let field_type = /*options.field_type ||*/ options.field_list[field_name].type

		if (options.field_divider_list && options.field_divider_list[field_name]) {
			let field_title_width = options.field_title_width || 200
			rows.push({
				className: ['table-row', 'header', 'slim', 'flex-block'],
				children: [
					{
						className: ['w'+field_title_width, 'a-right', 'nowrap'],
						text: lang(options.lang, options.field_divider_list[field_name])
					},
				],
			})
		}

		if (field_type==='json') {
			rows = rows.concat(build_edit_form_rows (Object.assign({}, options, {
				data:		options.data[field_name] || {},
				field_list:	options.json_map[field_name],
				lang:		options.lang || {},
				enum:		options.enum || {},
				input_name: options.input_name ? options.input_name + '[' + field_name  + ']' : field_name,
			}), structure))
		} else {
			let row_structure = build_edit_form_row (options, field_name)
			if (structure)
				structure[field_name] = row_structure
			rows.push(row_structure)
		}
	}
	return rows;
}
function build_edit_form_row (options, field_name) {
	let field_title_width = options.field_title_width || 200,
		r = options.field_list[field_name],// || options.field_localisation[field_name],
		title = r.title || field_name,
		translate = options.field_list[field_name].no_translate ? false : true,
		field_type = options.field_type
			|| (options.field_list && options.field_list[field_name] ? (options.field_list[field_name].ref ? 'ref' : options.field_list[field_name].type) : false)
			|| 'str'

	if (window['build_edit_form_row_'+field_type] && window['build_edit_form_row_'+field_type] instanceof Function)
		return window['build_edit_form_row_'+field_type](options, field_name)

	return {
		className: ['table-row',  options.no_color ? null : 'color', 'flex-block', 'between5', 'input-block', r.view_only || options.form_view_only? 'c-gray' : null],
		children: [
			{
				className: ['w'+field_title_width, 'a-right', 'overflow', 'nowrap'].concat(r.description ? ['icon', 'icon-left-h30', 'info', 'icon-color-disabled'] : null),
				attributes: r.description ? {title: translate ? lang(options.lang, r.description) : r.description} : null,
				text: (translate ? lang(options.lang, title) : title)+ ': ',
			},
			build_edit_form_input(options, field_name)
		]
	}
}

function build_edit_form_input (options, field_name) {
	let input_name = options.input_name ? options.input_name + '[' + field_name  + ']' : field_name,
		field_type = options.field_type
			|| (options.field_list && options.field_list[field_name] ? (options.field_list[field_name].ref ? 'ref' : options.field_list[field_name].type) : false)
			|| 'str',
		value = options.value
			|| (options.data ? options.data[field_name] : false)
			|| (options.field_list && options.field_list[field_name] && options.field_list[field_name].value ? options.field_list[field_name].value : false)
			|| '',
		view_only = options.form_view_only
			|| (options.field_list && options.field_list[field_name] && options.field_list[field_name].view_only ? true : false)
			|| false

	if (!window['build_input_'+field_type] || !window['build_input_'+field_type] instanceof Function) {
		console.log('Custom error: unknown function '+'build_input_'+field_type)
		return null
	}

	return window['build_input_'+field_type](options, field_name, input_name, value, view_only)
}
function form_show_errors (wraper, response_data) {
	for(let i of wraper.querySelectorAll('.err'))
		i.classList.remove('err')
	for(let i of wraper.querySelectorAll('.err-msg'))
		i.classList.add('display-none')

	let shown = {}
	for(let i in response_data.err) {
		let el = wraper.querySelector('[name^="data['+i+']"]') || wraper.querySelector('[name="'+i+'"]'),
			input_box = el ? el.closest('.input-box') : null,
			row = el ? el.closest('.input-block') : null
		if (row) {
			row.classList.add('err')
			shown[i] = true
			if  (response_data.err[i]!==1) {
				let err_msg = input_box ? (input_box.querySelector('.err_msg') || ce({parentNode: input_box, className: 'err-msg display-none'})) : null
				if (err_msg) {
					err_msg.classList.remove('display-none')
					err_msg.innerHTML = response_data.err[i]
				}
			}
		}
	}

	let notification_list = []
	for(let i in response_data.err) {
		if (!shown[i])
			notification_list.push({
				className: 'table-row color flex-block between5',
				children: [
//					{
//						className: 'w120 a-right',
//						text: i+':',
//					},
					{
						className: 'flex-grow',
						text: response_data.err[i],
					},
				]
			})
	}
	if (notification_list.length>0)
		yozh_notify({
			children: notification_list,
		})

	if (response_data.err_code && response_data.msg)
		yozh_notify({text: response_data.msg})
}

//----------------------------------------------------------------------------------------------------------------------
//-- build_input functions ---------------------------------------------------------------------------------------------
var build_input_str = build_input_int = build_input_float = build_input_money = build_input_byte = function  (options, field_name, input_name, value, view_only) {
	return view_only ? (options.field_list[field_name].view_copy || options.field_list[field_name].view ? {
		className: 'flex-grow flex-block overflow between5',
		children: [
			{className: 'input', text: value},
			options.field_list[field_name].view_copy ? { // иконка для копирования содержимого
				className: 'btn icon copy',
				attributes: {title: lang(options.lang, ['copy', 'value'])},
				events: {clickenter: ()=>{
					let i = ce({tagName: 'input', attributes: {type: 'text', value: value}, parentNode: document.body, styles: {position: 'absolute', opacity: 0}})
					i.focus()
					i.select()
					document.execCommand('copy')
					i.remove()
				}}
			} : null,
			options.field_list[field_name].view ? { // иконка со всплывающим окном, для отображения содержимого, сделано для длинных строк, не влазящих в видимую область инпута
				className: 'btn circle icon info',
				events: {clickenter: (e)=>{click_popup(e, {text: value})}}
			} : null
		]
	} : {
		className: 'input', text: value
	}) : {
		className: 'input-box flex-grow',
		children: [
			options.input_list[field_name] = {
			tagName: 'input',
			attributes: {
				type: 'text',
				name: input_name,
				value: value
			}
		}]
	}
}
var build_input_password = function  (options, field_name, input_name, value, view_only) {
	return view_only ? {className: 'input'} : {
		className: 'input-box flex-grow',
		children: [
			options.input_list[field_name] = {
				tagName: 'input',
				attributes: {
					type: 'password',
					name: input_name,
				}
			}
		]
	}
}
var build_input_readonly = function  (options, field_name, input_name, value, view_only) {
	return view_only ? {className: 'input', text: value} : {
		className: 'input-box flex-grow',
		children: [
			options.input_list[field_name] = {
				tagName: 'input',
				attributes: {
					type: 'text',
					name: input_name,
					value: value,
					readonly: true,
				}
			}
		]
	}
}

var build_input_hidden = function  (options, field_name, input_name, value, view_only) {
	return options.input_list[field_name] = {
		tagName: 'input',
		attributes: {
			type: 'hidden',
			name: input_name,
			value: value
		}
	}
}
var build_input_text = function  (options, field_name, input_name, value, view_only) {
	let html_fl = options.field_list && options.field_list[field_name] && options.field_list[field_name].html
	return view_only ?
		{
			className: html_fl ? ['scroll', 'h200', 'bg-white', 'w100p'] : ['textarea', 'pre'],
			[html_fl ? 'html' : 'text']: value
		} : {
			className: 'input-box flex-grow',
			children: {
				className: 'input-box',
				children: [options.input_list[field_name] = {
					tagName: 'textarea',
					attributes: {name: input_name},
					text: value,
				}]
			}
		}
}
var build_input_tinymce = function  (options, field_name, input_name, value, view_only) {
	let html_fl = options.field_list && options.field_list[field_name] && options.field_list[field_name].html
	return view_only ? {
			className: html_fl ? ['scroll', 'bg-white', 'w100p'] : ['textarea'],
			[html_fl ? 'html' : 'text']: value
		} : {
				className: 'input-box flex-grow flex-block column',
				children: [
					options.input_list[field_name] = {
						//styles: {width: '400px'},
						className: ['w100p', 'flex-grow'],
						tagName: 'textarea',
						attributes: {name: input_name},
						text: value,
					},
					{
						className: ['table-row', 'flex-block', 'right'],
						children: {
							className: ['btn', 'orange', 'slim'],
							text: lang(options.lang, 'insert_img'),
							events: {clickenter: file_list_show.bind(null, {
								title: lang(options.lang, 'select_img'),
								filters: {mime_type_like: 'image'},
								select_fn: function(records) {
									let file_id = Object.keys(records)[0]
									tinymce.activeEditor.execCommand('mceInsertContent', false, "<img src='" + records[file_id].url + "' />");
								},
								select_mode: 1,
								image_mode: true,
							})},
						}
					}
				]
			}
}

var build_input_bool = build_input_checkbox = function  (options, field_name, input_name, value, view_only) {
	return {
		className: 'input-box input-box-checkbox flex-grow flex-block between10',
		children: {
			tagName: 'label',
			className: 'flex-grow checkbox',
			children: [
				options.input_list[field_name] = {
					tagName: 'input',
					attributes: Object.assign(
						{
							type: 'checkbox',
							name: input_name,
							value: 1,
						},
						value ? {checked: true}: null,
						view_only ? {disabled: true} : null
					)
				},
				{}
			]
		}
	}
}
var build_input_select = function  (options, field_name, input_name, value, view_only) {
	let select_list = options.select_list || options.field_list[field_name].select_list || {}

	return view_only ? {className: 'input', text: select_list.hasOwnProperty(value) ? lang(options.lang, select_list[value]) : value} : {
		className: 'input-box flex-grow',
		children: [
			options.input_list[field_name] = {
				tagName: 'select',
				attributes: {
					name: input_name,
				},
				children: Object.keys(select_list).map(function(v) {
					let v_str = select_list.hasOwnProperty(v) ? select_list[v] : false
					return {
						tagName: 'option',
						attributes: Object.assign({value: v}, value==v ? {selected: true} : null),
						text: options.no_translate ? v_str : lang(options.lang, v_str),
					}})
			},
		]
	}
}
build_input_select_lang = function (options, field_name, input_name, value, view_only) {
	let new_options = Object.assign({}, options, {no_translate: true})
	return build_input_select(new_options, field_name, input_name, value, view_only);
}
var build_input_yes_no = function  (options, field_name, input_name, value, view_only) {
	let new_options = Object.assign({}, options, {select_list: {
		all: 'all',
		'1': 'yes',
		'0': 'no',
	}})
	return build_input_select(new_options, field_name, input_name, value, view_only)
}
var build_input_enum = function  (options, field_name, input_name, value, view_only) {
	let enum_name = options.field_list[field_name].enum_name || field_name,
		new_options = Object.assign({}, options, {
			select_list: options.enum[enum_name],
			no_translate: options.field_list[field_name].no_translate ? true : false
		})
	return build_input_select(new_options, field_name, input_name, value, view_only)
}
var build_input_enum_multiselect = function  (options, field_name, input_name, value, view_only) {
	let value_array = value instanceof Object ? Object.keys(value).map(function(i){return Number(value[i])}) : [],
		translate = options.field_list[field_name].no_translate ? false : true,
		column = options.field_list[field_name].column ? true : false

	options.input_list[field_name] = {}

	return {
		className: 'input-box flex-grow',
		children: {
			className: ['flex-grow', 'flex-block'].concat(column ? ['column', 'between2'] : ['wrap', 'between10']),
			children: Object.keys(options.enum[field_name]).map(function(i) {
				let value_i = value_array.indexOf(Number(i)) !== -1,
					title = options.enum[field_name][i]
				return {
					tagName: 'label',
					className: ['checkbox', 'right', column?'flex-grow':null],
					children: [
						{text: translate ? lang(options.lang, title) : title},
						options.input_list[field_name][i] = {
							tagName: 'input',
							attributes: Object.assign(
								{
									type: 'checkbox',
									name: input_name + '[' + i + ']',
									value: 1,
								},
								value_i ? {checked: true} : null
							)
						},
						{}
					]
				}
			})
		}
	}
}
var build_input_date = function  (options, field_name, input_name, value, view_only) {
	let value_str = options.data[field_name+'_str'] || options.data[field_name] || '',
		input

	return view_only ? {className: 'input', text:  value_str} : {
		className: 'input-box flex-grow flex-block',
		children: [
			options.input_list[field_name] = input = {
				tagName: 'input',
				className: ['date', 'right-flat'],
				attributes: {
					type: 'text',
					name: input_name,
					value: value_str,
					autocomplete: 'off',
				},
			},
			{
				className: ['btn', 'icon', 'calendar', 'left-flat'],
				events: {
					click: (e)=>{yozh_calendar_popup(e, {
						value: input.el.value,
						on_select: (d)=>{input.el.value=date_to_format(d)}
					})}
				},
			},
		]
	}
}
var build_time_selects = function(input_name, value) {
	let time_array = typeof(value)==='object' ? ['', value.h||0, value.i||0, value.s||0]
			: (
				value.match(/^(\d{2}):(\d{2}):(\d{2})$/)
				|| value.match(/^(\d{2}):(\d{2}):(\d{2})\.\d*$/)
				|| value.match(/^(\d{2}):(\d{2})$/)
				|| ['', 0, 0, 0]
			),
		selects = [],
		options_map = {h: {array_index: 1, count: 24}, i: {array_index: 2, count: 60}, s: {array_index: 3, count: 60}}

	for (let n in options_map) {
		selects.push({
			tagName: 'select',
			attributes: {name: input_name + '['+n+']'},
			children: Array(options_map[n].count).fill().map(function(v, index){ return {
				tagName: 'option',
				attributes: Object.assign(
					{value: index},
					index===(time_array && time_array[options_map[n].array_index] ? Number(time_array[options_map[n].array_index]) : 0) ? {selected: true} : null
				),
				text: (index<10 ? '0':'') + index
			}})
		})
	}
	return {className: 'select_time', children: selects}
}
var build_input_time = function  (options, field_name, input_name, value, view_only) {
	return view_only ? {
		className: 'input disabled',
		text: options.data[field_name+'_str'] || options.data[field_name] || ''
	} : {
		className: 'input-box flex-grow flex-block between5',
		children: build_time_selects(input_name, value)
	}
}
var build_input_datetime = function  (options, field_name, input_name, value, view_only) {
	let datetime = options.data[field_name+'_str'] || options.data[field_name] || ''
	if (view_only)
		return {
			className: 'input disabled',
			text: datetime
		}

	let date_time_str = datetime.match(/^(.*?) (\d{2}:\d{2}:\d{2})$/) || datetime.match(/^(.*?) (\d{2}:\d{2})$/) || ['', '', ''],
		input

	return {
		className: 'input-box flex-grow flex-block between5',
		children: [
			{
				className: ['flex-block'],
				children: [
					input = {
						tagName: 'input',
						className: ['date', 'right-flat'],
						attributes: {
							type: 'text',
							name: input_name + '[date]',
							value: date_time_str[1],
							autocomplete: 'off',
						},
					},
					{
						className: ['btn', 'icon', 'calendar', 'left-flat'],
						events: {
							click: (e)=>{yozh_calendar_popup(e, {
								value: input.el.value,
								on_select: (d)=>{input.el.value=date_to_format(d)}
							})}
						},
					}
				],
			}
		].concat(build_time_selects(input_name, date_time_str[2]))
	}
}
var build_input_ref = function  (options, field_name, input_name, value, view_only=false) {
	let js_call = options.js_call || options.field_list[field_name].js_call,
		js_call_filters = options.js_call_filters || options.field_list[field_name].js_call_filters || {},
		readonly = options.readonly || options.field_list[field_name].readonly || false,
		is_file = options.field_list && options.field_list[field_name] && options.field_list[field_name].ref==='\\file_db',
		is_file_protected = is_file  && options.field_list[field_name] && options.field_list[field_name].file_protected ? true : false,
		is_file_image = is_file  && options.field_list[field_name] && options.field_list[field_name].file_image ? true : false,
		s = {}

	if (typeof(js_call)==='string') {
		if (js_call==='model_table_db_list_show' && !js_call_filters.model)
			js_call_filters.model = options.field_list[field_name].ref

		if (window[js_call] instanceof Function)
			js_call = window[js_call]
	}
	if (!js_call instanceof Function) {
		if (!view_only) {
			console.log('there are no function: ' + js_call + ' for field: ' + field_name)
			return null
		}
	}

	return view_only || readonly ? {
		className: 'flex-grow flex-block between5',
		children: [
			readonly ? {
				tagName: 'input',
				attributes: {
					type: 'hidden',
					name: input_name,
					value: value,
				}
			} : null,
			{
				className: ['input', 'disabled'],
				text: options.data[field_name+'_str'] || ''
			},
			options.field_list && options.field_list[field_name] && options.field_list[field_name].ref==='\\file_db' ? {
				tagName: 'a',
				className: 'btn icon download' + (options.data[field_name + '_url'] ? '' : ' disabled'),
				attributes: {
					href: options.data[field_name + '_url'] ? options.data[field_name + '_url'] : 'javascript: void(0)',
					target: options.data[field_name + '_url'] ? '_blank' : '_self',
					title: lang(options.lang, 'download')
				},
			} : null,
		]
	} : {
		className: 'flex-grow flex-block between5',
		children: [
			{
				className: 'input-box flex-grow',
				children: [
					s.input = options.input_list[field_name] = {
						tagName: 'input',
						attributes: {
							type: 'hidden',
							name: input_name,
							value: value,
							value_first: value,
						}
					},
					s.div_link = {
						className: 'flex-grow input pointer ellipsis link',
						text: (options.data ? options.data[field_name+'_str'] : false) || value,
						attributes: {
							'value_first': (options.data ? options.data[field_name+'_str'] : false) || value,
							tabindex: 0,
						},
						events: {
							clickenter: js_call.bind(null, {
								filters: js_call_filters,
								title: options[field_name+'_title'] || options.field_title || lang(options.lang, 'select')+' '+lang(options.lang, options.field_list[field_name].title || field_name),
								select_mode: 1,
//								image_mode: is_file_image,
							})
						}
					}
				]
			},
			s.btn_info = {
				className: ['btn', 'icon', 'info', 'circle', value ? null : 'disabled'],
				attributes: {
					tabindex: 0,
					title: lang(options.lang, 'view'),
				},
				events: {clickenter: ()=>{
					if (options.input_list[field_name].el.value)
						js_call({
							filters: Object.assign({id: options.input_list[field_name].el.value}, js_call_filters),
							title: lang(options.lang, 'select')+' '+lang(options.lang, options.field_list[field_name].title || field_name),
//							image_mode: is_file_image,
						})
				}}
			},
			is_file ? s.btn_upload = {
				className: ['btn', 'icon', 'upload', is_file_protected ? 'blue' : null],
				children: {
					tagName: 'input',
					attributes: {type: 'file'},
					events: {change: field_file_upload.bind(null, is_file_protected ?  {data: {protected: true}} : {})}
				}
			} : null,
			is_file ? s.btn_download = {
				tagName: 'a',
				className: 'btn icon download' + (options.data[field_name + '_url'] ? '' : ' disabled'),
				attributes: {
					href: options.data[field_name + '_url'] ? options.data[field_name + '_url'] : 'javascript: void(0)',
					target: options.data[field_name + '_url'] ? '_blank' : '_self',
					title: lang(options.lang, 'download')
				},
			} : null,
			s.btn_clear = {
				className: ['btn', 'icon', 'remove', value ? null : 'disabled'],
				events: {clickenter: (e)=>{
					s.input.el.value = ''
					s.div_link.el.innerHTML = ''
					s.btn_info.el.classList.add('disabled')
					if (s.btn_download) {
						s.btn_download.el.href = 'javascript:void(0);'
						s.btn_download.el.classList.add('disabled')
						s.btn_download.el.target = '_self'
					}
					s.btn_clear.el.classList.add('disabled')
				}},
				attributes: {
					tabindex: 0,
					title: lang(options.lang, 'to_clear'),
				},
			},
		]
	}
}
var build_input_localisation = function  (options, field_name, input_name, value, view_only) {
	options.input_list[field_name] = {}
	return view_only ? {className: 'input', text: value[options.lang_cur] || '' } : {
		className: 'flex-block vert between5 flex-grow',
		children: Object.keys(options.lang_list).map(function (i){
			let lang_name = options.lang_list[i]
			return {
				className: 'flex-block between5',
				children: [
					{
						className: ['w20'],
						text: lang_name,
					},
					options.input_list[field_name][lang_name] = {
						tagName: 'input',
						attributes: {
							type: 'text',
							name: input_name + '[' + lang_name + ']',
							value: value[lang_name] || ''
						}
					},
				]
			}
		})
	}
}

//----------------------------------------------------------------------------------------------------------------------
function lang (dict, name, noCaps) {
	if (name===false)
		return ''

	if (Array.isArray(name)) {
		return name.map((n, i)=>{
			return lang(dict, n, i===0 ? noCaps : true)
		}).join(' ')
	}

	if (dict.hasOwnProperty(name))
		return noCaps ? dict[name] : dict[name].firstLetterCaps()

	return isFinite(name) ? name : name + ' (no translate)'
}
