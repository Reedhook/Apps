/**
 * Creates a dom Element from structure
 *
 * @params node = {
 tagName:		string (default 'div')
 parentNode:	dom_element,
 className:		string|array,
 attributes:	{k: string, ....},
 properties:	{k: string, ....},
 styles:		{k: string, ....},
 events:		{event_name: function, ...},
 html:			HTML_text,
 children|child|text: dom_element|array|json_object|text,
}
 * return DOM element
 **/
function ce (node) {
	//-- tagName
	let el = document.createElement(typeof(node.tagName)==='string' ? node.tagName : 'div')

	//-- parentNode
	if (node.parentNode instanceof Element)
		node.parentNode.appendChild(el)

	//-- html
	if (typeof(node.html)==='string')
		el.innerHTML = node.html

	//-- className
	if (typeof (node.className) !== 'undefined') {
		if (typeof(node.className) === 'string')
			node.className = node.className.split(/\s+/)
		if (Array.isArray(node.className)) {
			for (let i of node.className)
				if (typeof(i) === 'string' && i.length>0)
					el.classList.add(i)
		}
	}

	//-- attributes
	if (typeof(node.attributes) === 'object' && node.attributes !== null)
		for (let i in node.attributes)
			if (typeof(i) === 'string' || typeof(i) === 'number')
				el.setAttribute(i, node.attributes[i])

	//-- properties
	if (typeof(node.properties) === 'object' && node.properties !== null)
		for (let i in node.properties)
			el[i] = node.properties[i]
//			Object.defineProperty(el, i, {value: node.properties[i]})

	//-- styles
	if (typeof(node.styles)==='object' && node.styles!==null)
		for (let i in node.styles)
			if (typeof(node.styles[i])==='string' || typeof(node.styles[i])==='number')
				el.style[i] = node.styles[i]

	//-- events
	if (typeof(node.events)==='object' && node.events!==null)
		for (let event_name in node.events)
			el_add_event(el, event_name, node.events[event_name])

	//-- HTML
	if (node.hasOwnProperty('html') && node.html!==null)
		el.innerHTML = node.html

	//-- children | text
	let data = node.children || node.text
	if (typeof (data) !== 'undefined')
		el_add_children(el, data)

	node.el = el

	return el
}
/**
 * adds event to DOM element
 * @param {DOM element}		el
 * @param {str}				event_name
 * @param {Function|Array}	handler
 */
function el_add_event(el, event_name, handler) {
	if (handler instanceof Function) {
		if (event_name==='clickenter') {
			el.addEventListener('click', function(e){if (e.which===1 || e.button===1) {handler(e)}})
			el.addEventListener('keyup', function(e){if (e.keyCode===13 || e.keyCode===32) {handler(e)}})
		} else if (event_name==='link_click') { // для перехвата нажатия на ссылку
			el.addEventListener('click', function(e){if (e.which===1 || e.button===1) {e.preventDefault(); handler(e)}})
			el.addEventListener('keyup', function(e){if (e.keyCode===13 || e.keyCode===32) {e.preventDefault(); handler(e)}})
		} else if (event_name==='wheelclick') { // нажатие колесом мыши
			el.addEventListener('click', function(e){if (e.which===2 || e.button===2) handler(e)})
		} else {
			if (Array.isArray(handler)) {
				for(let i of handler)
					el.addEventListener(event_name, i)
			} else {
				el.addEventListener(event_name, handler)
			}
		}
		return
	}
	if (handler instanceof Array)
		for(let i in handler)
			el_add_event(el, event_name, handler[i])
}

/**
 * adds data to DOM element
 * @param el
 * @param data = DOM element | string | number | array | object(like ce(node))
 */
function el_add_children (el, data) {
	if (data instanceof Element) {
		el.appendChild(data)
	} else if (typeof(data)==='string' || typeof(data)==='number') {
		el.appendChild(document.createTextNode(data))
	} else if (Array.isArray(data)) {
		for (let i=0; i<data.length; i++)
			el_add_children(el, data[i])
	} else if (typeof(data)==='object' && data!==null) {
		el.appendChild(ce(data))
	}
}

/**-- tooltips ---------------------------------------------------------------------------------------------------------
 *
 sets - tooltips
 params:
 parent		- default document
 attr_text	- default 'title' // works only with attributes (not with properties)
 css		- default see in _tooltip.scss
 indent		- default {x: 15, y: -5}
 */
function yozh_tooltip(_params) {
	this.tooltip_box = ce({parentNode: document.body, className: 'tooltip-box'});

	this.params = {
		parent:			document.body,
		attr_text:		'title',
		indent:			{x: 15, y: 5},
		prepare_auto:	false,
	}
	if (typeof(_params)!='undefined')
		for (let i in _params)
			if (this.params.hasOwnProperty(i))
				this.params[i] = _params[i];

	this.move_to = function(mouse_x, mouse_y) {
		let x = mouse_x + this.params.indent.x,
			y = mouse_y + this.params.indent.y,
			x_correct_fl = false

		if ((x + this.tooltip_box.offsetWidth + this.params.indent.x + 10) > document.body.clientWidth) {
			x = document.body.clientWidth - this.tooltip_box.offsetWidth - (this.params.indent.x + 10);
			y += 15;
			x_correct_fl = true
		}
		if ((y + this.tooltip_box.offsetHeight + this.params.indent.y + 10) > document.body.clientHeight) {
			y = document.body.clientHeight - this.tooltip_box.offsetHeight - (this.params.indent.y + 10);
			if (x_correct_fl)
				x = mouse_x - this.tooltip_box.offsetWidth - (this.params.indent.x);
		}

		this.tooltip_box.style.left = x + 'px';
		this.tooltip_box.style.top = y + 'px';
	}

	this.tooltip_mouse_move = function(ev) {
		if (!ev)
			ev = window.event;
		let x = ev.pageX ? ev.pageX : (ev.clientX ? ev.clientX + (document.documentElement.scrollLeft || document.body.scrollLeft) - document.documentElement.clientLeft : false);
		let y = ev.pageY ? ev.pageY : (ev.clientY ? ev.clientY + (document.documentElement.scrollTop || document.body.scrollTop) - document.documentElement.clientTop : false);
		if (x === false || y === false)
			return;
		this.move_to(x, y)
	}.bind(this)

	this.show_tooltip = function (el, ev) {
		let attr_text = this.params.attr_text==='title' ? 'data-tooltip' : this.params.attr_text,
			text = el.getAttribute(attr_text)

		if (!text || text.length===0)
			return

		this.tooltip_box.innerHTML = text
		this.tooltip_mouse_move()
		document.addEventListener('mousemove', this.tooltip_mouse_move)

		this.tooltip_box.classList.add('tooltip-box-visible')

		let box = this.tooltip_box.getBoundingClientRect()
		this.move_to(box.left, box.top)
	}

	this.hide_tooltip = function (el, ev) {
		document.removeEventListener('mousemove', this.tooltip_mouse_move);
		this.tooltip_box.classList.remove('tooltip-box-visible');
	}

	this.set = function(parent) {
		if (!parent) {
			if (!this.params.parent)
				return
			parent = this.params.parent
		}

		if (parent)
			for (let el of parent.querySelectorAll('[' + this.params.attr_text + ']'))
				this.set_one(el)
	}

	this.set_one = function(el) {
		if (!el.yozh_tooltip) {
			if (!el.hasAttribute(this.params.attr_text))
				return

			if (this.params.attr_text==='title' ) {
				el.setAttribute('data-tooltip', el.getAttribute('title'))
				el.removeAttribute('title')
			}

			el.addEventListener('mouseover', this.show_tooltip.bind(this, el));
			el.addEventListener('mouseout', this.hide_tooltip.bind(this, el));
			el.addEventListener('DOMNodeRemovedFromDocument', this.hide_tooltip.bind(this));

/*			let observer = new MutationObserver((mutations)=>{
				for (const mutation of mutations) {
					for (const node of mutation.removedNodes) {
						if (el === node) {
							this.hide_tooltip.bind(this)
						}
					}
				}
				this.hide_tooltip.bind(this)
			})
			observer.observe(el, {childList: true})
*/
			el.yozh_tooltip = this
		}
	}

	if (this.params.prepare_auto)
		this.set()
}
/*--------------------------------------------------------------------------------------------------------------------*/
//-- ajax --------------------------------------------------------------------------------------------------------------
async function yozh_fetch(_params) {
	let params = {
		url:		false,
		data:		{},
		form:		null,
		headers:	{},
		on_progress_fn: function(upload) {},
		on_success_fn: function(response_data, response_headers) {},
		on_err_fn:	function(status, err_data) {console.log(status, err_data)},
		method:		'POST',
//		files:		{},
		async:		true,
		response_methos:	'json',
	}
	for (let i in _params)
		if (typeof(params[i])!='udefined')
			params[i] = _params[i]

	let response = await fetch(params.url, {
		method: params.method, // или 'PUT'
		body: JSON.stringify(params.data), // данные могут быть 'строкой' или {объектом}!
		headers: Object.assign({'Content-Type': 'application/json'}, params.headers)
	})

	if (response.ok) {
		let response_data = await response[params.response_methos]()

		if (params.on_success_fn instanceof Function)
			params.on_success_fn(response_data, response.headers)

		let event = new Event('yozhFetchResponse', {bubbles: true, cancelable: true})
		event.response_data = response_data
		document.dispatchEvent(event)

		return response_data
	} else {
		if (params.on_err_fn instanceof Function)
			params.on_err_fn('yozh fetch error: ' + response.status)
		return false
	}
}

function yozh_ajax(_params) {
	let params = {
		url:		false,
		data:		{},
		form:		null,
		headers:	{},
		on_progress_fn: function(upload) {},
		on_success_fn: function(response_data, response_headers) {/*console.log(response_data)*/},
		on_err_fn:	function(status, err_data) {console.log(status, err_data)},
//		method:		'POST',
		files:		{},
		async:		true,
		json:		true
	}

	for (let i in _params)
		if (typeof(params[i])!='udefined')
			params[i] = _params[i];

	let xmlhttp = new XMLHttpRequest();

	xmlhttp.onreadystatechange = function() {
		params.on_progress_fn(xmlhttp.upload)
		if (xmlhttp.readyState !== 4)
			return;
		if (xmlhttp.status == 200) {
			let responseText = xmlhttp.responseText
			if (params.json)
				try {
					responseText = JSON.parse(responseText)
					if (responseText.stat_info && stat_info)
						stat_info.add(responseText.stat_info)
				} catch (e) {
					params.on_err_fn(xmlhttp.status, {err: 'returned not json string', 'url': params.url, responseText: responseText})
					return
				}
			let response_headers = {}
			xmlhttp.getAllResponseHeaders().split('\n').map( function(value, index, arr ) {
				let header = value.split(':');
				response_headers[header[0].trim()] = header[1] ? header[1].trim() : ''
			})
			params.on_success_fn(responseText, response_headers);
		} else {
			params.on_err_fn(xmlhttp.status, {err: xmlhttp.statusText, 'url': params.url})
		}
	}

	let form = params.form ? new FormData(params.form) : new FormData(),
		one_level_data = object_to_one_level(params.data) // convert many-levels object to one-level object
	for (let element_name in one_level_data)
		form.append(element_name, one_level_data[element_name]) // set one-level data to form

	if (params.files)
		if (params.files instanceof FileList || Array.isArray(params.files)) {
			for (let i=0, l=params.files.length; i<l; i++)
				form.append(i, params.files[i])
		} else {
			for (let i in params.files)
				form.append(i, params.files[i])
		}

	xmlhttp.open('POST', params.url, params.async);

	for (let i in params.headers)
		xmlhttp.setRequestHeader(i, params.headers[i]);

	xmlhttp.responseType = "text";

//	xmlhttp.contentType = false;
	xmlhttp.send(form);
}

function yozh_post_redirect(url, data) {
	let data_tree_to_input_line = function (data, prefix) {
		let line = [];
		for(let i in data) {
			let name = prefix ? prefix+'['+i+']' : i
			if (typeof(data[i])==='object') {
				if (data!==null)
					line = line.concat(data_tree_to_input_line(data[i], name))
			} else {
				line.push({
					tagName: 'input',
					attributes: {
						type: 'hidden',
						name: name,
						value: data[i]
					}
				})
			}
		}
		return line
	}

	let f = ce({
		tagName: 'form',
		parentNode: document.body,
		styles: {display: 'none'},
		attributes: {
			method: 'post',
			action: url,
			target: '_blank',
		},
		children: data_tree_to_input_line(data)
	})
	f.submit()
	f.remove()
}

/*-- uploads -----------------------------------------------------------------------------------------------------------
 uploads files
 params:
 url		- required		- string
 files		- required		- input_obj.files
 data		- not required	- obj (will send with each file)
 fn_progress- not required	- function({total_size, uploaded_size, files_uploaded}){}
 fn_finish	- not required	- function(files{[size, upload_size, err, response], [], ..}){}
 */
function yozh_uploader (params) {
	let files_count = params.files.length;

	if (!files_count) {
		if (typeof(params.fn_finish)=='function')
			params.fn_finish({});
		return;
	}

	let progress = {total_size: 0, uploaded_size: 0, files_uploaded: 0},
		progress_files = {};

	for (let i=0, l=params.files.length; i<l; i++) {
		progress.total_size += params.files[i].size;
		progress_files[i] = {
			size: 			params.files[i].size,
			upload_size:	0,
			err:			false,
			response:		null
		};
	}

	for (let i=0, l=params.files.length; i<l; i++)
		(function (j) {
			yozh_ajax({
				url: params.url,
				data: params.data,
				files: {file: params.files[j]},
				on_progress_fn: function(upload) {
					if (upload.lengthComputable) {
						progress.uploaded_size += upload.loaded - progress_files[j].upload_size;
						progress_files[j].upload_size = upload.loaded;
						if (typeof(params.fn_progress)=='function')
							params.fn_progress(progress);
					}
				},
				on_success_fn: function(responseText) {
					progress.uploaded_size += progress_files[j].size - progress_files[j].upload_size;
					delete(progress_files[j].upload_size);

					if (typeof(params.fn_progress)=='function')
						params.fn_progress(progress);
					progress.files_uploaded ++;

					progress_files[j].response = responseText;

					if (progress.files_uploaded==files_count) {
						if (typeof(params.fn_finish)=='function')
							params.fn_finish(progress_files);
					}
				},
				on_err_fn: function(status, err_data) {
					progress_files[j].err = true;
					progress.files_uploaded ++;
				}
			});
		}) (i);
}

//-- on dom ready ------------------------------------------------------------------------------------------------------
function yozh_DOMContentLoaded(f) {
	if (f instanceof Function) {
		if (document.readyState === "complete" || document.readyState === 'interactive') {
			f()
		} else {
			document.addEventListener("DOMContentLoaded", f, false)
		}
	}
}

//-- попап по клику ----------------------------------------------------------------------------------------------------
// создаётся попапчик по клику, который закрывается, если нажать на эту же кнопку или не в попап
function click_popup(event_btn_click={}, options={}) {

	let el = options.node || event_btn_click.target
	event_btn_click.click_popup_caller = el

	if (el.click_popup) { // если попап уже создан, закрываем попап
		el.click_popup.close()
		return false
	}

	let s = el.click_popup = {}, // фиксируем, что попап по кнопке создан
		document_click = (e)=>{
			if (e.click_popup_caller===el)
				return
			s.close()
		}

	s.build = function() {

		document.addEventListener('click', document_click) // добавляем событие на удаление по клику вне попапа

		s.frame = {
			parentNode: document.body,
			className: ['tooltip-box', 'tooltip-box-visible'].concat(options.className?options.className:null),
			events: {
				click: function (popup_click_event){popup_click_event.click_popup_caller=el},
			}, // фиксируем, что клик с попапа
		}

		if (options.children) {
			s.frame.children = options.children
		} else if (options.node) {
			s.frame.children = [options.node]
		} else if (options.html) {
			s.frame.children = [{html: options.html}]
		} else if (options.text) {
			s.frame.children = [{text: options.text}]
		} else if (el.hasAttribute('title')) {
			s.frame.children = [{text: el.getAttribute('title')}]
			el.removeAttribute('title')
		}

		ce(s.frame)
		s.set_position()
	}

	s.set_position = function() {
		let pos = options.pos || 'bottom-left',
			box = el.getBoundingClientRect(),
			indent = {x:5, y:5},
			x=0, y=0

		if (pos==='right-top') { // справа от элемента выравниваем по верху
			x = box.left + el.offsetWidth + indent.x
			y = box.top
		}
		if (pos==='left-top') { // слева от элемента выравниваем по верху
			x = box.left - s.frame.el.offsetWidth - indent.x
			y = box.top
		}
		if (pos==='bottom-right') { // снизу от элемента выравниваем по правому краю
			x = box.left + el.offsetWidth - s.frame.el.offsetWidth
			y = box.top + box.height + indent.y
		}
		if (pos==='bottom-left') { // снизу от элемента выравниваем по левому краю
			x = box.left
			y = box.top + box.height + indent.y
		}

		if ((x + s.frame.el.offsetWidth + 10) > document.body.clientWidth)
			x = document.body.clientWidth - s.frame.el.offsetWidth - 5

		if ((y + s.frame.el.offsetHeight + 15) > document.body.clientHeight)
			y = document.body.clientHeight - s.frame.el.offsetHeight - 10


		s.frame.el.style.left = x + 'px';
		s.frame.el.style.top = y + 'px';
	}

	s.close = function() {
		document.removeEventListener('click', document_click)
		s.frame.el.remove()
		delete el.click_popup
//		if (el.o.onDestroy instanceof Function)
//			el.o.onDestroy()
	}

	s.build()

	return true
}

//-- notification ------------------------------------------------------------------------------------------------------
async function yozh_notify(options={}) {
	let popup = yozh_popup(options.popup || {}),
		popup_close = (action)=>{
			document.removeEventListener('keydown', keydown_listener)
			popup.close()
			if (options.on_close instanceof Function)
				options.on_close()
			if (action==='ok' && options.on_ok instanceof Function)
				options.on_ok()
			if (action==='no' && options.on_no instanceof Function)
				options.on_no()
		},
		structure = {},
		keydown_listener = (e)=>{
			if (e.keyCode===13)
				popup_close('ok')
			if (e.keyCode===27)
				popup_close('no')
		}

	document.addEventListener('keydown', keydown_listener)
	popup.wrapper.el.addEventListener('click', (e)=>{if (e.popup!==popup) popup_close()})
	popup.content.el.addEventListener('click', (e)=>{e.popup = popup})
	popup.content.el.classList.add('flex-grow', 'flex-block', 'column', 'h100p')

	popup.set([
		{
			className: ['table-header'],
			children: [
				structure.header = {
					className: ['table-row', 'relative'],//.concat(options.title_className || ['icon', 'icon-left-h30', 'exclamation']),
					html: options.title || '&nbsp;',
				}
			],
		},
		{
			className: ['flex-block', 'column', 'scroll', 'popup-bg'].concat(options.text_className || (options.text ? ['p20'] : null)),
			text: options.text || null,
			html: options.html || null,
			children: options.children || null,
		},
		{
			className: ['table-header'],
			children: [{
				className: ['table-row', 'flex-block', 'right', 'between5'],
				children: [
					{
						className: options.ok_className || 'btn',
						text: options.ok_text || 'Ok',
						events: {click: ()=>{popup_close('ok')}}
					},
					options.confirm_mode ? {
						className: options.no_className || 'btn',
						text: options.no_text || 'Cancel',
						events: {click: ()=>{popup_close('no')}},
					} : null
				]
			}],
		}
	])

	setTimeout(()=>{
		popup.show(popup)
		move_handle(popup.frame.el, structure.header.el)
		}, 1)
}

//-- popup -------------------------------------------------------------------------------------------------------------
var modal_count = 0
function yozh_popup (options={}) {
	let o = {
		fn_allow_close: null, // функция проверяющая, можно ли закрыть окно, передаём туда функцию закрытия
		fn_after_close: null,
		wait_on_create: true, // режим ожидания при создании
		parentNode: document.body,
		width: 600,
		height: 0,
		fullscreen: false,
		show: ()=>{
			o.wrapper.el.wait(false)
			o.wrapper.el.classList.add('visible')
			if (modal_count === 0)
				document.body.style.overflow = 'hidden'
			modal_count++
		},
		set: (data)=>{
			while (o.content.el.firstChild)
				o.content.el.firstChild.remove()
			el_add_children(o.content.el, data)
		},
		close: () => {
			if (o.fn_allow_close instanceof Function) {
				o.fn_allow_close(o.destroy)
				return
			}
			o.destroy()
		},
		destroy: () => {
			o.wrapper.el.classList.remove('visible')
			setTimeout(() => {
				if (o.wrapper.el instanceof Element) {
					let popupDestroy = new Event('popupDestroy', {bubbles: true, cancelable: true})
					o.wrapper.el.dispatchEvent(popupDestroy)
					o.wrapper.el.remove()
					document.removeEventListener('keydown', easy_exit_listener)

					modal_count--
					if (modal_count === 0)
						document.body.style.overflow = 'visible'

					if (o.fn_after_close instanceof Function)
						o.fn_after_close()
				}
			}, 200)
		},
	}

	let easy_exit_listener = (e)=>{
		if (e.keyCode===13)
			o.close()
		if (e.keyCode===27)
			o.close()
	}


	if (options.width==='100%') {
		options.width = 0
		options.fullscreen = true
	}
	for (let i in options)
		if (o.hasOwnProperty(i))
			o[i] = options[i]

	o.wrapper = {
		className: ['idler-popup'],
		children: [{
			className: o.fullscreen ? ['w100p', 'h100p'] : ['w100p', 'h100p', 'flex-block', 'column', 'center', 'middle'],
			children: [o.frame = {
				className: o.fullscreen ? ['idler-popup-frame', 'w100p', 'h100p'] : ['idler-popup-frame', 'flex-block', 'column'],
				children: [
					o.content = {
						className: ['idler-popup-content', 'flex-grow', 'flex-block', 'column', o.fullscreen ? 'h100p' : null],
						styles: o.fullscreen ? null : {
							width: o.width>0 ? (o.width>document.body.offsetWidth-40 ? document.body.offsetWidth-40 : o.width)+'px' : null,
							height: o.height>0 ? o.height+'px' : null,
						},
					},
					o.btn_close = {
						className: ['idler-popup-close', 'btn', 'red', 'icon', 'remove'],
						events: {clickenter: o.close}
					}
				]
			}]
		}]
	}

	if (typeof custom_yozh_popup !== 'undefined')
		custom_yozh_popup(options, o)

	el_add_children(o.parentNode, o.wrapper)
	o.wrapper.el.wait(true)

	if (options.easy_exit) {
		document.addEventListener('keydown', easy_exit_listener)
		o.wrapper.el.addEventListener('click', (e)=>{if (e.popup!==o) o.close()})
		o.content.el.addEventListener('click', (e)=>{e.popup = o})
	}

	return o
}
// перемещает obj в пределах своего родителя за handle
function move_handle(obj, handle) {
	let handle_data = {},
		move_handle_mousemove = (e)=>{
			let obj_x = obj.offsetLeft + (e.clientX - handle_data.clientX),
				obj_y = obj.offsetTop + (e.clientY - handle_data.clientY)
			handle_data.clientX = e.clientX
			handle_data.clientY = e.clientY

			if (obj_x+obj.offsetWidth > obj.parentNode.offsetWidth)
				obj_x = obj.parentNode.offsetWidth - obj.offsetWidth
			if (obj_x<0)
				obj_x = 0

			if (obj_y+obj.offsetHeight > obj.parentNode.offsetHeight)
				obj_y = obj.parentNode.offsetHeight - obj.offsetHeight
			if (obj_y<0)
				obj_y = 0

			obj.style.left = obj_x+'px'
			obj.style.top = obj_y+'px'
		},
		move_handle_mouseup = function(e) {
			document.removeEventListener('mousemove', move_handle_mousemove)
			document.removeEventListener('mouseup', move_handle_mouseup)
		},
		move_handle_mousedown = (e)=>{
			if (e.button===1) {
				obj.style.left = null
				obj.style.top = null
				obj.style.position = null
				obj.style.height = null
				return
			}
			if (obj.style.position!=='absolute') {
				obj.style.left = obj.offsetLeft + 'px'
				obj.style.top = obj.offsetTop + 'px'
				obj.style.position = 'absolute';
				if (obj.offsetHeight >= obj.parentNode.offsetHeight)
					obj.style.height = obj.parentNode.offsetHeight + 'px'
			}
			handle_data.clientX = e.clientX
			handle_data.clientY = e.clientY
			document.addEventListener('mousemove', move_handle_mousemove)
			document.addEventListener('mouseup', move_handle_mouseup)
			//this.options.move_handle.addEventListener('mouseout', this.move_handle_mouseup)

		}
	handle.classList.add('cursor-move')
	handle.addEventListener('mousedown', move_handle_mousedown)
}
//----------------------------------------------------------------------------------------------------------------------
String.prototype.firstLetterCaps = function() {
	return this.charAt(0).toUpperCase() + this.slice(1)
}
function array_shuffle(list) {
	let a = list.slice()
	for(let i = 0; i<a.length; i++) {
		let j = Math.floor(Math.random()*a.length), v = a[i]
		a[i] = a[j]
		a[j] = v
	}
	return a
}
/**
 * set value to object for key_list=[key1,key2,...]
 * result is object[key1][key2][...] = value
 *
 * @param {object}		object
 * @param {array}		key_list	[key1,key2,...]
 * @param {anything}	value
 * return {bool}
 */
function object_key_list_set_value (object, key_list, value) {
	if (!(key_list instanceof Array) || key_list.length===0)
		return false
	let key_name = key_list.shift()
	if (key_list.length>0)
		return object_key_list_set_value(object[key_name] || (object[key_name]={}), key_list, value)

	object[key_name] = value
	return true
}

/**
 * set value to object for key='name1[name2][...]'
 * result is object[key1][key2][...] = value
 *
 * @param {object}		object
 * @param {string}		key
 * @param {anything}	value
 * return {bool}
 */
function object_key_set_value(object, key, value) {
	if (typeof(key)!=='string')
		return false
	let key_list = key.match(/[^\[\]]+/g)
	return object_key_list_set_value(object, key_list, value)
}

/**
 * make one-level object from many-levels object
 *
 * @param {object|array}	data	{a: {b: c}, d: {e: f}}
 * return {object}					{a[b]: c, d[e]: f}
 */
function object_to_one_level (data, key_prefix=false, obj={}) {
	let is_array = Array.isArray(data)

	for (let i in data) {
		if (is_array && !(data.hasOwnProperty(i) && /^\d+$/.test(i) && i<=4294967294))
			continue

		let value = data[i],
			key = key_prefix ? key_prefix + '['+i+']' : i

		if (typeof(value)==='object' && value!==null) {
			object_to_one_level(value, key, obj)
		} else {
			obj[key] = value
		}
	}
	return obj
}

//-- date --------------------------------------------------------------------------------------------------------------
function format_to_date(format_str, options={}) {
	let format = (options.hasOwnProperty('format') ? options.format : date_format).toLowerCase(),
		re_str = '^',
		map_counter = 1,
		map = {y: 0, m: 0, d: 0, h: 0, i: 0, s: 0, ms: 0},
		a = {y: 0, m: 0, d: 0, h: 0, i: 0, s: 0, ms: 0}

	for(let i of format) {
		if (i==='y') {
			re_str += '(\\d\\d\\d\\d)'
			map.y = map_counter++
		} else if (i==='m') {
			re_str += '(\\d\\d)'
			map.m = map_counter++
		} else if (i==='d') {
			re_str += '(\\d\\d)'
			map.d = map_counter++
		} else if (i==='h') {
			re_str += '(\\d\\d)'
			map.h = map_counter++
		} else if (i==='i') {
			re_str += '(\\d\\d)'
			map.i = map_counter++
		} else if (i==='s') {
			re_str += '(\\d\\d)'
			map.s = map_counter++
		} else {
			re_str += i
		}
	}
	re_str += '$'
	re_str = re_str.replace(/\./g, '\\.')
	re_str = re_str.replace(/\//, '\\/')

	let re = new RegExp(re_str),
		matches = re.exec(format_str)

	for(let i in map) if (map[i]>0) {

		try {
			a[i] = parseInt(matches[map[i]])
		} catch (e) {
			return false
		}

		if (i==='m')
			a[i]--
	}

	return new Date(a.y, a.m, a.d, a.h, a.i, a.s, a.ms)
}
function date_to_format(d, format) {
	if (!format)
		format = date_format
	let format_str = ''

	for(let i of format) {
		if (i==='Y') {
			format_str += d.getFullYear()
		} else if (i==='m') {
			let n = d.getMonth()+1
			format_str += (n<10 ? '0':'') + n
		} else if (i==='d') {
			let n = d.getDate()
			format_str += (n<10 ? '0':'') + n
		} else {
			format_str += i
		}
	}
	return format_str
}
function getLastDayOfMonth(d) {
	let d2 = new Date(d.getFullYear(), d.getMonth()+1, 0, d.getHours(), d.getMinutes(), d.getSeconds(), d.getMilliseconds())
	return d2.getDay()
}

function date_console(d) {
	console.log({
		Y: d.getFullYear(),
		m: d.getMonth()+1,
		d: d.getDate(),
		h: d.getHours(),
		i: d.getMinutes(),
		s: d.getSeconds(),
		ms: d.getMilliseconds()
	})
}
//-- calendar ----------------------------------------------------------------------------------------------------------
/**
 * Creates a popup with calendar
 *
 * @params e:		Event
 * @params options = {
 value:			Date|null
 left:			int|nul
 top:			int|nul
 and yozh_calendar.options except on_select
 }
**/
function yozh_calendar_popup(e, options={}) {
	let width = 174,
		height = 166,
		left = options.left || false,
		top = options.top || false

	if (e instanceof Event && e.target) {
		if (e.target.yozh_calendar_popup_hide instanceof Function) {
			e.target.yozh_calendar_popup_hide()
			return
		}
		if ('value' in e.target) {
			if (!options.hasOwnProperty('value'))
				options.value = e.target.value

			if (!(options.on_select instanceof Function))
				options.on_select = (d)=>{e.target.value=date_to_format(d)}
		}

		let box = e.target.getBoundingClientRect()
		if (left===false) {
			left = box.left
			if (left + width + 4 > document.body.clientWidth)
				left = document.body.clientWidth - width - 4
		}
		if (top===false) {
			top = box.top + e.target.offsetHeight + 2
			if (top + height + 4 > document.body.clientHeight)
				top = document.body.clientHeight - height - 4
		}
	}

	if (typeof options.value==='string' || options.value instanceof String)
		options.value = format_to_date(options.value)

	if (left===false)
		left = (document.body.clientWidth - width)/2
	if (top===false)
		top = (document.body.clientHeight - top)/2

	let	yozh_calendar_popup_hide = ()=>{
			popup.el.remove()
			document.body.removeEventListener('click', document_click)
			delete e.target.yozh_calendar_popup_hide
		},
		document_click = (e)=>{
			if (e.event_popup===popup.el)
				return
			yozh_calendar_popup_hide()
		},
		calendar = yozh_calendar(Object.assign({}, options, {
			on_select: (date)=>{
				yozh_calendar_popup_hide()
				if (options.on_select instanceof Function)
					options.on_select(date)
			}
		})),
		popup = {
			className: ['shadow'],
			styles: {zIndex: 30, position: 'absolute', left: left+'px', top: top+'px'},
			children: calendar.build(),
			events: {click: (e)=>{e.event_popup=popup.el}}
		}

	el_add_children(document.body, popup)

	if (e instanceof Event) {
		e.event_popup = popup.el
		e.target.yozh_calendar_popup_hide = yozh_calendar_popup_hide
	}

	document.body.addEventListener('click', document_click)
}
/**
 * Creates a calendar structure
 *
 * @params options = {
 value:			Date|null
 select_type:	string day|month|year|first_day|last_day (default day)
 first_day:		Date|null (if select_type=last_day)
 last_day:		Date|null (if select_type=first_day)
 on_select:		Function(Date)|null
 }
 * return {
 build:			function() return structure of dom Element
 update:		function()
 }
**/
function yozh_calendar(options) {
	let o = {
		locale:		locale,
		locales:	{
			en:		{
				days:	['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
				months:	['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
				months3:['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
			},
			ru:		{
				days:	['пн', 'вт', 'ср', 'чт', 'пт', 'сб', 'вс'],
				months:	['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'],
				months3: ['Янв', 'Фев', 'Мар', 'Апр', 'Май', 'Июн', 'Июл', 'Авг', 'Сен', 'Окт', 'Ноя', 'Дек']
			},
		},
		value: null, // Date
		select_type: 'day', // day|first_day|last_day|month|year
		current_type: 'day', // day|month|year
		first_day: null,
		last_day: null,
		on_select: null,
		current_value: null, // Date - дата текущей страницы просмотра

		build_frame: function () {
			if (o.current_type==='day') {
				let start_day = new Date(o.current_value.getFullYear(), o.current_value.getMonth(), 1),
					list = [],
					dow = start_day.getDay(),
					value_n		= o.value.getTime(),
					first_day_n	= o.first_day ? o.first_day.getTime() : false,
					last_day_n	= o.last_day ? o.last_day.getTime() : false


				if (dow!==1)
					start_day = new Date(start_day.getFullYear(), start_day.getMonth(), 1-(dow+6)%7)

				for (let i=0; i<42; i++) {
					let day = new Date(start_day.getFullYear(), start_day.getMonth(), start_day.getDate()+i),
						day_n = day.getTime(),
						current = day_n===value_n,
						interval = first_day_n && last_day_n && first_day_n<=day_n && day_n<=last_day_n

					list.push({
						className: [
							'day',
							day.getMonth()!==o.current_value.getMonth() ? 'white' : null,
							current && !interval ? 'current' : null,
							current || interval ? 'selected' : null,
							interval && day_n===first_day_n ? 'first' : null,
							interval && day_n===last_day_n ? 'last' : null,
						],
						text: day.getDate(),
						events: {click: o.on_select instanceof Function ? ()=>{o.on_select(day)} : null},
					})
				}

				return [
					{
						className: 'table-row slim flex-block between2',
						children: [
							{
								className: 'btn slim icon angle-left w32',
								events: {clickenter: ()=>{
										o.current_value = new Date(o.current_value.getFullYear(), o.current_value.getMonth()-1, 1)
										o.update()
									}},
							},
							{
								className: 'btn slim flex-grow',
								text: o.locales[o.locale].months[o.current_value.getMonth()]+' '+o.current_value.getFullYear(),
								events: {clickenter: ()=>{
										o.current_type = 'month'
										o.update()
									}},
							},
							{
								className: 'btn slim icon angle-right',
								events: {clickenter: ()=>{
										o.current_value = new Date(o.current_value.getFullYear(), o.current_value.getMonth()+1, 1)
										o.update()
									}},
							},
						]
					},
					{
						className: ['yozh_calendar_week_day_list', 'flex-block'],
						children: o.locales[o.locale].days.map((d)=>{return {className: 'day', text: d}}),
					},
					{
						className: ['yozh_calendar_day_list', 'flex-block', 'wrap'],
						children: list
					},
				]
			}
			if (o.current_type==='month') {
				let start_day = new Date(o.current_value.getFullYear(), 0, 1),
					list = [],
					value = new Date(o.value.getFullYear(), o.value.getMonth(), 1),
					value_n = value.getTime(),
					first_day = o.first_day ? new Date(o.first_day.getFullYear(), o.first_day.getMonth(), 1) : false,
					first_day_n = first_day ? first_day.getTime() : false,
					last_day = o.last_day ? new Date(o.last_day.getFullYear(), o.last_day.getMonth(), 1) : false,
					last_day_n = last_day ? last_day.getTime() : false

				for (let i=0; i<12; i++) {
					let day = new Date(start_day.getFullYear(), i, 1),
						day_n = day.getTime(),
						current = day_n===value_n,
						interval = first_day_n && last_day_n && first_day_n<=day_n && day_n<=last_day_n

					list.push({
						className: [
							'month',
							current && !interval ? 'current' : null,
							current || interval ? 'selected' : null,
							interval && day_n===first_day_n ? 'first' : null,
							interval && day_n===last_day_n ? 'last' : null,
						],
						text: o.locales[o.locale].months3[i],
						events: {click: ()=>{
							if (o.select_type==='month') {
								if (o.on_select instanceof Function)
									o.on_select(day)
								return
							}
							o.current_type = 'day'
							o.current_value = day
							o.update()
						}},
					})
				}

				return [
					{
						className: 'table-row slim flex-block between2',
						children: [
							{
								className: 'btn slim icon angle-left',
								events: {clickenter: ()=>{
										o.current_value = new Date(o.current_value.getFullYear()-1, 0, 1)
										o.update()
									}},
							},
							{
								className: 'btn slim flex-grow',
								text: o.current_value.getFullYear(),
								events: {clickenter: ()=>{
										o.current_type = 'year'
										o.update()
									}},
							},
							{
								className: 'btn slim icon angle-right',
								events: {clickenter: ()=>{
										o.current_value = new Date(o.current_value.getFullYear()+1, 0, 1)
										o.update()
									}},
							},
						]
					},
					{
						className: ['yozh_calendar_month_list', 'flex-block', 'wrap'],
						children: list
					},
				]
			}
			if (o.current_type==='year') {
				let page = 20,
					year = o.current_value.getFullYear(),
					start_year = year-year%page+1,
					list = [],
					value = new Date(o.value.getFullYear(), 0, 1),
					value_n = value.getTime(),
					first_day = o.first_day ? new Date(o.first_day.getFullYear(), 0, 1) : false,
					first_day_n = first_day ? first_day.getTime() : false,
					last_day = o.last_day ? new Date(o.last_day.getFullYear(), 0, 1) : false,
					last_day_n = last_day ? last_day.getTime() : false

				for (let i=0; i<page; i++) {
					let day = new Date(start_year+i, 0, 1),
						day_n = day.getTime(),
						current = day_n===value_n,
						interval = first_day_n && last_day_n && first_day_n<=day_n && day_n<=last_day_n

					list.push({
						className: [
							'year',
							current && !interval ? 'current' : null,
							current || interval ? 'selected' : null,
							interval && day_n===first_day_n ? 'first' : null,
							interval && day_n===last_day_n ? 'last' : null,
						],
						text: start_year+i,
						events: {click: ()=>{
								if (o.select_type==='year') {
									if (o.on_select instanceof Function)
										o.on_select(day)
									return
								}
								o.current_type = 'month'
								o.current_value = day
								o.update()
							}},
					})
				}

				return [
					{
						className: 'table-row slim flex-block between2',
						children: [
							{
								className: 'btn slim icon angle-left',
								events: {clickenter: ()=>{
										o.current_value = new Date(start_year-page, 0, 1)
										o.update()
									}},
							},
							{
								className: 'flex-grow a-center',
								text: start_year + ' - ' + (start_year + page -1),
							},
							{
								className: 'btn slim icon angle-right',
								events: {clickenter: ()=>{
										o.current_value = new Date(start_year+page, 0, 1)
										o.update()
									}},
							},
						]
					},
					{
						className: ['yozh_calendar_year_list', 'flex-block', 'wrap'],
						children: list
					},
				]
			}
		},
		update: function () {
			while (o.farme.el.firstChild)
				o.farme.el.firstChild.remove()

			el_add_children (o.farme.el, o.build_frame())
		},
		build: function () {
			o.farme = {
				className: ['yozh_calendar'],
				children: o.build_frame()
			}
			return o.farme
		},
		set_value: function (d) {
			o.value = d
			o.current_value = d
			if (o.select_type==='first_day')
				o.first_day = o.value
			if (o.select_type==='last_day')
				o.last_day = o.value
		}
	}

	for (let i in options)
		if (o.hasOwnProperty(i))
			o[i] = options[i]

	if (o.value && typeof o.value==='object' && typeof o.value.getMonth==="function") {
		o.value = new Date(o.value.getFullYear(), o.value.getMonth(), o.value.getDate())
		o.current_value = o.value
	} else {
		o.value = new Date()
		o.current_value = new Date(o.value.getFullYear(), o.value.getMonth(), o.value.getDate())
	}

	if (o.select_type==='first_day')
		o.first_day = o.value
	if (o.select_type==='last_day')
		o.last_day = o.value

	o.current_type = o.select_type==='first_day' || o.select_type==='last_day' ? 'day' : o.select_type
	return o
}
//----------------------------------------------------------------------------------------------------------------------

async function get_reCAPTCHAv3(recaptcha_key=false, action=''){
	if (!recaptcha_key)
		return false
	await new Promise((resolve, reject) => {grecaptcha.ready(resolve)}) // grecaptcha.ready needs a callback so we create a promise to await
	return await grecaptcha.execute(recaptcha_key, {action: action});// grecaptcha.execute returns a promise so we can await it
}

function image_viewer(options={}) {
	let o = {
		img_list: [],
		current: -1,
		show_image: (n=0)=>{
			if (o.img_list.length===0)
				return

			o.current = n
			if (o.current<0)
				o.current = n = 0
			if (o.current>=o.img_list.length)
				o.current = n = o.img_list.length-1

			let img = o.img_list[n]

			if (!img.size) {
				let i = new Image()
				i.onload = function(){
					img.size = {w: i.width, h: i.height};
					o.show_image(n)
				}.bind(null, n)
				i.src = img.url || img.src
				return
			}

			o.imgbox.el.style.backgroundImage = 'url('+(img.url || img.src)+')'
			o.imgbox.el.style.backgroundSize = o.imgbox.el.offsetWidth<img.size.w || o.imgbox.el.offsetHeight<img.size.h ? 'contain' : 'auto'

			while (o.title.el.firstChild)
				o.title.el.firstChild.remove()
			el_add_children(o.title.el, img.title)

			o.stat.el.innerHTML = (n+1) + ' / ' + o.img_list.length
			o.size.el.innerHTML = img.size.w + ' x ' + img.size.h

			while (o.user_panel.el.firstChild)
				o.user_panel.el.firstChild.remove()
			if (img.actions)
				el_add_children(o.user_panel.el, img.actions)
		},
		keydown:  (e) => {
			switch (e.keyCode) {
				case 36: // home
					o.show_image(0)
					break
				case 37: // left
				case 38: // top
				case 33: // pgUp
					o.show_image(o.current-1)
					break
				case 39: // right
				case 40: // down
				case 34: // pgDown
				case 32: // space
					o.show_image(o.current+1)
					break
				case 35: // end
					o.show_image(o.img_list.length-1)
					break
				case 27: // esc
					o.popup.close()
					break
			}
		},
		popup: yozh_popup({
			fn_after_close: ()=>{document.removeEventListener('keydown', o.keydown)},
			fullscreen: true,
		}),
		show_on_create: true,
	}

	for (i in options)
		if (o.hasOwnProperty(i))
			o[i] = options[i]
	o.popup.content.el.classList.add('flex-block', 'column', 'between5')

	o.popup.set([
		{
			className: 'flex-grow bg-video br5 relative image_viewer',
			children: [
				o.imgbox = {
					className: 'w100p h100p',
					styles: {
						backgroundPosition: '50% 50%',
						backgroundRepeat: 'no-repeat',
					}
				},
/*				{
					className: 'image_viewer_leaf prev',
					events: {click: ()=>{o.show_image(o.current-1)}},
				},
				{
					className: 'image_viewer_leaf next',
					events: {click: ()=>{o.show_image(o.current+1)}},
				}
*/			],
		},
		{
			className: 'table-row popup-bg br5 flex-block between',
			children: [
				{
					className: 'flex-block between5',
					children: [
						o.stat = {className: 'w100'},
						o.size = {className: 'w100'},
						o.title = {},
					]
				},
				o.panel = {
					className: 'flex-block between2',
					children: [
						{
							className: ['btn', 'icon', 'prev'],
							events: {clickenter: ()=>{o.show_image(o.current-1)}}
						},
						{
							className: ['btn', 'icon', 'next'],
							events: {clickenter: ()=>{o.show_image(o.current+1)}}
						},
						o.user_panel = {className: 'flex-block between2'},
					]
				}
			]
		}
	])
	o.popup.show()

	if (o.show_on_create)
		o.show_image(o.current)

	document.addEventListener('keydown', o.keydown)

	return o
}
function to_bool (v) {
	if (Number.isInteger(v))
		return v === 0 ? false : true

	if (typeof v === 'boolean')
		return v

	if (typeof v === 'string') {
		let bool_value = {
			't':	true,	'f':	false,
			'true':	true,	'false':false,
			'1':	true,	'0':	false,
			'yes':	true,	'no':	false,
			'all':	false,
			'undefined':false,
			'null':	false,
		}
		return (bool_value.hasOwnProperty(v) ? bool_value[v] : v.length>0)
	}

	return false
}
