<?php
function p ($v, $return=false) {
//	$args = func_get_args();
//	foreach ($args as $v) {

	if(is_null($v)) {
		$s = "NULL";
	} elseif(is_bool($v)) {
		$s = $v ? "TRUE" : "FALSE";
	} else {
		$s = print_r($v, 1);
	}

	if ($return)
		return $s;

	echo empty($GLOBALS['is_console']) ? "<pre class='p'>\n{$s}</pre>\n" : $s."\n";
}

spl_autoload_register(function($class_name) {
//	$class_name = strtolower($class_name);

	$base_path = getcwd();
	if (strpos($class_name, '\\')!==false) { // if namespace
		$class_path = explode('\\', $class_name);

		$module = array_shift($class_path);
		$class_name = array_pop($class_path);
		$class_path = count($class_path)>0 ? implode('/', $class_path).'/' : '';
	} else { // core model
		$module = 'core';
		$class_path = '';
	}

	if ($module==='Dadata') {
		$file_name = "{$base_path}/external_soft/{$module}/{$class_path}{$class_name}.php";
	} elseif (strpos($class_name, '_controller')>0) {
		$file_name = "{$base_path}/modules/{$module}/controller/{$class_path}{$class_name}.php";
	} else {
		$file_name = "{$base_path}/modules/{$module}/model/{$class_path}{$class_name}.php";
	}

	if (is_file($file_name))
		require_once $file_name;
});

function exception_event($e) {
	$e_msg = $e->getMessage();

	if (!$GLOBALS['conf']['site']['debug_mode'])
		http_response_code(500);

	if (!empty($GLOBALS['exception_return'])) {
		$msg = $e_msg==='custom exception' ? ($GLOBALS['exception_err']['msg'] ?: $GLOBALS['exception_err']['err']) : $e_msg;
		if (empty($GLOBALS['REQUEST_JSON'])) {
			echo $msg;
		} else {
			\output::ajax([
				'success'	=> false,
				'msg'		=> $msg,
			]);
		}
		return;
	}

	if ($e_msg=='custom exception' && $GLOBALS['exception_err']['err']=='no access' && $GLOBALS['user']['role']=='guest') {
		if (!empty($GLOBALS['REQUEST_JSON'])) {
			output::ajax([
				'success'	=> false,
				'msg'		=> lang('no_access'),
			]);
		} else {
			controller_manager::prepare_default_module('guest');
			controller_manager::module_execute_request();
			session_write_close();
		}
	} else {

		$trace = $e->getTrace();
		foreach ($trace as $k=>$r)
			if (isset($trace[$k]['args']) && strlen(print_r($trace[$k]['args'], true))>1024*8)
				$trace[$k]['args'] = 'long data';

		$body = "<pre>\nException with message: {$e_msg}\n".
			(isset($GLOBALS['exception_err']) ? 'custom data: '.p($GLOBALS['exception_err'], true) : '').
			"file: ".$e->getFile()."\n".
			"line: ".$e->getLine()."\n".
			"Trace: ".print_r($trace, 1)."\n".
			"user: ".(isset($GLOBALS['user']) ? print_r($GLOBALS['user'], 1):'-')."\n".
			"\$_REQUEST: ".print_r($_REQUEST, 1)."\n".
			"\$_SERVER: ".print_r($_SERVER, 1)."\n";
		if (!empty($GLOBALS['conf']['site']['debug_mode'])) {
			echo $body;
		} else {
			$res = $GLOBALS['lib']->mail->send([
				'to_mail'	=> $GLOBALS['conf']['site']['error_email_to'],
				'subject'	=> 'exception from '.$GLOBALS['conf']['site']['site_url'],
				'body'		=> $body,
			]);
			echo "some error happened :(<br />\n".
				"the error email was".($res?'':"n't")." sent.<br />\n";
		}

		session_write_close();
	}
}

function no_access($data=null) {
	$GLOBALS['exception_err'] = [
		'err'	=> 'no access',
		'msg'	=> $data ?? '',
	];
	throw new \Exception('custom exception');
}

set_error_handler(function($errno, $errstr, $errfile, $errline) {
	if (!(error_reporting() & $errno))
		return false;
	$GLOBALS['exception_err'] = [
		'err'	=> 'warning',
		'msg'	=> ['errno'=>$errno, 'errstr'=>$errstr, 'errfile'=>$errfile, 'errline'=>$errline],
	];
	$e = new \Exception('custom exception');
	exception_event($e);
	exit();
	return true;
}, E_ALL & ~E_ERROR);

function firstLetterCaps($str) {
	if (mb_strlen($str)>0) {
		$first = mb_substr($str, 0, 1);
		$first_Up = mb_strtoupper($first);
		if (mb_strlen($str)>1) {
//			$second = mb_substr($str, 1, 1);
//			$second_Up = mb_strtoupper($second);
//			if ($first===$first_Up && $second===$second_Up) {// abbreviation
//				return $str;
//			} else {
//				return $first_Up.mb_strtolower(mb_substr($str, 1));
				return $first_Up.mb_substr($str, 1);
//			}
		}
		return $first_Up;
	}
	return '';
}

function lang($code, $firstLetterCaps = true) {
	if (is_array($code))
		return implode(' ', array_map('lang', $code, array_map(function($n){return $n==0;}, array_keys($code))));

	$str = isset($GLOBALS['lang'][$code]) ? $GLOBALS['lang'][$code] : $code;
	return $firstLetterCaps && !is_array($str) ? firstLetterCaps($str) : $str;
}

function bytes_format($bytes) {
	if ($bytes >= 1073741824) {
		$bytes = number_format($bytes / 1073741824, 2) . ' Gb';
	} elseif ($bytes >= 1048576) {
		$bytes = number_format($bytes / 1048576, 2) . ' Mb';
	} elseif ($bytes >= 1024) {
		$bytes = number_format($bytes / 1024, 2) . ' Kb';
	} else {
		$bytes = $bytes . ' b';
	}
	return $bytes;
}
function bytes_to_int ($str) {
	$str = str_replace([' ', "/n", "/r", "/t"], '', $str);
	$str = str_replace([',', "."], '', $str);
	$str = mb_strtolower($str);

	if (in_array(mb_substr($str, -2), ['gb', 'гб'])) {
		$bytes = intval(mb_substr($str, 0, -2) * 1073741824);
	} elseif (in_array(mb_substr($str, -2), ['mb', 'мб'])) {
		$bytes = intval(mb_substr($str, 0, -2) * 1048576);
	} elseif (in_array(mb_substr($str, -2), ['kb', 'кб'])) {
		$bytes = intval(mb_substr($str, 0, -2) * 1024);
	} elseif (in_array(mb_substr($str, -1), ['b', 'б'])) {
		$bytes = intval(mb_substr($str, 0, -1));
	} else {
		$bytes = intval($str);
	}
	return $bytes;
}

function str_to_lang_value($v) {
	return ['ru'=>$v, 'en'=>$v];
}
function str_umlaut_clear($str) {
	return strtr(
		utf8_decode($str),
		utf8_decode('ŠŒŽšœžŸ¥µÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝßàáâãäåæçèéêëìíîïðñòóôõöøùúûüýÿŽŠČŘĎŤŇŮžščřďťňů'),
					'SOZsozYYuAAAAAAACEEEEIIIIDNOOOOOOUUUUYsaaaaaaaceeeeiiiionoooooouuuuyyZSCRDTNUzscrdtnu'
	);
}

function to_bool($data) {
	if (is_bool($data))
		return $data;

	if (is_int($data))
		return $data!==0;

	if (is_null($data))
		return false;

	if (is_string($data)) {
		$data = mb_strtolower($data);
		$bool = [
			't'		=> true, 'f'	=> false,
			'true'	=> true, 'false'=> false,
			'1'		=> true, '0'	=> false,
			'yes'	=> true, 'no'	=> false,
			'да'	=> true, 'нет'	=> false,
			'all'	=> false,
			'undefined'=> false,
			'null'	=> false,
		];
		return isset($bool[$data]) ? $bool[$data] : strlen($data)>0;
	}

	$GLOBALS['exception_err'] = [
		'err'	=> 'table_db error',
		'msg'	=> "can\'t convert to bool",
	];
	throw new \Exception('custom exception');
}

//-- for table_db::post_process field(ref) to field_str ----------------------------------------------------------------
function get_ref_list($list, $field_name, $model) { // получить список $model по id, которые $field_name из $list
	$id_list = array_unique(array_diff(array_map('intval', array_column($list, $field_name)), [0]));
	return empty($id_list) ? [] : $model::get_list(['filters'=>['id'=>$id_list, 'constructor'=>true], 'key'=>'id']);
}
function get_ref_name($r, $ref_list, $field_name, $model) {
	return isset($ref_list[$r[$field_name]]) ? $model::record_get_name($ref_list[$r[$field_name]]) : $r[$field_name];
}
function set_ref_list_str(&$list, $field_name, $model) {
	if (is_array($field_name)) {
		foreach ($field_name as $k=>$f)
			set_ref_list_str($list, $f, $model[$k]);
		return;
	}
	$ref_list = get_ref_list($list, $field_name, $model);
	foreach ($list as $k=>$r)
		$list[$k][$field_name.'_str'] = get_ref_name($r, $ref_list, $field_name, $model);
}
//-- date sql function -------------------------------------------------------------------------------------------------
function date_sql_subtraction($date1_sql, $date2_sql, $return='days') { // returns days date1-date2; 2023-04-15-2023-04-11=4
	$date1_a		= array_map('intval', explode('-', $date1_sql));
	$date1_int		= gmmktime(0, 0, 0, $date1_a[1], $date1_a[2], $date1_a[0]);

	$date2_a		= array_map('intval', explode('-', $date2_sql));
	$date2_int		= gmmktime(0, 0, 0, $date2_a[1], $date2_a[2], $date2_a[0]);

	$days		= intval(round(($date1_int - $date2_int)/(3600*24)))+1;

	return $return==='days' ? $days : [$days, $date1_a, $date1_int, $date2_a, $date2_int];
}
function date_sql_add_days($date_sql, $days, $return='sql') {// return sql; 15-2023-04-11+4=2023-04-15; 2023-04-15-4=15-2023-04-11
	$date_a		= array_map('intval', explode('-', $date_sql));

	$new_date_int = gmmktime(0, 0, 0, $date_a[1], $date_a[2] + $days, $date_a[0]);
	$new_date_sql = gmdate("Y-m-d", $new_date_int);
	return $return==='sql' ? $new_date_sql : ['sql'=>$new_date_sql, 'int'=>$new_date_int];
}


//-- обрезает строку или увеличивает фоновым символом (по умолчанию - пробелами) до указанной длинны
function str_cell($str, $length, $align='left', $bg=' ') {
	$c = $bg[0];
	$strlen = mb_strlen($str);

	if ($strlen>$length)
		return mb_substr($str, 0, $length+1);

	$space_length = $length-$strlen;

	if ($align==='left')
		return $c.$str.str_repeat($c, $space_length);

	if ($align==='center')
		return $c.str_repeat($c, floor($space_length/2).$str.ceil($space_length/2));

	if ($align==='right')
		return  str_repeat($c, $space_length).$str.$c;

	throw new Exception('unknown align');
}
function str_color($str, $text_color='default', $bg_color='black') {
	$colors = [// https://joshtronic.com/2013/09/02/how-to-use-colors-in-command-line-output/
		'default'	=> "0;39",
		'black'		=> "0;30",
		'dark_gray'	=> "0;30",
		'red'		=> "0;31",
		'green'		=> "0;32",
		'yellow'	=> "0;33",
		'blue'		=> "0;34",
		'magenta'	=> "0;35",
		'cyan'		=> "0;36",
		'gray_l'	=> "0;37",
		'gray_d'	=> "0;90",
		'red_l'		=> "0;91",
		'green_l'	=> "0;92",
		'yellow_l'	=> "0;93",
		'blue_l'	=> "0;94",
		'magenta_l'	=> "0;95",
		'cyan_k'	=> "0;96",
//		'white'		=> "0;97",
		'white'		=> "1;37",
	];
	$bg_list	= [
		'black'		=> '40',
		'red'		=> '41',
		'green'		=> '42',
		'yellow'	=> '43',
		'blue'		=> '44',
		'magenta'	=> '45',
		'cyan'		=> '46',
		'grey_l'	=> '47',
	];

	echo "\e[".$colors[$text_color].';'.$bg_list[$bg_color]."m".$str."\e[0m";
}
