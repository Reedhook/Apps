<?php
require_once 'modules/core/output.php';

abstract class controller {
	static $default_method = 'start';
	protected static $access_name = ['root', 'cron', 'admin', 'user', 'guest'];
	static $model		= null;

	function __construct() {
		$class_info = new ReflectionClass($this);

		if (!in_array($GLOBALS['user']['role'], static::$access_name))
			no_access("Class ".$class_info->getName()." for user_id: ".p($GLOBALS['user']['id'], true)." ({$GLOBALS['user']['role']})");

		// add controller lang
		$lang_file = dirname($class_info->getFileName()).'/../lang.php';
		if (is_file($lang_file))
			require_once $lang_file;
	}

	protected static function parse_model() {
		$parts = explode('\\', substr(static::$model, 1));
		$class = end($parts);
		if (strpos($class, '_db')!==false)
			$class = substr(end($parts), 0, -3);
		return [$parts[0], $class];
	}
	public function start() {
		list($module_name, $model_name) = static::parse_model();

		$this->strat_add_files($module_name, $model_name);
		$GLOBALS['lib']->smarty->assign('title', lang($model_name.'_list'));
		$GLOBALS['lib']->smarty->assign('js_class', $model_name.'_class');
		\output::smarty('modules/core/view/manager.tpl');
	}
	protected function strat_add_files($module_name, $model_name) {
		\output::add_files(["{$module_name}/js/{$model_name}.js"]);
	}

	function list_ajax() {
		$pagination_data = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];
		list($pagination, $records) = (static::$model)::get_page($pagination_data);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'		=> $records,
				'pagination'	=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'			=> (static::$model)::get_columns(),
				'lang'				=> \output::lang_prepare(['model_name'=>static::$model, 'list'=>$this->list_lang()]),
				'filters_model'		=> (static::$model)::get_filters(),
				'filters_ref_name'	=> (static::$model)::get_filters_ref_name($pagination['filters']),
				'enum'				=> (static::$model)::get_enum(),
				'custom_data'		=> $this->custom_data($pagination),
			]),
		]);
	}
	function list_lang() {
		return [];
	}
	function custom_data($pagination) {
		return [];
	}

	function edit_ajax() {
		$localisation_fl = in_array('_localisation_db', class_parents(static::$model));
		list($module_name, $model_name) = static::parse_model();

		$item_id = empty($_REQUEST['item_id']) ? null : $_REQUEST['item_id'];
		$obj = new static::$model($item_id);
		if (!$obj->access('edit'))
			no_access();

		$field_list = $this->edit_field_list();
		$data = empty($_REQUEST['data']) ? [] : array_intersect_key($_REQUEST['data'], $field_list);

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : false;
		if ($action==='save') {
			$err = $obj->validate($data);

			if(empty($err))
				$obj->save($data);

			\output::ajax([
				'success'	=> count($err)===0,
				'err'		=> $err,
			]);
			return;
		} else {
			$this->edit_set_default_data($obj, $data);
		}

		\output::ajax([
			'edit_data'	=> array_merge([
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> $model_name,
				'lang'				=> \output::lang_prepare(['model_name'=>static::$model]),
				'enum'				=> (static::$model)::get_enum(),
				'json_map'			=> (static::$model)::get_json_map(),
			],
			$localisation_fl ? [
				'field_localisation'=> (static::$model)::get_localisation_fields(),
				'lang_list'			=> $GLOBALS['lib']->lang->list,
				'lang_cur'			=> $GLOBALS['lib']->lang->value,
				'data_localisation'	=> $obj->get_localisation(),
			] : []),
		]);
	}
	function edit_field_list() {
		return (static::$model)::get_field_list();
	}
	function edit_set_default_data($obj, $data) {
		if (!$obj->id) {
			$obj->set_data($data);
		}
	}

	protected static $edit_field_list = [];
	function edit_field_ajax() {
		$success = false;
//		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'manager']))
//			no_access();

		$item_id	= intval(isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : 0);
		$field_name	= isset($_REQUEST['field_name']) ? $_REQUEST['field_name'] : false;
		$value		= isset($_REQUEST['value']) ? $_REQUEST['value'] : false;

		if ($item_id>0 && in_array($field_name, static::$edit_field_list)) {
			$obj = new static::$model($item_id);
			if (!$obj->access('edit'))
				no_access();
			$obj->save([$field_name => $value]);
			$success = true;
		}

		\output::ajax([
			'success'	=> $success,
		]);
	}
	function edit_by_filter_ajax() {
		$filters	= $_REQUEST['filters'] ?? ['id'=>-1];
		$field_name	= $_REQUEST['field_name'] ?? false;
		$value		= $_REQUEST['value'] ?? false;

		$report = ['total'=>0, 'no_access'=>0, 'already'=>0, 'saved'=>0];
		if (in_array($field_name, static::$edit_field_list))
			(static::$model)::get_list(['filters'=>$filters, 'no_answer'=>true, 'row_function'=>function($r) use(&$report, $field_name, $value) {
				$obj = new static::$model();
				$obj->construct_by_data($r);
				$report['total'] ++;

				if (!$obj->access('edit')) {
					$report['no_access'] ++;
					return;
				}

				if ($obj->save([$field_name => $value])) {
					$report['saved'] ++;
				} else {
					$report['already'] ++;
				}

			}]);

		\output::ajax([
			'report'	=> $report,
		]);
	}

	function delete_ajax() {
		$item_id_list = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : [];

		if (!is_array($item_id_list))
			$item_id_list = [$item_id_list];

		foreach ($item_id_list as $item_id) {
			$obj = new static::$model($item_id);
			if (!$obj->access('edit'))
				throw new \Exception('no access');
			$obj->delete();
		}

		\output::ajax([
			'success'	=> true,
		]);
	}

	static function redirect($url='') {
		header('Location:'.(strpos($url, '://')===false ? $GLOBALS['conf']['site']['site_url'] : '').$url);
	}

	static function access($options) {
		return true;
	}

	protected function check_recaptcha(&$err, $recaptcha_token=null) {
		if (\site\setting_db::get_setting('recaptcha_use')) {
			if (!$recaptcha_token)
				$recaptcha_token = isset($_REQUEST['recaptcha_token']) ? $_REQUEST['recaptcha_token'] : null;

			if (!$recaptcha_token) {
				$err['recaptcha'] = 'empty_recaptcha_token';
				return false;
			}

			$response = $GLOBALS['lib']->curl->request(
				"https://www.google.com/recaptcha/api/siteverify",
				'post',
				[
					'secret'	=> \site\setting_db::get_setting('recaptcha_secret'),
					'response'	=> $recaptcha_token,
				],
				[]
			);
			$response = json_decode($response, true);

			if($response['success'])
				return true;

			$err['recaptcha'] = $response['error-codes'][0];
			return false;
		}

		return true;
	}

	function xls() {
		if (!in_array($GLOBALS['user']['role'], ['root', 'cron', 'admin']))
			no_access();
		$filters = isset($_REQUEST['filters']) ? $_REQUEST['filters'] : [];

		require_once 'external_soft/PHPExcel-1.8/Classes/PHPExcel.php';
		require_once 'external_soft/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php';
		$xls = new \PHPExcel();
		$xls->setActiveSheetIndex(0);
		$sheet = $xls->getActiveSheet();

		$n = 1;
		$c = 0;
		foreach ($this->xls_get_columns() as $f=>$o)
			$sheet->setCellValueExplicit(chr(ord('A')+($c++)).$n, lang($r['title'] ?? $f), \PHPExcel_Cell_DataType::TYPE_STRING);
		$n++;

		(static::$model)::get_list(['filters'=>array_merge($filters, ['xls'=>true]), 'no_answer'=>true, 'row_function'=>function($r) use (&$sheet, &$n) {
			$c = 0;
			foreach ($this->xls_get_columns() as $f=>$o)
				if (isset($r[$f]))
					$sheet->setCellValueExplicit(chr(ord('A')+($c++)).$n, $r[$f], \PHPExcel_Cell_DataType::TYPE_STRING);
			$n++;
		}]);

		header('Content-type: application/vnd.ms-excel');
		header("Content-Disposition: attachment; filename=\"certificate_report.xlsx\"");

		$objWriter = new \PHPExcel_Writer_Excel2007($xls);
		$objWriter->save('php://output');
	}
	protected function xls_get_columns() {
		return (static::$model)::get_columns();
	}
}