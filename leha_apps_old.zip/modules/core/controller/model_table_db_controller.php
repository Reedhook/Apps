<?php
class model_table_db_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'/*, 'user'*/];

	function __construct() {
		if (!empty($_REQUEST['model'])) {
			static::$model = $_REQUEST['model'];
		} elseif (!empty($_REQUEST['pagination']['filters']['model'])) {
			static::$model = $_REQUEST['pagination']['filters']['model'];
		} elseif (!empty($_REQUEST['request_line'])) {
			static::$model = '\\'.implode('\\', $_REQUEST['request_line']);
		} else {
			$GLOBALS['exception_err'] = [
				'err'	=> 'model error',
				'msg'	=> 'there is no model',
			];
			throw new \Exception('custom exception');
		}

		parent::__construct();

		$model_a = explode('\\', static::$model);
		$this->model_name = substr(end($model_a), 0, -3);

		$module = $model_a[1];
		$lang_file = "module/{$module}/lang.php";

		if (is_file($lang_file))
			require_once $lang_file;
	}

	function start() {
		\output::add_files(['core/js/model_table_db.js']);
		$edit_access = in_array($GLOBALS['user']['role'], ['root', 'admin']);

		$GLOBALS['lib']->smarty->assign('title', lang($this->model_name.(isset($GLOBALS['lang'][$this->model_name.'_list'])?'_list':'')));
		$GLOBALS['lib']->smarty->assign('js_class', 'model_table_db_class');

		$filters = static::$model::get_filters();
		$filters['model'] = ['type'=>'hidden', 'value'=>static::$model];
		$GLOBALS['lib']->smarty->assign('filters', $filters);
		$GLOBALS['lib']->smarty->assign('pagination', ['filters'=>['model'=>static::$model]]);

		$GLOBALS['lib']->smarty->assign('enum', static::$model::get_enum());

		$GLOBALS['lib']->smarty->assign('no_edit_access', !$edit_access);

		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];
		list($pagination, $records) = (static::$model)::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
				],
				empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> (static::$model)::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=>static::$model, 'list'=>['model'/*, 'model_title'=>$this->model_name*/]]),
				'filters_model'=> array_merge(static::$model::get_filters(), ['model'=>['type'=>'hidden', 'value'=>static::$model]]),
				'filters_ref_name' => static::$model::get_filters_ref_name($pagination['filters']),
				'enum'		=> static::$model::get_enum(),
			]),
		]);
	}

	function edit_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$localisation_fl = in_array('_localisation_db', class_parents(static::$model));

		if (static::$model::get_system_fields()['id']['type']==='int')
			$item_id = intval($item_id);

		$obj = new static::$model($item_id);
		if($localisation_fl)
			$obj->get_localisation();

		if(!$obj->access('edit'))
			no_access();

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if ($action=='save') {
			$data = $_REQUEST['data'];
			$err = $obj->validate($data);
			if (empty($err))
				$obj->save($data);
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;
		}

		\output::ajax([
			'edit_data'	=> array_merge(
				[
					'hidden_field_list'	=> ['model'=>static::$model],
					'item_name'			=> $this->model_name,
					'lang'				=> \output::lang_prepare(['model_name'=>static::$model, 'list'=>[]]),
					'field_list'		=> static::$model::get_field_list(),
					'enum'				=> static::$model::get_enum(),
					'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				],
				$localisation_fl ? [
					'field_localisation'=> static::$model::get_localisation_fields(),
					'lang_list'			=> $GLOBALS['lib']->lang->list,
					'lang_cur'			=> $GLOBALS['lib']->lang->value,
					'data_localisation'	=> $obj->get_localisation(),
				] : []
			)
		]);
	}

	function delete_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		if (static::$model::get_system_fields()['id']['type']==='int')
			$item_id = intval($item_id);

		$obj = new static::$model($item_id);

		if(!$obj->access('edit'))
			no_access();

		$obj->delete();

		\output::ajax([
			'success'	=> true,
		]);
	}
	function edit_field_ajax () {
		$field_name	= isset($_REQUEST['field_name']) ? $_REQUEST['field_name'] : false;
		$item_id	= isset($_REQUEST['item_id']) ? intval($_REQUEST['item_id']) : -1;
		$value		= isset($_REQUEST['value']) ? $_REQUEST['value'] : false;

		$obj = new static::$model($item_id);
		if (!$obj->access('edit'))
			no_access();

		$success = false;

//		$model_fields = [
//			'device_player'=>['position', 'available']
//		];
//		if (isset($model_fields[$this->model_name]) && in_array($field_name, $model_fields[$this->model_name])) {
			$obj->save([$field_name => $value]);
			$success = true;
//		}

		\output::ajax([
			'success'	=> $success,
		]);
	}
}
