<?php

class session_controller extends \controller{
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {
		\output::add_files(['core/js/session.js']);

		$GLOBALS['lib']->smarty->assign('title', lang('session_list'));
		$GLOBALS['lib']->smarty->assign('js_class', 'session_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];

		list($pagination, $records) = session_db::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> session_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=> '\\session_db', 'list'=>['clear_old']]),
				'filters_model'=> session_db::get_filters(),
//				'enum'		=> restore_db::get_enum(),
//				'filters_ref_name' => session_db::get_filters_ref_name($pagination['filters']),
			]),
		]);
	}

	function edit_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new session_db($item_id);
		if(!$obj->access('edit'))
			throw new Exception('no access');

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;
		if ($action=='save') {
			$data = array_intersect_key($_REQUEST['data'], session_db::get_field_list());
			$err = $obj->validate($data);
			if(empty($err))
				$obj->save($data);
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;
		}

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> session_db::get_field_list(),
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'session',
				'lang'				=> \output::lang_prepare(['model_name'=>'\\session_db', 'list'=>['session']]),
//				'enum'				=> session_db::get_enum(),
//				'form_view_only'	=> true,
			],
		]);
	}

	function delete_ajax() {
		$item_id_list = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		if (!is_array($item_id_list))
			$item_id_list = [$item_id_list];
		foreach ($item_id_list as $item_id) {
			$obj = new session_db($item_id);
			if(!$obj->access('edit'))
				no_access();
			$obj->delete();
		}

		\output::ajax([
			'success'	=> true,
		]);
	}

	function clear_ajax() {
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root']))
			no_access();

		$GLOBALS['lib']->session->garbage_collector($GLOBALS['conf']['session']['session_timeout']);
		\output::ajax(['success' => true]);
	}
}
