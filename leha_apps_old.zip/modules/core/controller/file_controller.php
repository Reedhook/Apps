<?php
//-- контроллер возвращает содержимое файлов изображений с возможностью изменения размера
class file_controller extends \controller {
//	protected static $access_name = ['root', 'cron', 'admin', 'manager', 'user', 'guest'];

	function start() {
		$GLOBALS['lib']->smarty->assign('title', lang('file_list'));
		$GLOBALS['lib']->smarty->assign('js_class', 'file_list_class');
		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function id() {
		$item_id = isset($_REQUEST['request_line'][0]) ? array_shift($_REQUEST['request_line']) : -1;
		$disposition = isset($_REQUEST['request_line'][0]) ? array_shift($_REQUEST['request_line']) : 'inline';
		$file_o = new \file_db($item_id);
		if (!$file_o->access('view'))
			no_access();

		$file_o->out(['disposition'=>$disposition]);
	}
	function hash() {
		$hash = isset($_REQUEST['request_line'][0]) ? array_shift($_REQUEST['request_line']) : -1;
		$disposition = isset($_REQUEST['request_line'][0]) ? array_shift($_REQUEST['request_line']) : 'inline';
		$file_list = file_db::get_list(['filters'=>['hash'=>$hash]]);
		if (count($file_list)===0) {
			echo "file doesn't exist in database";
			return;
		}
		$file_o = new file_db();
		$file_o->construct_by_data($file_list[0]);
		if (!$file_o->access('view'))
			no_access();

		$file_o->out(['disposition'=>$disposition]);
	}

	static function access($options) {
		if (empty($options['file_o']))
			return false;

		if ($options['file_o']->access==='private') {
			$GLOBALS['exception_err'] = [
				'err'	=> 'file error',
				'msg'	=> 'try to get private file. id: '.$options['file_o']->id,
			];
			throw new \Exception('custom exception');
		}
		return false;
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			$pagination['filters']['user_id'] = $GLOBALS['user']['id']>0 ? $GLOBALS['user']['id'] : -1;

		list($pagination, $records) = file_db::get_page($pagination);

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
			], empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> file_db::get_columns(),
				'lang'		=> \output::lang_prepare(['model_name'=>'file_db', 'list'=>['download', 'view', 'upload']]),
				'enum'		=> file_db::get_enum(),
				'filters_model'	=> file_db::get_filters(),
			])
		]);
	}

	function edit_ajax() {
		$item_id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : null;
		$obj = new file_db($item_id);
		if(!$obj->access('edit'))
			no_access();

		$field_list = file_db::get_field_list();
		$field_list['original_name']['type'] = 'str';
		$field_list['file_name']['type'] = 'str';
		$field_list['file_name']['view'] = true;

		$admin = in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'manager', 'user']);

		$editable_field_list = ['original_name'=>true, ($admin?'user_id':false)=>true];
		foreach ($field_list as $f=>$r)
			if (!isset($editable_field_list[$f]))
				$field_list[$f]['view_only'] = true;

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : null;

		if ($action=='save') {
			$data = array_intersect_key($_REQUEST['data'], $editable_field_list);
			$err = $obj->validate($data);
			if(empty($err))
				$obj->save($data);
			\output::ajax([
				'success'	=> empty($err),
				'err'		=> $err,
			]);
			return;

		}

		\output::ajax([
			'edit_data'	=> [
				'field_list'		=> $field_list,
				'data'				=> $obj->get_data(['get_ref_name'=>'true']),
				'item_name'			=> 'file',
				'lang'				=> \output::lang_prepare(['model_name'=>'\\file_db', 'list'=>['file', 'copy', 'value']]),
				'enum'				=> file_db::get_enum(),
			],
		]);
	}

	function upload_ajax() {
		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'user']))
			no_access();

		$result_stat = [
			'totals'	=> ['count'=>0, 'size'=>0],
			'successes'	=> ['count'=>0, 'size'=>0],
			'errors'	=> ['count'=>0, 'size'=>0],
		];
		$result = [];
		$data = isset($_REQUEST['data']) ? array_intersect_key($_REQUEST['data'], ['protected'=>true]) : [];
		foreach ($_FILES as $k=>$f) {
			$file_o = \file_db::upload($k, array_merge(['file_source'=>'post'], $data));
			$success = $file_o===false ? false : true;

			$result[] = array_merge($f, [
				'status'	=> $success,
				'err_msg'	=> \file_db::get_err_str(),
				'id'		=> $success ? $file_o->id : false,
				'url'		=> $success ? $file_o->url() : false,
			]);
			$result_stat['totals']['count']		++;
			$result_stat['totals']['size']		+= $f['size'];
			$result_stat['successes']['count']	+= $success ? 1 : 0;
			$result_stat['successes']['size']	+= $success ? $f['size'] : 0;
			$result_stat['errors']['count']		+= $success ? 0 : 1;
			$result_stat['errors']['size']		+= $success ? 0 : $f['size'];
		}

		output::ajax([
			'success'		=> true,
			'result_stat'	=> $result_stat,
			'result_list'	=> $result,
		]);
	}

	function delete_ajax() {
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : -1;
		$obj = new file_db($id);
		if(!$obj->access('edit'))
			no_access();

		$obj->delete();

		\output::ajax([
			'success'	=> true,
		]);

	}
}
