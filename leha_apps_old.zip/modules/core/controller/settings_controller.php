<?php

abstract class settings_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];
	static $model	= null;

	function start() {
//		\output::add_files([
//			'core/js/settings.js'
//		]);
//		$GLOBALS['lib']->smarty->assign('title', lang('settings'));
//		$GLOBALS['lib']->smarty->assign('js_class', 'settings_class');
//		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$setting_map = (static::$model)::$setting_map;
		$setting_list = (static::$model)::get_setting_list(); // for history
		$list = [];
		foreach ($setting_map as $k=>$map_item) {
			$value =  (static::$model)::get_setting($k);
			$list[] = array_merge($map_item, [
					'name'		=> $k,
					'value'		=> $value,
					'value_str'	=> (static::$model)::formatter($map_item, $value),
					'id'		=> array_key_exists($k, $setting_list) ? intval($setting_list[$k]['id']) : null, // for history
				]);
		}

		$lang = array_merge(
			array_keys($setting_map),
			$this->list_lang()
		);

		foreach (array_column($list, 'enum') as $enum)
			array_push($lang, ...array_values($enum));

		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $list,
			],
			empty($_REQUEST['build_data']) ? [] : [
				'lang'		=> \output::lang_prepare(['list'=>$lang]),
			]),
		]);
	}
	function list_lang() {
		return [
			'model_name' => static::$model, // for history
		];
	}

	function edit_ajax() {
		$name = isset($_REQUEST['name']) ? $_REQUEST['name'] : null;

		$action = isset($_REQUEST['action']) ? $_REQUEST['action'] : false;
		if($action==='save') {
			if (isset($_REQUEST['value']))
				(static::$model)::save_setting($name, $_REQUEST['value']);
			\output::ajax([
				'success'	=> true,
				'name'		=> $name,
				'value_str'	=> (static::$model)::formatter((static::$model)::$setting_map[$name], (static::$model)::get_setting($name)),
			]);
			return;
		}

		$type = (static::$model)::$setting_map[$name]['type'];
		$field_type = $type;
		$enum = [];
		$lang_list = [];

		switch ($type) {
			case 'lang':
			case 'date_format':
			case 'phone_format':
			case 'skin':
				$field_type = 'select_lang';
				break;
		}

		if ($type==='select') {
			$enum = (static::$model)::$setting_map[$name]['enum'];
			$lang_list = array_merge($lang_list, array_values($enum));
		}
		if ($type==='lang') {
			$list =$GLOBALS['lib']->lang->list;
			$enum = array_combine($list, $list);
			$lang_list = array_merge($lang_list, $list);
		}
		if ($type==='date_format') {
			$list = array_keys($GLOBALS['lib']->date_time->formats);
			$enum = array_combine($list, $list);
		}
		if ($type==='phone_format') {
			$enum = $GLOBALS['lib']->phone::$formats;
		}
		if ($type==='skin') {
			$enum = site\skin::get_list();
		}

		\output::ajax([
			'edit_data'	=> [
				'name'				=> $name,
				'value'				=> (static::$model)::prepare_value($type, (static::$model)::get_setting($name)),
				'field_type'		=> $field_type,
				'lang'				=> \output::lang_prepare(['list'=>array_merge([$name], $lang_list)]),
				'select_list'		=> $enum,

//				'field_localisation'=> track_db::get_localisation_fields(),
//				'data_localisation'	=> $obj->get_localisation(),
//				'lang_list'			=> $GLOBALS['lib']->lang->list,
//				'lang_cur'			=> $GLOBALS['lib']->lang->value,
			],
		]);

	}
}
