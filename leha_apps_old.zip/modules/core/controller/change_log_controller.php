<?php
class change_log_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {
		$filters = empty($_REQUEST['filters'])
			? (empty($_REQUEST['request_line'][0]) ? [] : json_decode(urldecode(array_shift($_REQUEST['request_line'])), true))
			: $_REQUEST['filters'];

		$GLOBALS['lib']->smarty->assign('title', lang('change_log'));
		$GLOBALS['lib']->smarty->assign('js_class', 'change_log_class');

		$GLOBALS['lib']->smarty->assign('pagination', ['filters'=>$filters]);

		\output::smarty('modules/core/view/manager.tpl', true);
	}

	function list_ajax() {
		$pagination = isset($_REQUEST['pagination']) ? $_REQUEST['pagination'] : [];

		$columns = change_log_db::get_columns();

		$model = empty($pagination['filters']['model']) ? null : $pagination['filters']['model'];
		if ($model) {
			$class_info = new ReflectionClass($model);
			$lang_file = dirname($class_info->getFileName()).'/../lang.php';
			if (is_file($lang_file))
				require_once $lang_file;
		}

		list($pagination, $records) = change_log_db::get_page($pagination);
		$model_list = array_unique(array_map(function($a){return substr(array_reverse(explode('\\', $a))[0], 0, -3);}, array_column($records, 'model')));
		\output::ajax([
			'success'	=> true,
			'table'		=> array_merge([
				'records'	=> $records,
				'pagination'=> $pagination,
				],
				empty($_REQUEST['build_data']) ? [] : [
				'columns'	=> change_log_db::get_columns(),
				'lang'		=> array_merge(
					\output::lang_prepare([
						'model_name'=>'\\change_log_db',
						'pagination'=>$pagination,
						'list'=>array_merge(['data_str'=>'data', 'model', 'edit_history', 'details'], $model_list, ['prev', 'next', 'display']),
					]),
					$model ? \output::lang_prepare(['model_name'=>$model]) : [],
				),
				'filters_model'	=> change_log_db::get_filters(),
				'filters_ref_name'	=> change_log_db::get_filters_ref_name($pagination['filters']),
				'enum'		=> change_log_db::get_enum(['model'=>$model]),
			]),
		]);
	}

	function view_ajax() {
		$success = false;
		$id = isset($_REQUEST['item_id']) ? $_REQUEST['item_id'] : -1;
		$obj = new change_log_db($id);

		if(!$obj->access('edit'))
			no_access();

		$GLOBALS['lib']->smarty->assign('data', $obj->get_data());
		$record_data_str = '';

		foreach ($obj->record_data as $f=>$v)
			$record_data_str .= "{$f}\t: {$v}\n";
		$GLOBALS['lib']->smarty->assign('record_data_str', $record_data_str);

		$GLOBALS['lib']->smarty->assign('enum', change_log_db::get_enum());

		\output::ajax([
			'success'	=> $success,
			'html'		=> $GLOBALS['lib']->smarty->fetch("modules/core/view/change_log/view.tpl"),
		]);
	}
}