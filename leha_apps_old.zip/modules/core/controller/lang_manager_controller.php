<?php


class lang_manager_controller extends \controller {
	protected static $access_name = ['root', 'cron', 'admin'];

	function start() {

		$d = 'lang_manager';
		$GLOBALS['lib']->lang->destination = $d;

		$map = [];
		foreach ($GLOBALS['lib']->file->read_dir('modules/', ['is_dir'=>true]) as $module) {
			$l = $GLOBALS['lib']->file->read_dir("modules/{$module}/", ['mask'=>'lang.php']);
			if (!$l) continue;
			$lang_file = "modules/{$module}/{$l[0]}";

			$map[$module] = [];
			foreach ($GLOBALS['lib']->lang->list as $ln) {
				$GLOBALS['lib']->lang->value = $ln;
				$GLOBALS[$d] = [];
				require ($lang_file);

				foreach($GLOBALS[$d] as $k=>$v) {
					if (!isset($map[$module][$k]))
						$map[$module][$k] = ['modules'=>[]];
					$map[$module][$k][$ln] = $v;
				}
			}
		}
		foreach ($map as $module=>$module_data)
			foreach ($map as $m=>$m_data)
				if ($module!==$m) {
					foreach (array_intersect_key($module_data, $m_data) as $k=>$v)
						$map[$module][$k]['modules'][] = $m;
				}

		$GLOBALS['lib']->smarty->assign('map', $map);

		\output::smarty('modules/core/view/lang_manager.tpl');
	}
}