<?php
class notes_db extends \table_db{
	protected static $table_name = 'notes';

	protected static $field_list = [
		'create_time'	=> ['type'=>'datetime'],
		'table_name'	=> ['type'=>'str'],
		'record_id'		=> ['type'=>'int'],
		'user_id'		=> ['type'=>'int', 'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
		'note'			=> ['type'=>'text'],
	];
	protected static $columns = [
		'default'	=> [
			'id'			=> ['sorted'=>true,		'className'=>'w50 a-right'],
			'create_time'	=> ['sorted'=>true],
			'table_name'	=> ['sorted'=>true],
			'record_id'		=> ['sorted'=>true],
			'note'			=> ['sorted'=>true],
			'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
		],
		'record'	=> [
			'id'			=> ['sorted'=>true,		'className'=>'w50 a-right'],
			'create_time'	=> ['sorted'=>true],
			'note'			=> ['sorted'=>true],
			'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
		],
	];
	static function get_columns($type='default') {
		return static::$columns[$type];
	}
	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'create_time', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $filters = [
		'default'	=> [
			'table_name'	=> ['type'=>'like'],
			'record_id'		=> ['type'=>'like'],
			'note'			=> ['type'=>'like'],
		],
		'record'	=> [
			'table_name'	=> ['type'=>'hidden'],
			'record_id'		=> ['type'=>'hidden'],
			'note'			=> ['type'=>'like'],
		],
	];

	function save($save_data=[], $options=[]) {
		if (empty($this->id)) {
			$save_data['user_id'] = $GLOBALS['user']['id'];
			$save_data['create_time'] = time();
		}
		parent::save($save_data);
	}

	static function post_process(&$list, $options = []) {
		$list_id = array_unique(array_diff(array_map('intval', array_column($list, 'user_id')), [0]));
		$user_list = count($list_id)>0 ? \user\user_db::get_list(['filters'=>['id'=>$list_id], 'key'=>'id']) : [];
		foreach ($list as $k=>$r) {
			$list[$k]['create_time_str'] = $GLOBALS['lib']->date_time->to_format($r['create_time'], true);
			$list[$k]['user_id_str'] = isset($user_list[$r['user_id']]) ? \user\user_db::record_get_name($user_list[$r['user_id']]) : $r['user_id'];
		}
	}
}