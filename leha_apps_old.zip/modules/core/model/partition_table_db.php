<?php

// таблица партицированная (секционированная)! выборка без фильтра по диапазону $partition_field будет сильно тормозить
abstract class partition_table_db extends \table_db {
	protected static $partition_field = null;
	protected static $partition_type = 'datetime'; // datetime | date
	protected static $partition_size = 'YYYY_MM'; // YYYY_MM | YYYY

	static function get_filters($type='default') {
		$filters = parent::get_filters($type);

		$f = [];
		if (!isset($filters[static::$partition_field.'_min']))
			$filters[static::$partition_field.'_min'] = ['type'=>'date_group_from', 'group'=>static::$partition_field.'_date'];
		if (!isset($filters[static::$partition_field.'_max']))
			$filters[static::$partition_field.'_max'] = ['type'=>'date_group_to', 'group'=>static::$partition_field.'_date'];

		static::check_filters($f);
		$filters[static::$partition_field.'_min']['value'] = $f[static::$partition_field.'_min'];
		$filters[static::$partition_field.'_max']['value'] = $f[static::$partition_field.'_max'];
		return $filters;
	}

	protected static function check_filters(&$filters) {
		$a = getdate();

		if (empty($filters[static::$partition_field.'_min']))
			$filters[static::$partition_field.'_min'] = static::$partition_size==='YYYY' ?
				$GLOBALS['lib']->date_time->date_to_format(gmmktime(12,0,0, 1, 1, $a['year'])) : // начало года
				$GLOBALS['lib']->date_time->date_to_format(gmmktime(0,0,0, $a['mon'], 1, $a['year'])); // начало месяца
		if (empty($filters[static::$partition_field.'_max']))
			$filters[static::$partition_field.'_max'] = static::$partition_size==='YYYY' ?
				$GLOBALS['lib']->date_time->date_to_format(gmmktime(0,0,0, 1, 0, $a['year']+1)) : // конец года
				$GLOBALS['lib']->date_time->date_to_format(gmmktime(0,0,0, $a['mon']+1, 0, $a['year'])); // конец месяца
	}
	static function prepare_filters($filters) {
		if (empty($filters['constructor']))
			static::check_filters($filters);

		if (static::$partition_type==='datetime') {
			if (!empty($filters[static::$partition_field.'_min']))
				$filters[static::$partition_field.'_min'] = $GLOBALS['lib']->date_time->to_stamp($filters[static::$partition_field.'_min']);
			if (!empty($filters[static::$partition_field.'_max']))
				$filters[static::$partition_field.'_max'] = $GLOBALS['lib']->date_time->to_stamp($filters[static::$partition_field.'_max']) + 3600*24-1;
		}

		return parent::prepare_filters($filters);
	}
	static function get_page(&$pagination_data) {
		static::check_filters($pagination_data['filters']);
		return parent::get_page($pagination_data);
	}

	//-- создать таблицу -----------------------------------------------------------------------------------------------
	public static function create_table($options=[]) {
		if (parent::create_table($options)) {
			$f = static::$partition_field;
			$t = static::$db->settings['prefix'].static::$table_name;
			$tz1 = static::$partition_type==='date' ? '' : " AT TIME ZONE ''UTC''";
			$tz2 = static::$partition_type==='date' ? '' : " AT TIME ZONE 'UTC'";

			static::$db->query(//-- функция создания секции таблицы ----------------------------------------------------------------
				"CREATE OR REPLACE FUNCTION {$t}_create_new_partition(parent_table_name text, partition_date timestamp, partition_name text) 
RETURNS VOID AS
\$BODY\$
DECLARE
	sql text;
BEGIN
	EXECUTE 'CREATE TABLE IF NOT EXISTS ' || partition_name || ' ( CHECK (
{$f}{$tz1} >= ''' || partition_date || ''' AND 
{$f}{$tz1} < ''' || partition_date + interval '".(static::$partition_size==='YYYY' ? '1 year' : '1 month')."' || '''
)) INHERITS (' || parent_table_name || ')';

 -- создаём индекс
".static::partition_index()."

END;
\$BODY\$
LANGUAGE plpgsql;");

			static::$db->query( //-- функция вставки данных в секцию ---------------------------------------------------------------
				"CREATE OR REPLACE FUNCTION {$t}_insert_row() 
RETURNS TRIGGER AS
\$BODY\$
DECLARE
	partition_date TIMESTAMP;
	partition_name TEXT;
BEGIN
	-- construct partition name
	partition_date := date_trunc('".(static::$partition_size==='YYYY' ? 'year' : 'month')."', NEW.{$f}{$tz2});
	partition_name := format('%s_%s', TG_TABLE_NAME, to_char(partition_date, '".static::$partition_size."'));

	-- create partition, if necessary
	IF NOT EXISTS(SELECT relname FROM pg_class WHERE relname = partition_name) THEN
		PERFORM {$t}_create_new_partition(TG_TABLE_NAME, partition_date, partition_name);
	END IF;

	-- insert to partition
	EXECUTE 'INSERT INTO ' || partition_name || ' VALUES (($1).*)' USING NEW;

	RETURN NULL; -- RETURN NEW if ORM

END;
\$BODY\$

LANGUAGE plpgsql;");

			static::$db->query(//-- триггер вставки данных в таблицу ---------------------------------------------------------------
				"CREATE TRIGGER bubuka_object_track_stat_before_insert_row_trigger
BEFORE INSERT ON ".static::$db->field_quote("#p#".static::$table_name)."
FOR EACH ROW EXECUTE PROCEDURE {$t}_insert_row();");

		}
	}

	protected static function partition_index() {
		$f = static::$partition_field;
		return "EXECUTE 'CREATE INDEX IF NOT EXISTS ' || partition_name || '_{$f}_idx ON ' || partition_name || ' ({$f})';";
	}
}