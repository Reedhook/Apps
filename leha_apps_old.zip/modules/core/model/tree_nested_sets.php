<?php
abstract class tree_nested_sets extends \table_db {
	protected static $log_changes = false;
	protected static $field_list = [
		'node_id'	=> ['type'=>'int'],
	];

	protected static $tree_table_name = 'tree_nested_sets';
	protected static $field_list_tree = [
		'tree_id'	=> ['type'=>'int',	'ref'=>'\\tree_db', 'view_only'=>true],
		'left'		=> ['type'=>'int'],
		'right'		=> ['type'=>'int'],
		'level'		=> ['type'=>'int'],
	];
	protected static $join_field_list = [
		'tree_id'	=> 'tree_id',
		'left'		=> 'tree.left',
		'right'		=> 'tree.right',
		'level'		=> 'tree.level',
	];

	protected static function get_sql_fields($options=[]) {
		return parent::get_sql_fields($options) . ",\n" .
//			static::$db->field_quote("tree.id")." AS node_id, ".
			static::$db->field_quote("tree.tree_id").", ".
			static::$db->field_quote("tree.left").", ".
			static::$db->field_quote("tree.right").", ".
			static::$db->field_quote("tree.level");
	}

	protected static function get_sql_from($options=[]) {
		return parent::get_sql_from($options)."
INNER JOIN ".static::$db->field_quote('#p#'.static::$tree_table_name)." AS tree ON tree.id=".static::$db->field_quote(static::$table_alias.'.node_id');
	}

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		foreach($filters as $f=>$v)
			if(!empty($v))
				if(isset(static::$field_list_tree[$f]))
					$res[$f] = ['f'=>'tree.'.$f, 'o'=>is_array($v)?'IN':'=', 'v'=>$v];

		if(isset($filters['node_id']))
			$res['node_id'] = ['f'=>'tree.id', 'o'=>is_array($filters['node_id'])?'IN':'=', 'v'=>$filters['node_id']];

		if(isset($filters['left>']))
			$res[] = ['f'=>'tree.left', 'o'=>'>', 'v'=>$filters['left>']];
		if(isset($filters['left>=']))
			$res[] = ['f'=>'tree.left', 'o'=>'>=', 'v'=>$filters['left>=']];
		if(isset($filters['left<']))
			$res[] = ['f'=>'tree.left', 'o'=>'<', 'v'=>$filters['left<']];
//		if(isset($filters['left<=']))
//			$res[] = ['f'=>'tree.left', 'o'=>'<=', 'v'=>$filters['left<=']];
		if(isset($filters['right>']))
			$res[] = ['f'=>'tree.right', 'o'=>'>', 'v'=>$filters['right>']];
//		if(isset($filters['right>=']))
//			$res[] = ['f'=>'tree.right', 'o'=>'>=', 'v'=>$filters['right>=']];
		if(isset($filters['right<']))
			$res[] = ['f'=>'tree.right', 'o'=>'<', 'v'=>$filters['right<']];
		if(isset($filters['right<=']))
			$res[] = ['f'=>'tree.right', 'o'=>'<=', 'v'=>$filters['right<=']];

		return $res;
	}

	function construct_by_data($data) {
		parent::construct_by_data($data);
//		foreach (static::$system_fields as $f=>$r)
//			$this->data[$f] = $data[$f];
		foreach (static::$field_list_tree as $f=>$r)
			$this->data[$f] = $data[$f];
//		foreach (static::$field_list as $f=>$r) if(isset($data[$f]))
//			$this->data[$f] = static::prepare_field_set($f, $data[$f]);
//		$this->data_old = $this->data;
	}

	function get_data($options=[]) {
		$data = [];
		foreach(static::$system_fields as $f=>$r)
			$data[$f] = isset($this->data[$f]) ? $this->data[$f] : null;
		foreach (static::$field_list_tree as $f=>$r)
			$data[$f] = isset($this->data[$f]) ? $this->data[$f] : null;
		foreach(static::$field_list as $f=>$r)
			$data[$f] = $this->get_field($f);

		return $data;
	}

	function __get($field) {
		if (isset(static::$field_list_tree[$field]))
			return isset($this->data[$field]) ? $this->data[$field] : null;

		return parent::__get($field);
	}
	function __set($field, $value) {
		if (isset(static::$field_list_tree[$field])) {
			$this->data[$field] = $value;
			return;
		}
		parent::__set($field, $value);
	}
	function __isset($field) {
		if (isset(static::$field_list_tree[$field]))
			return isset($this->data[$field]);

		return isset($this->data[$field]);
	}
//	function __unset($field) {
//		unset($this->data[$field]);
//	}

	static function get_list($options=[]) {
		unset($options['limit'], $options['offset']);
		$options['order'] = 'left';
		$options['dir'] = 'ASC';
		return parent::get_list($options);
	}

	static function list_to_tree($list, &$i=0, $level=0) {
		$tree = [];
		$counter = 0;
		while($i<count($list)) {
			if ($list[$i]['level']>$level) {
				$tree[$counter]['sub'] = static::list_to_tree($list, $i, $level+1);
				continue;
			} elseif ($list[$i]['level']<$level) {
				return $tree;
			} else {
				$tree[++$counter] = $list[$i++];
			}
		}
		return $tree;
	}

	static function create_root_node($root_data, $tree_id) {// returns the root data of new tree
		// create root node
		$node_data = [
			'tree_id'	=> $tree_id,
//			'item_id'	=> $obj->id,
			'left'		=> 0,
			'right'		=> 1,
			'level'		=> 0,
		];
		static::$db->insert(static::$tree_table_name, $node_data, false);

		$obj = new static();
		$obj->set_data($root_data);
		$obj->node_id = $node_data['id'];
		$obj->save();

		return array_merge(
			$obj->get_data(),
			$node_data
		);
	}

	protected static function get_node($node_id){
		$res = static::$db->query("SELECT * FROM ".static::$db->field_quote('#p#'.static::$tree_table_name).
			" WHERE ".static::$db->field_quote('id')."=".$node_id);

		if(count($res)>0) {
			return $res[0];
		} else {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> 'Unknown node_id: '.p($node_id, true),
			];
			throw new \Exception('custom exception');
		}
	}

	protected static function get_parent_node($node_data){
		if($node_data['level']==0)
			return [];

		$res = static::$db->query("SELECT * FROM ".static::$db->field_quote('#p#'.static::$tree_table_name).
			" WHERE ".static::$db->field_quote('tree_id')."=".static::$db->data_quote($node_data['tree_id']).
			" AND ".static::$db->field_quote('left')."<".static::$db->data_quote($node_data['left']).
			" AND ".static::$db->field_quote('right').">".static::$db->data_quote($node_data['right']).
			" AND ".static::$db->field_quote('level')."=".static::$db->data_quote($node_data['level']-1)
		);

		if(count($res)>0) {
			return $res[0];
		} else {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> 'There is no parent node for node id: '.p($node_data['id'], true),
			];
			throw new \Exception('custom exception');
		}
	}

	function get_branch($curren_include=true) {
		if (!$this->tree_id)
			return [];

		return $curren_include ?
			static::get_list(['filters'=>[
				'tree_id'	=> $this->tree_id,
				'left>='	=> $this->left,
				'right<='	=> $this->right,
			]]) :
			static::get_list(['filters'=>[
				'tree_id'	=> $this->tree_id,
				'left>'	=> $this->left,
				'right<'	=> $this->right,
			]]);
	}

	function get_parent_item() {
		$res = static::get_list(['filters'=>[
			'tree_id'	=> $this->tree_id,
			'left<'		=> $this->left,
			'right>'	=> $this->right,
			'level'		=> $this->level-1
		]]);

		return count($res)>0 ? $res[0] : [];
	}

	static function get_root_item($tree_id) {
		$res = static::get_list(['filters'=>[
			'tree_id'	=> $tree_id,
			'level'		=> 0
		]]);

		return count($res)>0 ? $res[0] : [];
	}

	function get_item_path($root_node_data=null) {
		if ($root_node_data)
			return static::get_list(['filters'=>[
				'tree_id'	=> $this->tree_id,
				'left<'		=> $this->left,
				'right>'	=> $this->right,
				'left>='	=> $root_node_data['left'],
			],
				'key'	=> 'id',
			]);
		return static::get_list(['filters'=>[
			'tree_id'	=> $this->tree_id,
			'left<'		=> $this->left,
			'right>'	=> $this->right,
		],
			'key'	=> 'id',
		]);
	}

	function get_next_item() {
		$res = static::get_list(['filters'=>[
			'tree_id'	=> $this->tree_id,
			'left'		=> $this->right+1,
			'level'		=> $this->level,
		]]);
		return count($res)>0 ? $res[0] : [];
	}

	protected static function check_tree($tree_id) {
		$db = static::$db;
		$from = " FROM ".$db->field_quote('#p#'.static::$tree_table_name);
		$where =" WHERE ".$db->field_quote('tree_id')."=".$db->data_quote($tree_id);

		$res = $db->query("SELECT id ".$from.$where.
			" AND ".$db->field_quote('left').">".$db->field_quote('right'));
		if (count($res)>0) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; left>right;\n".p($res, true),
			];
			throw new \Exception('custom exception');
		}

		$res = $db->query("SELECT COUNT(*) AS cnt, MIN(".$db->field_quote('left').") AS min_key,  MAX(".$db->field_quote('right').") AS max_key".$from.$where);
		if ($res[0]['min_key']!=0 || ($res[0]['max_key']+1)/2!=$res[0]['cnt']) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; cnt error",
			];
			throw new \Exception('custom exception');
		}

		$res = $db->query("SELECT id".$from.$where." AND (".$db->field_quote('right')."-".$db->field_quote('left').")%2=0");
		if (count($res)>0) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; ostatok;\n".p($res, true),
			];
			throw new \Exception('custom exception');
		}

		$res = $db->query("SELECT id ".$from.$where." AND (".$db->field_quote('left')."-".$db->field_quote('level').")%2>0");
		if (count($res)>0) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; level;\n".p($res, true),
			];
			throw new \Exception('custom exception');
		}

		$res = $db->query("SELECT ".$db->field_quote('left').", COUNT(*) AS cnt ".$from.$where." GROUP BY ".$db->field_quote('left')." HAVING COUNT(*)>1");
		if (count($res)>0) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; left repeat;",
			];
			throw new \Exception('custom exception');
		}

		$res = $db->query("SELECT ".$db->field_quote('right').", COUNT(*) AS cnt ".$from.$where." GROUP BY ".$db->field_quote('right')." HAVING COUNT(*)>1");
		if (count($res)>0) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'tree_nested error',
				'msg'	=> "tree_id={$tree_id}; right repeat",
			];
			throw new \Exception('custom exception');
		}
	}

	protected function add_child_node() {// add child node to the end of children list
		$db = static::$db;
		$insert_width = 2;

		$where =" WHERE ".$db->field_quote('tree_id')."=".$db->data_quote($this->tree_id);
		$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
			" SET ".$db->field_quote('left')."=".$db->field_quote('left')."+{$insert_width} ".
			$where." AND ".$db->field_quote('left').">".$db->data_quote($this->right)
		);
		$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
			" SET ".$db->field_quote('right')."=".$db->field_quote('right')."+{$insert_width} ".
			$where." AND ".$db->field_quote('right').">=".$db->data_quote($this->right)
		);

		$node_data = array(
			'tree_id'	=> $this->tree_id,
//			'item_id'	=> $item_id,
			'left'		=> $this->right,
			'right'		=> $this->right+1,
			'level'		=> $this->level+1,
		);

		$db->insert(static::$tree_table_name, $node_data, false);
		//$node_data['id'] = $db->query("SELECT currval('".static::$db->settings['prefix'].static::$tree_table_name."_id_seq') AS id;")[0]['id'];
		//$db->get_insert_id();

		$this->right += $insert_width;

		static::check_tree($this->tree_id);

		return $node_data;
	}

	function add_child_item($data) {
		$node_data = $this->add_child_node(); // create node

		$child_item = new static();
		$child_item->set_data($data);
		$child_item->node_id = $node_data['id'];
		$child_item->save();// create item

		foreach(['tree_id', 'left', 'right', 'level'] as $f)
			$child_item->data[$f] = $node_data[$f];

		return $child_item;
	}

	protected function paren_delete() {
		parent::delete();
	}

	function delete() {
		$db = static::$db;
		$branch_width = $this->right - $this->left + 1;

		$branch = $this->get_branch();
		foreach($branch as $item_data) {
			$item = new static();
			$item->construct_by_data($item_data);
			$item->paren_delete();
		}

		$where = " WHERE ".$db->field_quote('tree_id')."=".$db->data_quote($this->tree_id);

		$db->query("DELETE FROM ".$db->field_quote('#p#'.static::$tree_table_name).$where.
			" AND ".$db->field_quote('left').">=".$db->data_quote($this->left).
			" AND ".$db->field_quote('right')."<=".$db->data_quote($this->right)
		);
		$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
			" SET ".$db->field_quote('left')."=".$db->field_quote('left')."-{$branch_width} ".
			$where." AND ".$db->field_quote('left').">".$db->data_quote($this->right)
		);
		$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
			" SET ".$db->field_quote('right')."=".$db->field_quote('right')."-{$branch_width} ".
			$where." AND ".$db->field_quote('right').">=".$db->data_quote($this->right)
		);

		$tree_id = $this->tree_id;
		$this->data_old = $this->data = [];

		static::check_tree($tree_id);
	}

	function move_item_to($item_id) { // item_id - is new parent item
		if ($this->id==$item_id)
			return 'err_move_to_self';

		$parent_item = new static();
		$parent_item->construct_by_data($this->get_parent_item());

//		if (!$parent_item->id || $parent_item->id==$item_id) // same parent makes: move to last position
//			return 'err_move_to_same_parent';

		$new_parent_item = new static($item_id);

		if ($this->left<$new_parent_item->left && $this->right>$new_parent_item->right) // new parent is child of this
			return 'err_move_to_child';

		$db = static::$db;
		$branch_width = $this->right - $this->left + 1;
		$d_level = $new_parent_item->level - $parent_item->level;
		$branch_id_list = array_map(function($a){return static::$db->data_quote($a);}, array_column($this->get_branch(), 'node_id'));
		$where = " WHERE ".$db->field_quote('tree_id')."=".$db->data_quote($this->tree_id);

		if ($this->right>$new_parent_item->right) {// move backward
			$d_count = $new_parent_item->right - $this->left;

			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('left')."=".$db->field_quote('left')."+{$branch_width} ".
				$where.
				" AND ".$db->field_quote('left').">".$db->data_quote($new_parent_item->right).
				" AND ".$db->field_quote('left')."<".$db->data_quote($this->left)
			);
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('right')."=".$db->field_quote('right')."+{$branch_width} ".
				$where.
				" AND ".$db->field_quote('right').">=".$db->data_quote($new_parent_item->right).
				" AND ".$db->field_quote('right')."<".$db->data_quote($this->left)
			);
		}
		if ($this->right<$new_parent_item->right) {// move forward
			$d_count = $new_parent_item->right - $this->left - $branch_width;

			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('left')."=".$db->field_quote('left')."-{$branch_width} ".
				$where.
				" AND ".$db->field_quote('left').">".$db->data_quote($this->right).
				" AND ".$db->field_quote('left')."<".$db->data_quote($new_parent_item->right)
			);
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('right')."=".$db->field_quote('right')."-{$branch_width} ".
				$where.
				" AND ".$db->field_quote('right').">".$db->data_quote($this->right).
				" AND ".$db->field_quote('right')."<".$db->data_quote($new_parent_item->right)
			);
		}
		if (count($branch_id_list)>0)
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".
				$db->field_quote('right')."=".$db->field_quote('right')."+{$d_count}, ".
				$db->field_quote('left')."=".$db->field_quote('left')."+{$d_count}, ".
				$db->field_quote('level')."=".$db->field_quote('level')."+{$d_level} ".
				$where." AND ".$db->field_quote('id')." IN (".implode(', ', $branch_id_list).")"
			);

		static::check_tree($this->tree_id);
		return true;
	}

	function move_item_before($item_id) {
		if ($this->id==$item_id)
			return 'err_move_to_self';

		$before_item = new static($item_id);
		if ($before_item->level==0)
			return 'err_move_root';

		if ($this->left<$before_item->left && $this->right>$before_item->right) // before_item is child for this
			return 'err_move_to_child';

		$db = static::$db;
		$branch_width = $this->right - $this->left + 1;
		$d_level = $before_item->level - $this->level;
		$branch_id_list = array_map(function($a){return static::$db->data_quote($a);}, array_column($this->get_branch(), 'node_id'));
		$where = " WHERE ".$db->field_quote('tree_id')."=".$db->data_quote($this->tree_id);

		if ($this->right>$before_item->left) {// move backward
			$d_count = $before_item->left - $this->left;

			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('left')."=".$db->field_quote('left')."+{$branch_width} ".
				$where.
				" AND ".$db->field_quote('left').">=".$db->data_quote($before_item->left).
				" AND ".$db->field_quote('left')."<".$db->data_quote($this->left)
			);
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('right')."=".$db->field_quote('right')."+{$branch_width} ".
				$where.
				" AND ".$db->field_quote('right').">".$db->data_quote($before_item->left).
				" AND ".$db->field_quote('right')."<".$db->data_quote($this->left)
			);
		}
		if ($this->right<$before_item->left) {// move forward
			$d_count = $before_item->left - $this->left - $branch_width;

			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('left')."=".$db->field_quote('left')."-{$branch_width} ".
				$where.
				" AND ".$db->field_quote('left').">".$db->data_quote($this->right).
				" AND ".$db->field_quote('left')."<".$db->data_quote($before_item->left)
			);
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".$db->field_quote('right')."=".$db->field_quote('right')."-{$branch_width} ".
				$where.
				" AND ".$db->field_quote('right').">".$db->data_quote($this->right).
				" AND ".$db->field_quote('right')."<".$db->data_quote($before_item->left)
			);
		}
		if (count($branch_id_list)>0)
			$db->query("UPDATE ".$db->field_quote('#p#'.static::$tree_table_name).
				" SET ".
				$db->field_quote('right')."=".$db->field_quote('right')."+{$d_count}, ".
				$db->field_quote('left')."=".$db->field_quote('left')."+{$d_count}, ".
				$db->field_quote('level')."=".$db->field_quote('level')."+{$d_level} ".
				$where." AND ".$db->field_quote('id')." IN (".implode(', ', $branch_id_list).")"
			);

		static::check_tree($this->tree_id);

		return true;
	}

	//-- tree methods --------------------------------------------------------------------------------------------------
	protected static $tree_type_str = false;
	protected static $tree_data = false;
	static function get_tree_data() {
		if (static::$tree_data===false)
			static::$tree_data = \tree_db::get_or_create(['type'=>static::$tree_type_str])->get_data();
		return static::$tree_data;
	}

	static function get_root_data() {
		$tree_data = static::get_tree_data();
		$root_data = static::get_root_item($tree_data['id']);
		if (empty($root_data['id'])) {
			$root_data = static::create_root_node([], $tree_data['id']);
		}
		return $root_data;
	}

	public function access($action) {
		if (parent::access($action)) {
			if (!$this->id)
				return true;
			return true;
//			if ($this->tree_id==static::get_tree_data()['id'])
//				return true;
		}
		return false;
	}

	public static function create_table($options=[]) {
		tree_db::create_table($options);
		_tree_nested_sets::create_table($options);
		return parent::create_table($options);
	}
}

class _tree_nested_sets extends \table_db {
	protected static $log_changes = false;

	protected static $table_name = 'tree_nested_sets';
	protected static $field_list = [
		'tree_id'	=> ['type'=>'int',	'ref'=>'\\tree_db'],
		'left'		=> ['type'=>'int'],
		'right'		=> ['type'=>'int'],
		'level'		=> ['type'=>'int'],
	];
}

/*
DROP TABLE IF EXISTS public.api_tree_nested_sets;
CREATE TABLE public.api_tree_nested_sets (
"id" serial NOT NULL,
"tree_id" int4 DEFAULT 0 NOT NULL,
"left" int4 DEFAULT 0 NOT NULL,
"right" int4 DEFAULT 0 NOT NULL,
"level" int4 DEFAULT 0 NOT NULL,
CONSTRAINT api_tree_nested_sets_pkey PRIMARY KEY (id)
)
WITH (OIDS=FALSE);

ALTER TABLE public.api_tree_nested_sets OWNER TO postgres;

CREATE SEQUENCE IF NOT EXISTS public.api_tree_nested_sets_id_seq
MINVALUE 1
NO MAXVALUE
START 1
INCREMENT 1
OWNED BY public.api_tree_nested_sets_id;

ALTER TABLE public.api_tree_nested_sets_id_seq OWNER TO postgres;

ALTER TABLE public.api_tree_nested_sets
ALTER COLUMN id SET DEFAULT NEXTVAL('public.api_tree_nested_sets_id_seq'::regclass);
*/