<?php

class localisation_db extends \table_db {
	protected static $table_name = 'localisation';
	protected static $field_list = [
		'table_name'	=> ['type'=>'str'],
		'record_id'		=> ['type'=>'int'],
		'lang'			=> ['type'=>'enum'],
		'field_name'	=> ['type'=>'str', 'title'=>'field'],
		'str'			=> ['type'=>'str', 'case_insensitive'=>true, 'html'=>true],
	];
	protected static $log_changes = false;

	protected static $columns = [			// описание колонок при выводе списка
		'id'			=> ['sorted'=>true,		'className'=>'w50 a-right'],
		'table_name'	=> ['sorted'=>true],
		'record_id'		=> ['sorted'=>true],
		'lang'			=> ['sorted'=>true],
		'field_name'	=> ['sorted'=>true, 'title'=>'field'],
		'str'			=> [],
		'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $enum = [
		'lang'	=> []
	];
	static function get_enum($options=[]) {
		$enum = static::$enum;
		$enum['lang'] = array_combine($GLOBALS['lib']->lang->list, $GLOBALS['lib']->lang->list);
		return $enum;
	}

	protected static $filters = [
		'default'	=> [
			'table_name'	=> ['type'=>'like'],
			'record_id'		=> ['type'=>'int'],
			'lang'			=> ['type'=>'enum'],
			'field_name'	=> ['type'=>'like', 'title'=>'field'],
			'str'			=> ['type'=>'like'],
		],
	];

//	protected static function prepare_filters($filters) {
//		$res = parent::prepare_filters($filters);
//		return $res;
//	}

	static function insert_or_update ($data) {
		$sql_data = [];
		foreach($data as $f=>$v)
			$sql_data[$f] = static::prepare_field_set($f, $v);

		$sql =
			"INSERT INTO ".$GLOBALS['lib']->db->field_quote('#p#'.static::$table_name).
			" (".implode(', ', array_map([static::$db, 'field_quote'], array_keys($sql_data))).")\n".
			"VALUES (".implode(', ', array_map([static::$db, 'data_quote'], $sql_data)).")\n".
			(static::$db->db_type==='pg' ?
			"ON CONFLICT (table_name, record_id, lang, field_name) DO UPDATE SET\n" :
			"ON DUPLICATE KEY UPDATE ").
			$GLOBALS['lib']->db->field_quote('str').'='.$GLOBALS['lib']->db->data_quote($sql_data['str']);

		$GLOBALS['lib']->db->query($sql);
	}

	public static function create_table($options=[]) {
		parent::create_table($options);
		static::$db->create_index(static::$table_name, ['table_name', 'record_id', 'field_name', 'lang'], true);
	}

	static function update_enum() {
		$lang_list = $GLOBALS['lib']->lang->list;
		static::$enum['lang'] = array_combine($lang_list, $lang_list);
	}
}

localisation_db::update_enum();