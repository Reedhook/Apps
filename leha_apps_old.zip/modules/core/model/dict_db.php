<?php

class dict_db extends \table_db {
	protected static $table_name = 'dict';
	protected static $field_list = [
		'parent_id'		=> ['type'=>'int'],
		'name'			=> ['type'=>'str'],
		'value_int'		=> ['type'=>'int'],
		'value_str'		=> ['type'=>'str', ],
		'value_text'	=> ['type'=>'text', 'html'=>true],
	];
	protected static $columns = [
		'id'			=> ['sorted'=> true, 'className'=>'w50 a-right'],
		'parent_id'		=> ['sorted'=> true, 'className'=>'w50 a-right'],
		'name'			=> ['sorted'=> true, 'js_formatter'=>'td_formatter_ellipsis'],
		'value_int'		=> ['sorted'=> true, 'className'=>'w100 a-right'],
		'value_str'		=> ['sorted'=> true, 'js_formatter'=>'td_formatter_ellipsis'],
		'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
}
