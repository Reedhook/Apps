<?php
class db_stat {
	static protected $db = [];

	static function get($type) {
		if (empty(static::$db[$type]))
			static::create($type);
		return static::$db[$type];
	}

	static protected function create($type='') {
		if (isset($GLOBALS['conf']['db_'.$type])) {
			if ($GLOBALS['conf']['db_'.$type]['type'] === 'pg')
				static::$db[$type] = new \lib\db_pg();

			if ($GLOBALS['conf']['db_'.$type]['type'] === 'mysqli')
				static::$db[$type] = new \lib\db_mysqli();

			if ($GLOBALS['conf']['db_'.$type]['type'] === 'clickhouse')
				static::$db[$type] = new \lib\db_clickhouse();

			static::$db[$type]->connect($GLOBALS['conf']['db_'.$type]);
		} else {
			static::$db[$type] = $GLOBALS['lib']->db;
		}
	}
}