<?php
abstract class setting_db extends \table_db{
	protected static $table_name = 'settings';
	protected static $setting_group = null;
	protected static $setting_list = [];
	static $setting_map = [];

	protected static $field_list = [
		'setting_group'	=> ['type'=>'str'],
		'name'			=> ['type'=>'str'],
		'value_int'		=> ['type'=>'int'],
		'value_str'		=> ['type'=>'str'],
		'value_text'	=> ['type'=>'text', 'html'=>true],
	];

	protected static $setting_type	= [
		'group'		=> 'value_str',
		'int'		=> 'value_int',
		'str'		=> 'value_str',
		'text'		=> 'value_text',
		'checkbox'	=> 'value_int',
		'date'		=> 'value_str',
		'datetime'	=> 'value_str',
		'time'		=> 'value_str',
		'select'	=> 'value_str',
		'ref'		=> 'value_int',
		'byte'		=> 'value_int',
//		'radio'		=> 'value_str',
//		'cat'		=> 'value_int',

		// custom types
		'date_format'=>'value_str',
		'phone_format'=> 'value_int',
		'lang'		=> 'value_str',
		'skin'		=> 'value_str',
//		'row_list'	=> 'value_text'
	];
	static function prepare_value($type, $value) { // prepare data to put to database
		switch ($type) {
			case 'phone_format':
			case 'ref':
			case 'int':			return intval($value);
			case 'byte':		return bytes_to_int($value);
			case 'str':
			case 'text':		return strval($value);
			case 'checkbox':	return to_bool($value) ? 1 : 0;
			case 'date':		return $GLOBALS['lib']->date_time->to_sql($value, false);
			case 'datetime':	return $GLOBALS['lib']->date_time->to_sql($value, true);
			case 'time':		return $GLOBALS['lib']->date_time->to_sql_time($value, true);
			case 'select':
			case 'date_format':
			case 'lang':
			case 'skin':		return strval($value);
		}
		return $value;
	}
	static function formatter($map_item, $value) { // prepare data to show
		switch ($map_item['type']) {
			case 'ref':
				$ref_obj = new $map_item['ref']($value ? $value : null, ['empty_if_not_exists'=>true]);
				return $ref_obj->id ? $ref_obj->get_name_str() : '';
			case 'int':			return intval($value);
			case 'str':
			case 'text':		return strval($value);
			case 'byte':		return bytes_format($value);
			case 'checkbox':	return lang(to_bool($value) ? 'yes' : 'no');
			case 'date':		return $GLOBALS['lib']->date_time->to_format($value, false);
			case 'datetime':	return $GLOBALS['lib']->date_time->to_format($value, true);
			case 'time'	:		return $GLOBALS['lib']->date_time->to_sql_time($value);
			case 'select':		return lang(isset($map_item['enum'][$value]) ? $map_item['enum'][$value] : $map_item['value']);
			case 'date_format':	return $value;
			case 'lang':		return lang('lang_'.$value);
			case 'skin':		return lang('skin_'.$value);
			case 'phone_format': return $GLOBALS['lib']->phone::$formats[$value];
		}
		return $value;
	}


	protected static function prepare_filters($filters) {
		$filters['setting_group'] = static::$setting_group;
		return parent::prepare_filters($filters);
	}

	function save($save_data=[], $options=[]) {
		if (!$this->id)
			$save_data['setting_group'] = static::$setting_group;

		parent::save($save_data, $options);
	}

	static function read_all() {
		static::$setting_list = static::get_list(['key'=>'name']);
	}

	static function get_setting_list() {
		if (empty(static::$setting_list))
			static::read_all();
		return static::$setting_list;
	}
	static function get_settings() {
		if (empty(static::$setting_list))
			static::read_all();

		$res = [];
		foreach (static::$setting_map as $name=>$r)
			$res[$name] = static::prepare_value($r['type'],
				array_key_exists($name, static::$setting_list) ?
				static::$setting_list[$name][static::$setting_type[$r['type']]] :
				(isset($r['value']) ? $r['value'] : '')
			);

		return $res;
	}

	static function get_setting($name){
		if (empty(static::$setting_list))
			static::read_all();

		$r = static::$setting_map[$name];

		return static::prepare_value($r['type'],
			isset(static::$setting_list[$name]) ?
			static::$setting_list[$name][static::$setting_type[$r['type']]] :
			(isset($r['value']) ? $r['value']:'')
		);
	}

	static function save_setting($name, $value){
		if (empty(static::$setting_list))
			static::read_all();

		$obj = new static();
		if (isset(static::$setting_list[$name]))
			$obj->construct_by_data(static::$setting_list[$name]);

		$r = static::$setting_map[$name];

		$obj->save([
			'name'	=> $name,
			static::$setting_type[$r['type']] => static::prepare_value($r['type'], $value),
		]);

		static::$setting_list[$name] = $obj->get_data();
	}

}