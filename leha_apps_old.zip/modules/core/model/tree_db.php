<?php
class tree_db extends \table_db{
	protected static $table_name = 'tree';

	protected static $field_list = [
		'type'	=> ['type'=>'str'],
		'user_id'=>['type'=>'int', 'ref'=>'\\user\\user_db'],
		'title'	=> ['type'=>'str'],
	];

	public static function get_or_create($filters) {
		$list = static::get_list(['filters'=>$filters]);

		$obj = new static();
		if(count($list)>0) {
			$obj->construct_by_data($list[0]);
		} else {
			$obj->set_data($filters);
			$obj->save();
		}
		return $obj;
	}
}