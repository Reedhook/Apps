<?php
class file_db extends \table_db {
	protected static $table_name = 'file';
	protected static $table_alias = 'f';
	protected static $field_list = [
		'file_name'		=> ['type'=>'text', 'html'=>true], // путь, где файл хранится
		'original_name'	=> ['type'=>'text', 'html'=>true], // название файла
//		'type'			=> ['type'=>'enum'],

		'position'		=> ['type'=>'enum', 'title'=>'file_position'],
		'protected'		=> ['type'=>'bool'],
		'user_id'		=> ['type'=>'int', 'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
		'hash'			=> ['type'=>'str'],

		'mime_type'		=> ['type'=>'str'],
		'file_size'		=> ['type'=>'int'],
		'width'			=> ['type'=>'int'],
		'height'		=> ['type'=>'int'],
	];

	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'original_name', 'dir'=>'asc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static $enum = [
//		'access'	=> ['all'=>'all', 'own'=>'own'],
		'position'	=> [
			'u'		=> 'uploaded',	// файл расположен в папке сайта, в $GLOBALS['conf']['files']['upload']
			'e'		=> 'external',	// файл лежит на диске с сайтом, но не в папке $GLOBALS['conf']['files']['upload']
			'w'		=> 'web',		// файл лежит по ссылке
		],
		'mime_type'	=> [
			'text'	=> 'text',
			'image'	=> 'image',
			'audio'	=> 'audio',
			'video'	=> 'video',
		],
	];
	protected static $columns = [
		'id'			=> ['sorted'=> true, 'className'=>'w50 a-right'],
		'user_id'		=> ['js_formatter'=>'td_formatter_str_ellipsis'],
//		'protected'		=> ['js_formatter'=>'td_formatter_yes_no'],
		'original_name'	=> ['sorted'=> true, 'js_formatter'=>'td_formatter_ellipsis', 'title'=>'title'],
		'mime_type'		=> ['sorted'=> true, 'js_formatter'=>'td_formatter_ellipsis', 'className'=>'w100'],
		'file_size'		=> ['sorted'=> true, 'js_formatter'=>'td_formatter_str', 'className'=>'w100 a-right'],
		'functions'		=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
//			'type'			=> ['type'=>'hidden'],
			'user_id'		=> ['type'=>'ref', 'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
			'mime_type'		=> ['type'=>'str'],
			'original_name'	=> ['type'=>'like'],
			'protected'		=> ['type'=>'yes_no'],
			'hash'			=> ['type'=>'like'],
			'position'		=> ['type'=>'enum', 'title'=>'file_position'],

		],
	];

	static $record_name_field = 'original_name';

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		if (!empty($filters['own']))
			$res['user_id'] = ['f'=>"#a#user_id", 'o'=>'=', 'v'=>$GLOBALS['user']['id']];

		if (!empty($filters['mime_type']) && $filters['mime_type']!=='all')
			$res['mime_type'] = ['f'=>"#a#mime_type", 'o'=>'LIKE', 'v'=>$filters['mime_type']];

		if (!in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']) && empty($filters['constructor'])) {
			$res['access'] = ['o'=>'or', 'v'=>[
				['f'=>'user_id',	'o'=>'=', 'v'=>$GLOBALS['user']['id']],
				['f'=>'protected',	'o'=>'=', 'v'=>false],
			]];
		}

		return $res;
	}

	protected static function post_process(&$list, $options=[]) {
		$list_id = array_unique(array_diff(array_map('intval', array_column($list, 'user_id')), [0]));
		$user_list = count($list_id)>0 ? \user\user_db::get_list(['filters'=>['id'=>$list_id], 'key'=>'id']) : [];

		foreach($list as $k=>$r){
			$list[$k]['file_full_name'] = static::get_file_path($r);
			$list[$k]['file_size_str'] = bytes_format($r['file_size']);
//			number_format($r['file_size'], 0, '.', ' ');
			$list[$k]['url'] = static::get_url($r);
//			$list[$k]['url_hash'] = static::get_url_hash($r);
			$list[$k]['user_id_str'] = isset($user_list[$r['user_id']]) ? \user\user_db::record_get_name($user_list[$r['user_id']]) : $r['user_id'];
			$list[$k]['blue'] = to_bool($r['protected']);
		}
	}

	function access($action) {
		if (in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'manager']))
			return true;

		if ($this->protected) { // access for owner
			return $this->user_id === $GLOBALS['user']['id'];
		} elseif ($action==='view') { // everyone can view not protected file
			return true;
		}

		// edit
		if ($this->id>0) {
			if ($this->user_id==$GLOBALS['user']['id']) // only owner can edit file
				return true;
		} else {
			return $GLOBALS['user']['role']==='user'; // only user can create new file
		}

		return false;
	}

	protected function prepare_changes(){
		// если изменен protected
		$f = 'protected';
//		$i = static::$field_list[$f];
		if ($this->protected
			&& array_key_exists($f, $this->data_old)
			&& $this->data_old[$f]!=$this->data[$f]
			&& $this->position==='u'
		) { // перемещаем файл из папки public в protected
			$old_path = $this->file_path();
//			$new_pahe = str_replace('public', 'protected');
//			$file_path = pathinfo($new_pahe)['dirname'].'/';

			$protected_folder = 'protected/';
			$file_folder = $protected_folder.sprintf("%'.08d", floor($this->id/10000)).'/';
			$file_path = $GLOBALS['conf']['files']['upload'].$file_folder;

//			$file_folder = $protected_folder.sprintf("%'.08d", floor($this->id/10000)).'/';
//			$file_path = $GLOBALS['conf']['files']['upload'].$file_folder;
			if(!$GLOBALS['lib']->file->create_dir($file_path))
				return static::err("Can't create dir: " . $file_path);

			$disk_file_name = $file_path.$this->file_name;
			if (!rename($old_path, $disk_file_name))
				return static::err("Error copy file ".print_r($old_path, true)." to ".$disk_file_name);
			chmod($disk_file_name, 0777);

			$this->save(['file_folder'=>$file_folder], ['dont_prepare_changes'=>true]);
		}

		parent::prepare_changes();
	}

	public static function create_table($options=[]) {
		// таблицы user и file ссылаются друг на друга, потому столбец user_id будет создаваться из user
		$user_id_column = static::$field_list['user_id'];
		unset(static::$field_list['user_id']);
		$res = parent::create_table($options=[]);
		static::$field_list['user_id'] = $user_id_column;

		if ($res) {
			static::$db->create_index(static::$table_name, ['hash'], true);
			static::$db->query("ALTER TABLE ".static::$db->field_quote("#p#".static::$table_name)." ALTER COLUMN file_size SET DATA TYPE int8;", ['no_answer'=>true]);
		}

		return $res;
	}

	//-- upload --------------------------------------------------------------------------------------------------------
	protected static $err_str;
	static function get_err_str() {
		return static::$err_str;
	}
	protected static $err_exception = false;
	static protected function err($err_str){
		if (static::$err_exception) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'file_db error',
				'msg'	=> $err_str,
			];
			throw new \Exception('custom exception');
		}
		static::$err_str = $err_str;
		return false;
	}

	protected static function create_file_record($options=[]) {
		$obj = new static();
		$protected = to_bool($options['protected'] ?? false);

		$protected_folder = $protected ? 'protected/' : 'public/';

		if (!$GLOBALS['lib']->file->create_dir($GLOBALS['conf']['files']['upload'], ['htaccess'=>false]))
			return static::err("Can't create dir: " . $GLOBALS['conf']['files']['upload']);

		if (!$GLOBALS['lib']->file->create_dir($GLOBALS['conf']['files']['upload'].$protected_folder, ['htaccess'=>!to_bool($protected)]))
			return static::err("Can't create dir: " . $GLOBALS['conf']['files']['upload'].$protected_folder);

		// create record
		$obj->save();

		// create record folder
		$file_folder = $protected_folder.sprintf("%'.08d", floor($obj->id/10000)).'/';

		if (!$GLOBALS['lib']->file->create_dir($GLOBALS['conf']['files']['upload'].$file_folder)) {
			$obj->delete();
			return static::err("Can't create dir: " . $GLOBALS['conf']['files']['upload'].$file_folder);
		}

		$obj->set_data([
			'file_name'		=> $file_folder.sprintf("%'.08d", $obj->id),
			'user_id'		=> isset($options['user_id']) ? $options['user_id'] : $GLOBALS['user']['id'],
			'protected'		=> $protected,
		]);

		return $obj;
	}

	protected static $export_upload_counter = 0;
	static function upload($name, $options=[]) {
		static::$err_str = '';

		if (empty($options['file_source']) || $options['file_source']=='post') { //-- from $_FILES --------------------
			if (isset($options['index'])) {
				$index = $options['index'];
				if ($_FILES[$name]['error'][$index]!==UPLOAD_ERR_OK) {
					return static::err(@[
							UPLOAD_ERR_INI_SIZE=>'UPLOAD_ERR_INI_SIZE',
							UPLOAD_ERR_FORM_SIZE=>'UPLOAD_ERR_FORM_SIZE',
							UPLOAD_ERR_NO_TMP_DIR=>'UPLOAD_ERR_NO_TMP_DIR',
							UPLOAD_ERR_CANT_WRITE=>'UPLOAD_ERR_CANT_WRITE',
							UPLOAD_ERR_EXTENSION=>'UPLOAD_ERR_EXTENSION',
							UPLOAD_ERR_PARTIAL=>'UPLOAD_ERR_PARTIAL'
						][$_FILES[$name]['error'][$index]] ?? 'UPLOAD_ERR'
					);
				}

				if (isset($GLOBALS['user']) && !in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'manager']))
					if ($_FILES[$name]['size'][$index] >= \site\setting_db::get_setting('file_max_size'))
						return static::err(lang('file_max_size_exceed').' ('.bytes_format(\site\setting_db::get_setting('file_max_size')).')');

				if (!isset($_FILES[$name]['tmp_name'][$index]) || $_FILES[$name]['size'][$index]==0)
					return static::err("\$_FILES[{$name}]['tmp_name'][{$index}]- empty");

				$tmp_name		= $_FILES[$name]['tmp_name'][$index];
				$file_size		= $_FILES[$name]['size'][$index];
				$original_name	= $_FILES[$name]['name'][$index];
//				$mime_type		= $_FILES[$name]['type'][$index];
				$mime_type 		= mime_content_type($_FILES[$name]['tmp_name'][$index]);
			} else {
				if ($_FILES[$name]['error']!==UPLOAD_ERR_OK) {
					return static::err(@[
							UPLOAD_ERR_INI_SIZE=>'UPLOAD_ERR_INI_SIZE',
							UPLOAD_ERR_FORM_SIZE=>'UPLOAD_ERR_FORM_SIZE',
							UPLOAD_ERR_NO_TMP_DIR=>'UPLOAD_ERR_NO_TMP_DIR',
							UPLOAD_ERR_CANT_WRITE=>'UPLOAD_ERR_CANT_WRITE',
							UPLOAD_ERR_EXTENSION=>'UPLOAD_ERR_EXTENSION',
							UPLOAD_ERR_PARTIAL=>'UPLOAD_ERR_PARTIAL'
						][$_FILES[$name]['error']] ?? 'UPLOAD_ERR'
					);
				}

				if (isset($GLOBALS['user']) && !in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin', 'manager']))
					if ($_FILES[$name]['size'] >= \site\setting_db::get_setting('file_max_size'))
						return static::err(lang('file_max_size_exceed').' ('.bytes_format(\site\setting_db::get_setting('file_max_size')).')');

				if (!isset($_FILES[$name]['tmp_name']) || $_FILES[$name]['size']==0)
					return static::err("\$_FILES[{$name}]['tmp_name'] - empty");

				$tmp_name		= $_FILES[$name]['tmp_name'];
				$file_size		= $_FILES[$name]['size'];
				$original_name	= $_FILES[$name]['name'];
//				$mime_type		= $_FILES[$name]['type'];
				$mime_type 		= mime_content_type($_FILES[$name]['tmp_name']);
			}

			$obj = static::create_file_record($options);
			$disk_file_name = $GLOBALS['conf']['files']['upload'].$obj->file_name;

			if (move_uploaded_file($tmp_name, $disk_file_name)) {
				chmod($disk_file_name, 0777);
			} else {
				$obj->delete();
				return static::err("Error move_uploaded_file ".print_r($tmp_name, true)." to ".$obj->file_name);
			}

			$imagesize = strpos($mime_type, 'image/')===0 ? getimagesize($disk_file_name) : false;
			$obj->save([
				'original_name'	=> $original_name,
				'mime_type'		=> $mime_type,
				'position'		=> 'u',
				'hash'			=> static::create_hash($obj->id),
				'file_size'		=> $file_size,
				'width'			=> $imagesize===false ? 0 : $imagesize[0],
				'height'		=> $imagesize===false ? 0 : $imagesize[1],
			]);
		} elseif ($options['file_source']==='file') { //-- copy existing file -------------------------------------------

			$obj = static::create_file_record($options);
			$disk_file_name = $GLOBALS['conf']['files']['upload'].$obj->file_name;

			if(copy($name, $disk_file_name)) {
				chmod($disk_file_name, 0777);
			} else {
				$obj->delete();
				return static::err("Error copy file ".print_r($name, true)." to ".$disk_file_name);
			}

			$mime_type = mime_content_type($disk_file_name);
			$imagesize = strpos($mime_type, 'image/')===0 ? getimagesize($disk_file_name) : false;
			$obj->save([
				'original_name'	=> pathinfo($name)['basename'],
				'mime_type'		=> $mime_type,
				'position'		=> 'u',
				'hash'			=> static::create_hash($obj->id),
				'file_size'		=> filesize($disk_file_name),
				'width'			=> $imagesize===false ? 0 : $imagesize[0],
				'height'		=> $imagesize===false ? 0 : $imagesize[1],
			]);
		} elseif ($options['file_source']==='external') { //-- add existing file (don't copy) ---------------------------
			$obj = new static();
			if (!file_exists($name))
				return static::err("File doesn't exist: ".$name);

			$obj->save([
				'file_name'		=> $name,
				'user_id'		=> isset($options['user_id']) ? $options['user_id'] : $GLOBALS['user']['id'],
				'protected'		=> $options['protected'] ?? false,
			]);

			$mime_type		= mime_content_type($name);
			$file_size		= filesize($name);
			$imagesize		= strpos($mime_type, 'image/')===0 ? getimagesize($name) : false;
			$obj->save([
				'original_name'	=> pathinfo($name)['basename'],
				'mime_type'		=> $mime_type,
				'position'		=> 'e',
				'user_id'		=> isset($options['user_id']) ? $options['user_id'] : $GLOBALS['user']['id'],
				'hash'			=> static::create_hash($obj->id),

				'file_size'		=> $file_size,
				'width'			=> $imagesize===false ? 0 : $imagesize[0],
				'height'		=> $imagesize===false ? 0 : $imagesize[1],
			]);
		} elseif ($options['file_source']==='url') { //-- from http ------------------------------------------------------

			$obj = static::create_file_record();
			$obj->save([
				'file_name'		=> $name,
				'original_name'	=> pathinfo($name)['basename'],
				'mime_type'		=> $options['mime_type'] ?? '',
				'position'		=> 'w',
				'hash'			=> static::create_hash($obj->id),

				'file_size'		=> empty($options['file_size']) ? '' : $options['file_size'],
				'width'			=> empty($options['width']) ? '' : $options['width'],
				'height'		=> empty($options['height']) ? '' : $options['height'],
			]);
		} elseif ($options['file_source']==='content') {
			$obj = static::create_file_record($options);
			$disk_file_name = $GLOBALS['conf']['files']['upload'].$obj->file_name;

			if (
				file_put_contents($disk_file_name, $options['content'])) {
				chmod($disk_file_name, 0777);
			} else {
				$obj->delete();
				return static::err("Error file put content ".$obj->file_name);
			}

			$mime_type		= mime_content_type($disk_file_name);
			$file_size		= filesize($disk_file_name);
			$imagesize		= strpos($mime_type, 'image/')===0 ? getimagesize($disk_file_name) : false;

			$obj->save([
				'original_name'	=> $name,
				'mime_type'		=> $mime_type,
				'position'		=> 'u',
				'hash'			=> static::create_hash($obj->id),
				'file_size'		=> $file_size,
				'width'			=> $imagesize===false ? 0 : $imagesize[0],
				'height'		=> $imagesize===false ? 0 : $imagesize[1],
			]);
		}

		return empty($options['return_id']) ? $obj : $obj->id;
	}

	//-- custom --------------------------------------------------------------------------------------------------------
	static function get_url_id($r) {
//		return $GLOBALS['conf']['site']['site_url'].'core/file/id/'.$r['id'];
	}
	static function get_url_hash($r) {
		return $GLOBALS['conf']['site']['site_url'].'core/file/hash/'.$r['hash'];
	}

	function file_path() {
		return static::get_file_path($this->data);
	}
	static function get_file_path($r) {
//UPDATE bbk_file_bbk_export SET name = REPLACE(name, 'php.bubuka.info', 'bubuka.local') WHERE name LIKE '%php.bubuka.info%';
//UPDATE bbk_file SET file_folder = REPLACE(file_folder, 'php.bubuka.info', 'bubuka.local') WHERE file_folder LIKE '%php.bubuka.info%';

		if ($r['position']==='u')
			return getcwd().DIRECTORY_SEPARATOR.$GLOBALS['conf']['files']['upload'].$r['file_name'];
		if ($r['position']==='e')
			return $r['file_name'];
		if ($r['position']==='w')
			return $r['file_name'];

		return false;
	}

	function url() {
		return static::get_url($this->data);
	}

	static function get_url($r) {
		if ($r['position']==='w')
			return $r['file_name'];

		if (to_bool($r['protected']))
			return static::get_url_hash($r);

		if ($r['position']==='u')
			return $GLOBALS['conf']['site']['site_url'].$GLOBALS['conf']['files']['upload'].$r['file_name'];
//			return static::get_url_hash($r);

		if ($r['position']==='e')
			return static::get_url_hash($r);
	}

	function thumb_url($w=0, $h=0, $cover=false) {
		return static::get_thumb_url($this->data, $w, $h, $cover);
	}
	static function get_thumb_url($r, $w=0, $h=0, $cover=false) {
		return to_bool($r['protected']) ? false :
			$GLOBALS['conf']['site']['site_url'].
			$GLOBALS['conf']['files']['thumb'].
			'public/'.
			$r['hash'].($w?'_'.$w.($h?'_'.$h.($cover?'_c':''):''):'');
	}

	function out($options=[]) {
		if ($this->position==='w') {
			$source_file = $this->file_name;
		} else {
			$source_file = $this->file_path();
			if (!file_exists($source_file)) {
				echo "file doesn't exist on disk";
				return;
			}
		}
		$disposition = empty($options['disposition']) ? 'attachment' : $options['disposition']; // inline : attachment
//		$file_size = filesize($source_file);
		$file_size = $this->file_size;

		header('Content-type: '.$this->mime_type);
		header("Content-Disposition: {$disposition}; filename=\"{$this->original_name}\"");
		header("Content-Length: ".$file_size);
		header("Accept-Ranges: bytes");
//		header("Content-Range: bytes {$file_size}/{$file_size}"); // для скачивания частями - нафиг не нужно
		header("Cache-control: public");
		header("Cache-control: max-age=60");

		if ($this->position==='w') {
			echo file_get_contents($source_file);
		} else {
			readfile($source_file);
		}
	}

	function delete() {
		if ($this->position==='u')
			@unlink($this->file_path());

		parent::delete();
	}

	static function create_hash($code='') {
		if (empty($GLOBALS['export'])) {
			do {
				$hash = md5((function_exists('random_int') ? random_int(100000, 999999) : rand(100000, 999999)).time().$code);
				$list = static::get_list(['filters'=>['hash'=>$hash]]);
			} while (count($list)>0);
		} else {
			$hash = sprintf('%09s', $code).substr(md5((function_exists('random_int') ? random_int(100000, 999999) : rand(100000, 999999))), 9);
		}
		return $hash;
	}

	protected static $mime_types = [
		'txt'	=> 'text/plain',
		'htm'	=> 'text/html',
		'html'	=> 'text/html',
		'php'	=> 'text/html',
		'css'	=> 'text/css',
		'js'	=> 'application/javascript',
		'json'	=> 'application/json',
		'xml'	=> 'application/xml',
		'swf'	=> 'application/x-shockwave-flash',

		// images
		'png'	=> 'image/png',
		'jpg'	=> 'image/jpeg',
		'jpeg'	=> 'image/jpeg',
		'jpe'	=> 'image/jpeg',
		'gif'	=> 'image/gif',
		'bmp'	=> 'image/bmp',
		'ico'	=> 'image/vnd.microsoft.icon',
		'tiff'	=> 'image/tiff',
		'tif'	=> 'image/tiff',
		'svg'	=> 'image/svg+xml',
		'svgz'	=> 'image/svg+xml',

		// archives
		'zip'	=> 'application/zip',
		'rar'	=> 'application/x-rar-compressed',
		'exe'	=> 'application/x-msdownload',
		'msi'	=> 'application/x-msdownload',
		'cab'	=> 'application/vnd.ms-cab-compressed',

		// audio/video
		'mp3'	=> 'audio/mpeg',
		'qt'	=> 'video/quicktime',
		'mov'	=> 'video/quicktime',
		'flv'	=> 'video/x-flv',

		// adobe
		'pdf'	=> 'application/pdf',
		'psd'	=> 'image/vnd.adobe.photoshop',
		'ai'	=> 'application/postscript',
		'eps'	=> 'application/postscript',
		'ps'	=> 'application/postscript',

		// ms office
//		'doc'	=> 'application/msword',
		'rtf'	=> 'application/rtf',
		'xls'	=> 'application/vnd.ms-excel',
		'doc'	=> 'application/vnd.ms-word',
		'ppt'	=> 'application/vnd.ms-powerpoint',

		// open office
		'odt'	=> 'application/vnd.oasis.opendocument.text',
		'ods'	=> 'application/vnd.oasis.opendocument.spreadsheet',
	];
	static function ext_by_mime_type($mime_type) {
		return array_search(static::$mime_types[$mime_type]);
	}
}