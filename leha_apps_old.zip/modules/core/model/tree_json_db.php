<?php
/*
class tree_json_db extends \table_db {
	protected static $table_name = 'tree_json';
	protected static $field_list = [
		'tree_name'		=> ['type'=>'str'],
		'is_system'		=> ['type'=>'int'],
		'table_name'	=> ['type'=>'str'],
		'tree_structure'=> ['type'=>'json'],
//		'user_id'		=> ['type'=>'int'],
	];

	protected
		$tree	= [],
		$map	= [],
		$list_data = [];

	public function __construct($id=null, $stop_if_not_exist=true) {
		parent::__construct($id, $stop_if_not_exist);
		$this->_prepare_map();
	}

	protected function _prepare_map () {
		if(!$this->id)
			return;

		$this->tree = empty($this->data['tree_structure']) ? [0=>[]] : json_decode($this->data['tree_structure'], true);
		$this->map = [];
		static::_build_map($this->tree, $this->map);
		$this->list_data = $GLOBALS['lib']->db->query("SELECT *
FROM ".$GLOBALS['lib']->db->field_quote('#p#'.$this->table_name)."
WHERE id IN (".implode(', ', array_keys($this->map)).")",
			['key'=>'id']);
		foreach($this->map as $id=>$node)
			if(isset($this->list_data[$id]))
				$this->map[$id]['data'] = $this->list_data[$id];
	}

	protected static function _build_map(&$tree, &$map, $level=0, $parent_id=0) {
		foreach($tree as $id=>$child_list) {
			$map[$id] = ['children'=>&$tree[$id], 'data'=>[], 'level'=>$level, 'parent_id'=>$parent_id];
			static::_build_map($tree[$id], $map, $level+1, $id);
		}
	}

	public function add_node ($item_o, $parent_id=null, $rebuild=false) { // $item_o - is table_db object
		if(empty($parent_id))
			$parent_id = 0;
		$this->map[$parent_id]['children'][$item_o->id] = [];
		$this->save();

		if($rebuild) {
			$this->map = [];
			static::_build_map($this->tree, $this->map);
			$this->list_data[] = $item_o->get_data();
			foreach ($this->list_data as $r)
				$this->map[$r['id']]['data'] = $r;
		}
	}

	public function move_node($item_o, $parent_id, $rebuild=false) {
		$from_parent_id = $this->map[$item_o->id]['parent_id'];

		if($parent_id==$from_parent_id)
			return;

		$i = $parent_id;
		while($i!=0) {
			if($i==$item_o->id)
				return;
			$i = $this->map[$i]['parent_id'];
		}

		$this->map[$parent_id]['children'][$item_o->id] = $this->map[$from_parent_id]['children'][$item_o->id];
		unset($this->map[$from_parent_id]['children'][$item_o->id]);
		$this->save();

		if($rebuild) {
			$this->map = [];
			static::_build_map($this->tree, $this->map);
			$this->list_data[] = $item_o->get_data();
			foreach ($this->list_data as $r)
				$this->map[$r['id']]['data'] = $r;
		}
	}

	public function move_in_order_before($item_o, $before_item_id, $rebuild=false) {
		$parent_id = $this->map[$item_o->id]['parent_id'];

		$new_line = [];
		foreach($this->map[$parent_id]['children'] as $id=>$sub) {
			if($id==$item_o->id)
				continue;
			if($id==$before_item_id)
				$new_line[$item_o->id] = $this->map[$item_o->id]['children'];
			$new_line[$id] = $sub;
		}
		if($before_item_id==0)
			$new_line[$item_o->id] = $this->map[$parent_id]['children'][$item_o->id];
		$this->map[$parent_id]['children'] = $new_line;
		$this->save();

		if($rebuild) {
			$this->map = [];
			static::_build_map($this->tree, $this->map);
			foreach ($this->list_data as $r)
				$this->map[$r['id']]['data'] = $r;
		}
	}

	public function delete_node($item_o, $rebuild=false) {
		$parent_id = $this->map[$item_o->id]['parent_id'];

		unset($this->map[$parent_id]['children'][$item_o->id]);
		unset($this->map[$item_o->id]);
		$this->save();

		if($rebuild) {
			$this->map = [];
			static::_build_map($this->tree, $this->map);
			foreach ($this->list_data as $r)
				$this->map[$r['id']]['data'] = $r;
		}
	}

	public function get_path($item_id, $map=false) {
		if(!$map)
			$map = $this->map;
		$path_list = [];
		$i = $item_id;
		while($i!=0) {
			$path_list[$i] = $map[$i]['data'];
			$i = $map[$i]['parent_id'];
		}
		return array_reverse($path_list);
	}

	public function save() {
		$this->data['tree_structure'] = empty($this->tree) ? '' : json_encode($this->tree, JSON_FORCE_OBJECT);
		parent::save();
	}

	public static function get_or_create($data) {
		$obj = parent::get_or_create($data);
		$obj->_prepare_map();
		return $obj;
	}

	public function get_map() {
		return $this->map;
	}

	public function get_tree() {
		return $this->tree;
	}

	public function get_sub_map($node_id) {
		$sub_map = [$node_id=>[
			'children'	=> &$this->tree[$node_id],
			'data'		=> $this->list_data[$node_id],
			'level'		=> 0,
			'parent_id'	=> 0,
		]];

		static::_build_map($this->map[$node_id]['children'], $sub_map, 1, $node_id);
		foreach($sub_map as $id=>$node)
			if(isset($this->list_data[$id]))
				$sub_map[$id]['data'] = $this->list_data[$id];
		return $sub_map;
	}

	public function access($action) {
		if ($this->is_system) {
			if($GLOBALS['user']['role']=='root')
				return true;
			if($GLOBALS['user']['role']=='admin')
				return true;
		} else {
//			if(in_array($GLOBALS['user']['role'], ['user', 'guest']) && $action=='view')
//				return true;
		}
		return false;
	}

}*/