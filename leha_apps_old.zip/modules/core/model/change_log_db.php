<?php

class change_log_db extends \partition_table_db {
	public static $db = null;
	protected static $partition_field = 'event_time';

	protected static $table_name = 'change_log';
	protected static $log_changes = false;
	protected static $field_list = [
		'event_time'	=> ['type'=>'datetime'],
		'user_id'		=> ['type'=>'int'], //'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
		'change_type'	=> ['type'=>'int'],
//		'table_name'	=> ['type'=>'str'],
		'model'			=> ['type'=>'str'],
		'record_id'		=> ['type'=>'int'],
		'record_data'	=> ['type'=>'json'],
	];
	protected static $enum = [
		'change_type'	=> [
			1	=> 'change_insert',
			2	=> 'change_update',
			3	=> 'change_delete',
		],
		'change_type_str'	=> [ // специально для js, где с числовыми индексами хлопоты
			'insert'	=> 'change_insert',
			'update'	=> 'change_update',
			'delete'	=> 'change_delete',
		],
		'change_type_str_int'	=> [
			'insert'	=> 1,
			'update'	=> 2,
			'delete'	=> 3,
		],

		'field'	=> [],
	];
	static function get_enum($options=[]) {
		$enum = static::$enum;
		if (isset($options['model'])) {
			$field_name_list = array_keys($options['model']::get_field_list());
			sort($field_name_list);
			$enum['field'] = array_combine($field_name_list, $field_name_list);
		}

		return $enum;
	}

	protected static $json_map = [
		'record_data'	=> [],
	];
	protected static $filters = [
		'default' => [
			'id'			=> ['type'=>'int'],
			'user_id'		=> ['type'=>'ref', 'ref'=>'\\user\\user_db', 'js_call'=>'user_list_show'],
			'change_type_str'=>['type'=>'enum'],
			'event_time_min'=> ['type'=>'date_group_from',	'group'=>'event_time_date'],
			'event_time_max'=> ['type'=>'date_group_to',	'group'=>'event_time_date'],
			'day'			=> ['type'=>'date_group_day',	'group'=>'event_time_date', 'slim'=>true],
			'month'			=> ['type'=>'date_group_month',	'group'=>'event_time_date', 'slim'=>true],
			'year'			=> ['type'=>'date_group_year',	'group'=>'event_time_date', 'slim'=>true],

			'record_id'		=> ['type'=>'int'],
//			'table_name'	=> ['type'=>'hidden'],
			'model'			=> ['type'=>'hidden'],
			'field_data'	=> ['type'=>'str'],
			'field'			=> ['type'=>'enum'],
		],
	];

	protected static $pagination = ['page_size'=>10, 'page_no'=>0, 'order'=>'id', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,'all']];

	function save($save_data=false, $options=[]) {
		if ($this->id) // create only (don't update exists record)
			return;

		$save_data['event_time'] = time();
		$save_data['user_id'] = $GLOBALS['user']['id']>0 ? $GLOBALS['user']['id'] : null;

		parent::save($save_data);
	}

	protected static $columns = [
		'id'				=> ['sorted'=>true,	'className'=>'w50 a-right'],
		'event_time'		=> ['sorted'=>true,	'js_formatter'=>'td_formatter_str', 'className'=>'w150'],
		'user_id'			=> ['sorted'=>true,	'js_formatter'=>'td_formatter_str', 'className'=>'w120'],
//		'table_name'		=> ['sorted'=>true,],
		'record_id'			=> ['sorted'=>true,	'className'=>'w50 a-right'],
		'change_type'		=> ['sorted'=>true,	'js_formatter'=>'td_formatter_enum', 'className'=>'w120'],
		'data_str'			=> ['js_formatter'=>'td_formatter_data_list'],
		'functions'			=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

/*	protected static function get_sql_fields($options=[]) {
		return parent::get_sql_fields($options).", u.email AS user_id_str";
	}

	protected static function get_sql_from($options=[]) {
		return parent::get_sql_from($options)."
LEFT JOIN ".$GLOBALS['lib']->db->field_quote("#p#user")." AS u ON u.id=".static::$table_alias.".user_id";
	}
*/

	protected static function post_process(&$list, $options=[]) {
		$user_id_list = array_unique(array_diff(array_column($list, 'user_id'), [null, '']));
		$user_list = count($user_id_list)>0 ? \user\user_db::get_list(['filters'=>['id'=>$user_id_list, 'constructor'=>true], 'key'=>'id']) : [];

		foreach ($list as $k=>$r) {
			$list[$k]['event_time_str'] = $GLOBALS['lib']->date_time->to_format($r['event_time'], true);
			$list[$k]['data'] = json_decode($r['record_data'], true);
			$list[$k]['data_str'] = [];
			$list[$k]['user_id_str'] = isset($user_list[$r['user_id']]) ? \user\user_db::record_get_name($user_list[$r['user_id']]) : $r['user_id'];

			$list[$k]['data_str'] = static::data_to_str($r['model'], $list[$k]['data']);
		}
	}
	static function data_to_str($model, $data, $options=[]) {
		$field_list = $options['field_list'] ?? ($model ? $model::get_field_list() : []);
		$field_list_localisation = $model && in_array('_localisation_db', class_parents($model)) ? $model::get_localisation_fields() : [];

		$res = [];

		foreach ($data as $f=>$v) {
			if (!isset($v)) {
				$v = lang('no');
			} elseif (isset($field_list[$f]) && $field_list[$f]['type']==='bool') {
				$v = lang($v?'yes':'no');
			} elseif (isset($field_list[$f]) && $field_list[$f]['type']==='json') {
				$res = array_merge($res, static::data_to_str($model, $v ? json_decode($v, true) : [], ['field_list'=>$model::get_json_map()[$f]]));
				continue;
			} elseif (isset($field_list_localisation[$f])) {
				$a = json_decode($v, true);
				$v = implode(";\n", array_map(function ($lang, $str){return "{$lang}: {$str}";}, array_keys($a), $a));
			} elseif (isset($field_list[$f]) && $field_list[$f]['type']==='text' && mb_strlen($v)>252) {
				$v = mb_substr($v, 0, 252).'...';
			}

			if (is_array($v)) {
				foreach ($v as $v_k=>$v_v)
					$v[$v_k] = $v_k.':'.$v_v;
				$v = implode(';', $v);
			}


			$f_lang = isset($GLOBALS['lang'][$f]) ? lang($f) : $f;
			$res[$f_lang] = $v;
		}

		return $res;

	}

	static function prepare_filters($filters) {
		if (!empty($filters['model']) && $filters['model'][0]==='\\')
			$filters['model'] = substr($filters['model'], 1);

//		$filters['event_time_min'] = $GLOBALS['lib']->date_time->to_stamp($filters['event_time_min']);
//		$filters['event_time_max'] = $GLOBALS['lib']->date_time->to_stamp($filters['event_time_max']) + 3600*24 - 1;

		if (isset($filters['change_type_str']) && $filters['change_type_str']!=='all')
			$filters['change_type'] = static::$enum['change_type_str_int'][$filters['change_type_str']];

		$res = parent::prepare_filters($filters);

		if (!empty($filters['field']) && $filters['field']!=='all')
			$res['field'] = ['f'=>"#a#record_data", 'o'=>'?&', 'v'=>$filters['field']];

		if (!empty($filters['field_data'])) {
			$filters['field_data'] = array_map('trim', explode(';', $filters['field_data']));
			foreach ($filters['field_data'] as $field_data) {
				list($f, $v) = explode('=', $field_data, 2);
				if (ctype_digit($v))
					$v = intval($v);

				$res['field_data_'.$f] = ['f'=>"#a#record_data", 'o'=>'@>', 'v'=>[$f, $v]];
			}
		}

		return $res;
	}

	public function access($action) {
		if (in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			return true;
		return false;
	}

//	function restore($class_name) {
//		$record_data = $this->record_data;
//		$obj = new $class_name();
//		$obj->save($this->record_data, ['insert_id'=>$record_data['id']]);
//	}
}
change_log_db::$db = db_stat::get('stat');
