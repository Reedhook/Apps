<?php
/*
класс для локализации полей
локализованные поля перечислены в переменной static $localisation_fields
физически эти поля отсутствуют в таблице, значения хранятся в таблице #p#localisation
[field_name => table_alias, field_name => table_alias]
где field_name - как обращаться к полю из объекта для записи / чтения
table_alias - для формирования SQL, так же можно задавать, как сортировку
по __get - возвращает массив

так же необходимо добавить эти поля в  static $join_field_list, если вы рассчитываете сортировать или совершать поиск по этим полям

по умолчанию калсс настроен на одно локализованное поле - name

данные для локализации хранятся в переменной $localisation_data
[field_name_1=>['ru'=>str, 'en'=>str, ...], field_name_2=> ...]

в set_data можно передавать массив ['ru'=>str, 'en'=>str, ...],
либо строку, которая будет преобразована в массив ['текущий_язык'=>str]

*/
abstract class _localisation_db extends \table_db {
	protected static $localisation_fields = [// field_name=>alias
		'name'	=> 'nl',
	];
	public static function get_localisation_fields() {return static::$localisation_fields;}
	protected static $join_field_list = ['name'=>'nl.str'];
	protected $localisation_data = [];
	protected $localisation_data_old = [];
	protected static $trust = false;

	protected static $columns = [
		'id'				=> ['sorted'=>true, 'className'=>'w50 a-right'],
		'name'				=> ['sorted'=>true, 'title'=>'title'],
		'functions'			=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $filters = [
		'default' => [
			'id'	=> ['type'=>'int'],
			'name'	=> ['type'=>'like', 'title'=>'title'],
		]
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'name', 'dir'=>'asc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	function __construct($id=null, $options=[]) {
		parent::__construct($id, $options);
		if ($id>0) {
			$this->get_localisation();
		}
	}

	function construct_by_data($data) {
		parent::construct_by_data($data);
		foreach (static::$localisation_fields as $f=>$alias)
			if (isset($data[$f]) && is_array($data[$f]))
				$this->localisation_data[$f] = $data[$f];
		$this->localisation_data_old = $this->localisation_data;
		return $this;
	}

	protected static function to_sort_field($field_name) {
		if (isset(static::$system_fields[$field_name]))
			return static::$table_alias.'.'.$field_name;

		if (isset(static::$field_list[$field_name]))
			return static::$table_alias.'.'.$field_name;

//		if (in_array($field_name, static::$join_field_list))
//			return true;
		if (isset(static::$join_field_list[$field_name]))
			return static::$join_field_list[$field_name];

		if (isset(static::$localisation_fields[$field_name]))
			return static::$localisation_fields[$field_name].'.str';

		$GLOBALS['exception_err'] = [
			'err'	=> 'table_db error',
			'msg'	=> 'unknown sort field: '.p($field_name, true),
		];
		throw new \Exception('custom exception');
	}

	//-- sql -----------------------------------------------------------------------------------------------------------
	protected static function get_sql_fields($options=[]) {
		$fields_sql = '';
		foreach (static::$localisation_fields as $f=>$a)
			$fields_sql .= ", {$a}.str AS $f";

		return parent::get_sql_fields($options).$fields_sql;
	}

	protected static function get_sql_from($options=[]) {
		$fields_sql = '';
		foreach (static::$localisation_fields as $f=>$a)
			$fields_sql .= "\n".
				"LEFT JOIN ".$GLOBALS['lib']->db->field_quote("#p#localisation")." AS {$a}".
				" ON {$a}.table_name=".$GLOBALS['lib']->db->data_quote(static::$table_name).
				" AND {$a}.record_id=".static::$table_alias.".id".
				" AND {$a}.lang=".$GLOBALS['lib']->db->data_quote(empty($options['lang']) ? $GLOBALS['lib']->lang->value : $options['lang']).
				" AND {$a}.field_name=".$GLOBALS['lib']->db->data_quote($f);

		return parent::get_sql_from($options).$fields_sql;
	}

//	protected static function build_sql($options=[]) {
//		if (isset($options['order']) && isset(static::$localisation_fields[$options['order']]))
//			$options['order'] = static::$localisation_fields[$options['order']].'.str';
//		return parent::build_sql($options);
//	}

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		foreach (static::$localisation_fields as $f=>$a) {
			if (!empty($filters[$f])) {
//				$res[$f] = ['f'=>$a.'.str', 'o'=>'=', 'v'=>$filters[$f]];
				$select = "SELECT ".localisation_db::$table_alias.".record_id "
					.localisation_db::get_sql_from()
					." WHERE TRUE".localisation_db::filters_to_sql(localisation_db::prepare_filters([
						'table_name'	=>static::$table_name,
						'field_name'	=> $f,
						'str'			=> $filters[$f]
					]));
				$res[$f] = ['f'=>"t.id", 'o'=>'IN_SELECT', 'v'=>$select];
			}
			if (!empty($filters[$f.'_like'])) {
//				$res[$f.'_like'] = ['f'=>$a.'.str', 'o'=>'like', 'v'=>$filters[$f.'_like']];
				$select = "SELECT ".localisation_db::$table_alias.".record_id "
					.localisation_db::get_sql_from()
					." WHERE TRUE".localisation_db::filters_to_sql(localisation_db::prepare_filters([
						'table_name'	=>static::$table_name,
						'field_name'	=> $f,
						'str_like'		=> $filters[$f.'_like']
					]));
				$res[$f.'_like'] = ['f'=>"t.id", 'o'=>'IN_SELECT', 'v'=>$select];
			}
		}
		return $res;
	}

	function get_localisation() {
		if (empty($this->localisation_data)) {
			$list = localisation_db::get_list(['filters'=>[
				'table_name'	=> static::$table_name,
				'record_id'		=> $this->id ? $this->id : -1,
			]]);

			foreach ($list as $r){
				if (!isset($this->localisation_data[$r['field_name']]))
					$this->localisation_data[$r['field_name']] = [];
				$this->localisation_data[$r['field_name']][$r['lang']] = $r['str'];
			}
			$this->localisation_data_old = $this->localisation_data;
		}
		return $this->localisation_data;
	}

	function __get($field) {
		if (isset(static::$localisation_fields[$field]))
			return $this->get_field($field);
		return static::get_field($field);
	}
	function __set($field, $value) {
		$data = [$field => $value];
		$this->set_data($data);
	}
	function __isset($field) {
		if (isset(static::$localisation_fields[$field]))
			return isset($this->localisation_data[$field]);
		return parent::__isset($field);
	}
	function __unset($field) {
		if (isset(static::$localisation_fields[$field])) {
			unset($this->localisation_data[$field]);
		} else {
			parent::__unset($field);
		}
	}

	public function get_field($field) {
		if (isset(static::$localisation_fields[$field])) {
			if (empty($this->localisation_data))
				$this->get_localisation();
			return isset($this->localisation_data[$field][$GLOBALS['lib']->lang->value]) ? $this->localisation_data[$field][$GLOBALS['lib']->lang->value] : null;
		}
		return parent::get_field($field);
	}

	function get_name_str() {
		return $this->record_get_name($this->get_data());
	}
	static function record_get_name($record) { // возвращает название записи
		return "[{$record['id']}] ".(
			isset(static::$localisation_fields[static::$record_name_field]) // если поле локализованное
			? (isset($record[static::$record_name_field])
				? (
					is_array($record[static::$record_name_field]) // если значение поля - массив со значениями каждого языка
					? (isset($record[static::$record_name_field][$GLOBALS['lib']->lang->value]) ? $record[static::$record_name_field][$GLOBALS['lib']->lang->value] : '')
					: $record[static::$record_name_field])
			: '')
			: $record[static::$record_name_field]); // если поле нелокализованное
	}

	function get_data($options=[]) {
		return array_merge(parent::get_data($options), $this->get_localisation());
	}
	function set_data($data) {
		foreach (static::$localisation_fields as $f=>$v)
			if (array_key_exists($f, $data)) {
				if (is_array($data[$f])) {
					foreach ($data[$f] as $lang=>$str)
						$data[$f][$lang] = mb_strcut(mb_convert_encoding(strval($str), 'UTF-8'), 0, 512, 'UTF-8');
					$this->localisation_data[$f] = $data[$f];
				} else {
					if (!isset($this->localisation_data[$f]))
						$this->localisation_data[$f] = [];
					$this->localisation_data[$f][$GLOBALS['lib']->lang->value] = mb_strcut(mb_convert_encoding(strval($data[$f]), 'UTF-8'), 0, 512, 'UTF-8');
				}
				unset($data[$f]);
			}
		parent::set_data($data);
	}

	function save($save_data=[], $options=[]) {
		parent::save($save_data, array_merge($options, ['dont_prepare_changes'=>true]));

		$log = [];
		foreach ($this->localisation_data as $f=>$v)
			foreach ($v as $lang=>$str) {
				if (empty($this->localisation_data_old[$f][$lang]) || $this->localisation_data_old[$f][$lang]!=$str) {
					\localisation_db::insert_or_update([
						'table_name'	=> static::$table_name,
						'record_id'		=> $this->id,
						'lang'			=> $lang,
						'field_name'	=> $f,
						'str'			=> $str,
					]);
					$log[$f][$lang] = $str;
				}
			}

		if (!empty($log)) {
			foreach($log as $f=>$r)
				$log[$f] = json_encode($r, JSON_FORCE_OBJECT);
			if (static::$log_changes)
				(new change_log_db)->save([
					'change_type'	=> 2,
					'model'			=> get_called_class(),
					'record_id'		=> $this->id,
					'record_data'	=> $log,
				]);
			}

		$this->prepare_changes();
		return true;
	}

	protected function prepare_changes(){
		parent::prepare_changes();
		$this->localisation_data_old = $this->localisation_data;
	}


	static function create_table($options = []) {
		localisation_db::create_table($options);
		return parent::create_table($options);
	}
}
