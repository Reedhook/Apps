<?php
class session_db extends \table_db{
	protected static $table_name = 'session';
//	protected static $table_alias = 's';
	protected static $log_changes = false;

	protected static $system_fields = ['id' => ['type'=>'tsr']];
	protected static $field_list = [
		'created'	=> ['type'=>'datetime'],
		'updated'	=> ['type'=>'datetime'],
		'content'	=> ['type'=>'text', 'html'=>true],
		'user_ip'	=> ['type'=>'str'],
	];
//	protected static $field_html_list = ['content'];

	protected static $columns = [
		'id'		=> ['sorted'=>true,		'className'=>'w300'],
		'created'	=> ['sorted'=>true,		'className'=>'w150 a-right', 'js_formatter'=>'td_formatter_str'],
		'updated'	=> ['sorted'=>true,		'className'=>'w150 a-right', 'js_formatter'=>'td_formatter_str'],
		'duration'	=> ['className'=>'w150 a-right'],
		'user_ip'	=> ['className'=>'w120', 'sorted'=>true],
		'user'		=> ['js_formatter'=>'td_formatter_ellipsis'],
		'size'		=> ['className'=>'w50', 'className'=>'w100 a-right'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];

	protected static $filters = [
		'default'	=> [
			'id'		=> ['type'=>'int'],
			'empty'		=> ['type'=>'bool'],
		],
	];

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'updated', 'dir'=>'desc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];

	protected static function prepare_filters($filters) {
		$res = parent::prepare_filters($filters);

		if (!empty($filters['empty']))
			$res['empty'] = ['f'=>'#a#updated-#a#created', 'o'=>'=', 'v'=>'00:00:00'];

		return $res;
	}

	static function get_ip() {
		if (!empty($_SERVER['HTTP_CLIENT_IP'])) {//ip from share internet
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {//ip pass from proxy
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		} else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		return $ip;
	}

	function save($save_data=[], $options=[]) {
		$now = time();
		if ($this->set_id_fl)
			$save_data['created'] = $now;
		$save_data['updated'] = $now;
		$save_data['user_ip'] = static::get_ip();

		$this->set_data($save_data);

		$data = [];
		foreach(static::$field_list as $f=>$i)
			if (isset($this->data[$f]) && (!isset($this->data_old[$f]) || $this->data_old[$f]!==$this->data[$f]))
				$data[$f] = $this->data[$f];

		if (count($data)==0)
			return;

		$insert = $this->set_id_fl;

		if($this->set_id_fl) {
			$data['id'] = $this->data['id'];
			$this->set_id_fl = false;
		}
		if ($insert) {
			$sql = "INSERT INTO ".$GLOBALS['lib']->db->field_quote('#p#'.static::$table_name).
				" (".implode(', ', array_map([$GLOBALS['lib']->db, 'field_quote'], array_keys($data))).') '.
				"VALUES (".implode(', ', array_map([$GLOBALS['lib']->db, 'data_quote'], $data)).")";
			$GLOBALS['lib']->db->query($sql);
		} else {
			$field_values = [];
			foreach($data as $f=>$v)
				$field_values[] = $GLOBALS['lib']->db->field_quote($f)."=".$GLOBALS['lib']->db->data_quote($v);

			$sql = "UPDATE ".$GLOBALS['lib']->db->field_quote('#p#'.static::$table_name).
				" SET ".implode(', ', $field_values).
				" WHERE ".$GLOBALS['lib']->db->field_quote('id').'='.$GLOBALS['lib']->db->data_quote($this->data['id']);
			$GLOBALS['lib']->db->query($sql);
		}

		$this->prepare_changes();
	}

	static function post_process(&$list, $options=[]) {
		$user_id_list = [];
		foreach ($list as $k=>$r) {
			$list[$k]['size']			= strlen($r['content']);
			$list[$k]['created_str']	= $GLOBALS['lib']->date_time->to_format($r['created'], true);
			$list[$k]['updated_str']	= $GLOBALS['lib']->date_time->to_format($r['updated'], true);
			$list[$k]['duration']		= $GLOBALS['lib']->date_time->sec_to_sql_time($GLOBALS['lib']->date_time->to_stamp($r['updated']) - $GLOBALS['lib']->date_time->to_stamp($r['created']));
			if ($r['id']===$GLOBALS['lib']->session->get_session_data()['id'])
				$list[$k]['green'] = true;

			if (
				preg_match('/user_id\|s:\d+:\"(.+?)\";/isu', $r['content'], $matches) ||
				preg_match('/user_id\|i:(\d+?);/isu', $r['content'], $matches)
			);
			$user_id_list[] = $list[$k]['user_id'] = empty($matches[1]) ? null : intval($matches[1]);

			unset($list[$k]['content']);
		}

		$user_list = count($user_id_list)>0 ? \user\user_db::get_list(['filters'=>['id'=>$user_id_list], 'key'=>'id']) : [];
		foreach ($list as $k=>$r) {
			$list[$k]['user'] = empty($user_list[$r['user_id']]) ? '' : \user\user_db::record_get_name($user_list[$r['user_id']]);
		}
	}

}