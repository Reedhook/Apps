<?php
abstract class table_db {
	public static $db = null;				// объект базы данных дочерний от lib/db.php abstract class db_
	protected static $table_name = '';		// название таблицы без префикса
	static function get_table_name() {return static::$table_name;}
	protected static $table_alias = 't';	// алиас таблицы для построения запросов

	protected static $system_fields = ['id' => ['type'=>'int']];	// системные поля базы данных (недоступные для редактирования)
	static function get_system_fields() {return static::$system_fields;}

	protected static $field_list = [		// список полей базы данных с описанием, кроме системных (static::$system_fields)
//		field_name: {type: 'int|float|str|text|bool|date|datetime|time|enum|json'},
//		user_id: {type: 'int', ref:'\\user\\user_db', js_call:'user_list_show', validator: 'int_positive'},
	];
	static function get_field_list() {return static::$field_list;}

	protected static $join_field_list = [// поля из join таблиц, для сортировки, фильтрации
//		'some_field_name'=>'table_alias.real_field_name',...
	];

	protected static $enum = [];			// описание перечисляемых полей
	static function get_enum($options=[]) {return static::$enum;}

	protected static $json_map = [];		// описание json полей
	static function get_json_map() {return static::$json_map;}
	static function set_json_map($json_map) {static::$json_map=$json_map;}

	protected static $log_changes = true;	// сохранять все изменения в change_log_db
	static function set_log_changes($value) {static::$log_changes = $value;}

	protected static $columns = [			// описание колонок при выводе списка
		'id'		=> ['sorted'=>true,		'className'=>'w50 a-right'],
		'functions'	=> ['className'=>'w0', 'js_formatter'=>'td_formatter_icons', 'title'=>''],
	];
	static function get_columns() {return static::$columns;}

	protected static $filters = [			// фильтры для автоматического построения формы фильтров
		'default' => [
			'id'	=> ['type'=>'int'],
		]
	];
	static function get_filters($type='default') {return static::$filters[$type];}
	static function get_filters_ref_name($filters_data) { // подготавливает name для фильтров ref / hidden_ref
		$filters_ref_name = [];
		foreach (static::get_filters() as $f=>$r)
			if (!empty($filters_data[$f]))
				if (!empty($r['ref'])) {
					$ref_model = $r['ref'];
					$filters_ref_name[$f] = (in_array('_localisation_db', class_parents($ref_model))) ?
						(new $ref_model($filters_data[$f], ['empty_if_not_exists'=>true]))->get_name_str() :
						$ref_model::record_get_name($ref_model::get_list(['filters'=>['id'=>$filters_data[$f], 'constructor'=>true]])[0]);
				} elseif ($r['type']==='hidden' && isset(static::$field_list[$f]['ref'])) {
					$ref_model = static::$field_list[$f]['ref'];
					$filters_ref_name[$f] = (new $ref_model($filters_data[$f], ['empty_if_not_exists'=>true]))->get_name_str();
				}

		return $filters_ref_name;
	}

	//-- sql -----------------------------------------------------------------------------------------------------------
	protected static function get_sql_fields($options=[]) {// подготавливает SELECT часть из SQL
		return static::$table_alias.".*";
	}
	protected static function get_sql_select($options=[]) {// подготавливает SELECT часть из SQL для подсчета количества записей
		return "SELECT ".
		(static::$db->db_type==='mysqli'		? 'SQL_CALC_FOUND_ROWS '.static::get_sql_fields($options) : '').
		(static::$db->db_type==='pg'			? (!empty($options['count_only']) ? "COUNT(*) AS cnt" : static::get_sql_fields($options)) : '').
		(static::$db->db_type==='clickhouse'	? (!empty($options['count_only']) ? "COUNT(*) AS cnt" : static::get_sql_fields($options)) : '');
	}
	protected static function get_sql_from($options=[]) {// подготавливает FROM часть из SQL
		return "FROM ".static::$db->field_quote("#p#".static::$table_name)." AS ".static::$table_alias;
	}
	protected static function get_order_sql($options=[]) {
		if (empty($options['order']))
			$options['order'] = static::$pagination['order'];
		if (empty($options['dir']))
			$options['dir'] = static::$pagination['dir'];

		$order = "\nORDER BY ";

		$db_type_rnd = [
			'pg'	=> 'RANDOM()',
			'mysqli'=> 'RAND()',
		];
		if ($options['order']==='rnd')
			return $order . $db_type_rnd[static::$db->db_type];


		if (is_array($options['order'])) {
			foreach ($options['order'] as $k=>$f) {
				if ($f==='rnd') {
					$order .= ($k > 0 ? ', ' : '') . $db_type_rnd[static::$db->db_type];
					continue;
				}
				$f = static::to_sort_field($f);
				$dir = empty($options['dir']) ? 'ASC' : (is_array($options['dir']) ? $options['dir'][$k] : $options['dir']);
				$order .= ($k > 0 ? ', ' : '') . static::$db->field_quote($f) .' '. (strtoupper($dir) === 'DESC' ? ' DESC' : ' ASC');
			}
		} else {
			$f = static::to_sort_field($options['order']);
			$order .= static::$db->field_quote($f).
				(!empty($options['dir']) && strtoupper($options['dir'])=='DESC' ? ' DESC' : ' ASC');
		}
		return $order;
	}
	protected static function build_sql($options=[]) {
		// сначала готовим фильтры, потому что там может меняться таблица (в таблицах статистики, например)
		$where = "\nWHERE TRUE".static::filters_to_sql(static::prepare_filters(empty($options['filters']) ? [] : $options['filters']));
		$select_from = static::get_sql_select($options)."\n".
			static::get_sql_from($options);

		$group = empty($options['group']) ? '' : "\nGROUP BY ".static::to_sort_field($options['group']);

		$order = static::get_order_sql($options);

		$limit = "";
		if(!empty($options['limit']) && $options['limit']!='all' && $options['limit']>0)
			$limit = "\nLIMIT ".((int)$options['limit']);
		if(!empty($options['offset']))
			$limit .= "\nOFFSET ".((int)$options['offset']);

		return $select_from.$where.$group.(empty($options['count_only']) ? $order.$limit : '');
	}

	protected static function filters_to_sql($filters, $glue="AND") {
		$db = &static::$db;
		$sql = '';
		// в postgre для поиска без учета регистра, приходится использовать ILIKE, в mysql = ищет без учета регистра
		$db_type_op = [
			'pg'		=> ['LIKE'=>'ILIKE',	'NOT LIKE'=>'NOT ILIKE',	'CASE_INSENSITIVE'=>'ILIKE'],
			'mysqli'	=> ['LIKE'=>'LIKE',		'NOT LIKE'=>'NOT LIKE',		'CASE_INSENSITIVE'=>'='],
			'clickhouse'=> ['LIKE'=>'LIKE',		'NOT LIKE'=>'NOT LIKE',		'CASE_INSENSITIVE'=>'='],
		];
		foreach($filters as $i) {
			if (empty($i['o']))
				continue;
			$i['o'] = strtoupper($i['o']);
			if (isset($i['f'])) { // not set for options = OR|AND
				$f = str_replace(['#a#', ' '], [static::$table_alias.'.', ''], strtolower($i['f']));
				$f = preg_split('/([+-])/', $f, -1, PREG_SPLIT_DELIM_CAPTURE); // допускается несколько полей таблицы в параметре 'f', разделенные + или -. например: '#a#updated - #a#created'
				$l = count($f);
				if ($l===1) {
					$i['f'] = static::$db->field_quote($f[0]);
				} else {
					$j = 0;
					$i['f'] = '';
					while($j<$l) {
						$i['f'] .= static::$db->field_quote($f[$j++]);
						if ($j<$l)
							$i['f'] .= $f[$j++];
					}
				}
			}

			if (in_array($i['o'], ['=', '>', '<', '>=', '<=', '<>', '?'])) {
				$sql .= " {$glue} {$i['f']} {$i['o']} " . $db->data_quote($i['v']);
			} elseif (in_array($i['o'], ['LIKE', 'NOT LIKE'])) {
				$sql .= " {$glue} {$i['f']} ".$db_type_op[static::$db->db_type][$i['o']].' '.$db->data_quote('%'.$i['v'].'%');
			} elseif ($i['o']==='CASE_INSENSITIVE') {
				$sql .= " {$glue} {$i['f']} ".$db_type_op[static::$db->db_type][$i['o']].' '.$db->data_quote($i['v']);
			} elseif (in_array($i['o'], ['IN', 'NOT IN'])) {
				$sql .= " {$glue} {$i['f']} {$i['o']} (".implode(', ', array_map([$db, 'data_quote'], $i['v'])).')';
			} elseif (in_array($i['o'], ['IS NULL', 'IS NOT NULL'])) {
				$sql .= " {$glue} {$i['f']} {$i['o']}";
			} elseif ($i['o']==='MONTH') {
				$sql .= " {$glue} extract(month from {$i['f']}) = ".$db->data_quote($i['v']);
			} elseif ($i['o']==='IN_SELECT') {
				$sql .= " {$glue} {$i['f']} IN (".$i['v'].')';
			} elseif ($i['o']==='NOT_IN_SELECT') {
				$sql .= " {$glue} {$i['f']} NOT IN (".$i['v'].')';
			} elseif (in_array($i['o'], ['OR', 'AND'])) {
				$sql .= " {$glue} (".($i['o']=='OR'?'FALSE':'TRUE').static::filters_to_sql($i['v'], $i['o']).')';
			} elseif (in_array($i['o'], ['?&', '?|'])) { // поиск ключа в JSONB
				$sql .= " {$glue} {$i['f']} {$i['o']} array[".$db->data_quote($i['v'])."]";
			} elseif (in_array($i['o'], ['@>'])) { // поиск ключа в JSONB
				$f = $db->field_quote($i['v'][0]);
				$v = is_numeric($i['v'][1]) ? $i['v'][1] : '"'.$db->escape_string($i['v'][1]).'"';
				$sql .= " {$glue} {$i['f']} {$i['o']} '{{$f}:{$v}}'";
			}
		}

		return $sql;
	}

	//------------------------------------------------------------------------------------------------------------------
	// модификация фильтров: [id: 8] -> [field: 'id', operator: '=', value: 8] (подготовка для функции filters_to_sql)
	protected static function prepare_filters($filters) {
		$res = [];
		foreach ([static::$system_fields, static::$field_list] as $field_list)
			foreach ($field_list as $f=>$r) {
				//-- оригинальное название поля ------------------------------------------------------------------------
				if ($r['type']==='bool') {
					if (isset($filters[$f]) && $filters[$f] !== 'all')
						$res[$f] = ['f' => "#a#{$f}", 'o' => '=', 'v' => to_bool($filters[$f])];
				} elseif ($r['type']==='enum') {
					if (!empty($filters[$f]) && $filters[$f] !== 'all')
						$res[$f] = ['f'=>"#a#{$f}", 'o' => is_array($filters[$f]) ? 'IN' : '=', 'v' => $filters[$f]];
				} elseif ($r['type']==='str' && !empty($r['case_insensitive'])) {
					if (!empty($filters[$f]))
						$res[$f] = ['f'=>"#a#{$f}", 'o'=>'case_insensitive', 'v'=>$filters[$f]];
				} elseif ($r['type']==='int') {
					if (isset($filters[$f])) {
						if (is_string($filters[$f]))
							foreach ([',', ';'] as $needle)
								if (strpos($filters[$f], $needle)!==false) {
									$filters[$f] = array_map('trim', explode($needle, $filters[$f]));
									break;
								}
						if (is_array($filters[$f])) {
							if (count($filters[$f])>0)
								$res[$f] = ['f'=>"#a#{$f}", 'o'=>'IN', 'v'=>array_map('intval', $filters[$f])];
						} elseif (is_int($filters[$f]) || is_string($filters[$f]) && strlen($filters[$f])>0) {
							$res[$f] = ['f'=>"#a#{$f}", 'o'=>'=', 'v'=>intval($filters[$f])];
						}
					}
				} elseif (in_array($r['type'], ['date', 'datetime', 'time'])) {
					if (!empty($filters[$f]))
						$res[$f] = ['f'=>"#a#{$f}", 'o'=>'=', 'v'=>static::prepare_field_set($f, $filters[$f])];
				} else if (!empty($filters[$f])) {
					$res[$f] = ['f'=>"#a#{$f}", 'o'=>is_array($filters[$f])?'IN':'=', 'v'=>$filters[$f]];
				}

				//-- модифицированное название поля --------------------------------------------------------------------
				if (!empty($filters[$f.'_like'])) {
					if (in_array($r['type'], ['str', 'text']))
						$res[$f.'_like'] = ['f'=>"#a#{$f}", 'o'=>'LIKE', 'v'=>$filters[$f.'_like']];
					if ($r['type']==='int')
						$res[$f.'_like'] = ['f'=>"#a#{$f}::VARCHAR", 'o'=>'LIKE', 'v'=>$filters[$f.'_like']];
				}

				if (!empty($filters[$f.'_not'])) {
					if (!is_array($filters[$f.'_not']))
						$filters[$f.'_not'] =  explode(',', $filters[$f.'_not']);
					$res[$f.'_not'] = ['o'=>'or', 'v'=>[
						count($filters[$f.'_not'])===1 ?
						['f'=>"#a#{$f}", 'o'=>'<>', 'v'=>static::prepare_field_set($f, $filters[$f.'_not'][0])] :
						['f'=>"#a#{$f}", 'o'=>'NOT IN','v'=>array_map(function($v) use($f) {return static::prepare_field_set($f, $v);}, $filters[$f.'_not'])],
						['f'=>"#a#{$f}", 'o'=>'IS NULL'],
					]];
				}

				if (isset($filters[$f.'_positive']) && $filters[$f.'_positive']!=='all')
					$res[$f.'_positive'] = ['f'=>"#a#{$f}", 'o'=>to_bool($filters[$f.'_positive'])?'>':'<=', 'v'=>0];
				if (isset($filters[$f.'_negative']) && $filters[$f.'_negative']!=='all')
					$res[$f.'_negative'] = ['f'=>"#a#{$f}", 'o'=>to_bool($filters[$f.'_negative'])?'<':'>=', 'v'=>0];
				if (!empty($filters[$f.'_is_0']))
					$res[$f.'_is_0'] = ['f'=>"#a#{$f}", 'o'=>'=', 'v'=>0];
				if (isset($filters[$f.'_isnull']) && $filters[$f.'_isnull']!=='all')
					$res[$f.'_isnull'] = ['f'=>"#a#{$f}", 'o'=>to_bool($filters[$f.'_isnull']) ? 'IS NULL' : 'IS NOT NULL'];
				if (isset($filters[$f.'_isnotnull']) && $filters[$f.'_isnotnull']!=='all')
					$res[$f.'_isnotnull'] = ['f'=>"#a#{$f}", 'o'=>to_bool($filters[$f.'_isnotnull']) ? 'IS NOT NULL' : 'IS NULL'];

				if (isset($filters[$f.'_empty']) && $filters[$f.'_empty']!=='all') {
					$empty_value = static::prepare_field_set($f, '');
					if (to_bool($filters[$f.'_empty'])) {
						$res[$f.'_empty'] = is_null($empty_value)
							? ['f'=>"#a#{$f}", 'o'=>'IS NULL']
							: ['o'=>'OR', 'v'=>[
								['f'=>"#a#{$f}", 'o'=>'IS NULL'],
								['f'=>"#a#{$f}", 'o'=>'=', 'v'=>$empty_value],
							]];
					} else {
						$res[$f.'_isnotnull'] = ['f'=>"#a#{$f}", 'o'=>'IS NOT NULL'];
						if (!is_null($empty_value))
							$res[$f.'_notempty'] = ['f'=>"#a#{$f}", 'o'=>'<>', 'v'=>$empty_value];
					}
				}

				if (isset($filters[$f.'_notempty']) && $filters[$f.'_notempty']!=='all') {
					$empty_value = static::prepare_field_set($f, '');
					if (to_bool($filters[$f.'_notempty'])) {
						$res[$f.'_isnotnull'] = ['f'=>"#a#{$f}", 'o'=>'IS NOT NULL'];
						if (!is_null($empty_value))
							$res[$f.'_notempty'] = ['f'=>"#a#{$f}", 'o'=>'<>', 'v'=>$empty_value];
					} else {
						$res[$f.'_empty'] = is_null($empty_value)
							? ['f'=>"#a#{$f}", 'o'=>'IS NULL']
							: ['o'=>'OR', 'v'=>[
								['f'=>"#a#{$f}", 'o'=>'IS NULL'],
								['f'=>"#a#{$f}", 'o'=>'=', 'v'=>$empty_value],
							]];
					}
				}

				//-- диапазоны
				if (!empty($filters[$f.'_min'])) // значение записи больше или равно передаваемого значения
					$res[$f.'_min'] = ['f'=>"#a#{$f}", 'o'=>'>=', 'v'=>static::prepare_field_set($f, $filters[$f.'_min'])];
				if (!empty($filters[$f.'_max'])) //значение записи меньше или равно передаваемого значения
					$res[$f.'_max'] = ['f'=>"#a#{$f}", 'o'=>'<=', 'v'=>static::prepare_field_set($f, $filters[$f.'_max'])];
				if (!empty($filters[$f.'_min_null'])) // передаваемое значение больше или равно, чем данные записи или NULL
					$res[$f.'_min_null'] = ['o'=>'OR', 'v'=>[
						['f'=>"#a#{$f}", 'o'=>'>=', 'v'=>static::prepare_field_set($f, $filters[$f.'_min_null'])],
						['f'=>"#a#{$f}", 'o'=>'IS NULL'],
					]];
				if (!empty($filters[$f.'_max_null'])) // передаваемое значение меньше или равно, чем данные записи или NULL
					$res[$f.'_max_null'] = ['o'=>'OR', 'v'=>[
						['f'=>"#a#{$f}", 'o'=>'<=', 'v'=>static::prepare_field_set($f, $filters[$f.'_max_null'])],
						['f'=>"#a#{$f}", 'o'=>'IS NULL'],
					]];

				if (!empty($filters[$f.'_less'])) // значение записи меньше передаваемого значения
					$res[$f.'_less'] = ['f'=>"#a#{$f}", 'o'=>'<', 'v'=>static::prepare_field_set($f, $filters[$f.'_less'])];
				if (!empty($filters[$f.'_more'])) // значение записи больше передаваемого значения
					$res[$f.'_more'] = ['f'=>"#a#{$f}", 'o'=>'>', 'v'=>static::prepare_field_set($f, $filters[$f.'_more'])];
				if (!empty($filters[$f.'_less_null'])) // передаваемое значение больше, чем данные записи или NULL
					$res[$f.'_less_null'] = ['o'=>'OR', 'v'=>[
						['f'=>"#a#{$f}", 'o'=>'<', 'v'=>static::prepare_field_set($f, $filters[$f.'_less_null'])],
						['f'=>"#a#{$f}", 'o'=>'IS NULL'],
					]];
				if (!empty($filters[$f.'_more_null'])) // передаваемое значение меньше, чем данные записи или NULL
					$res[$f.'_ore_null'] = ['o'=>'OR', 'v'=>[
						['f'=>"#a#{$f}", 'o'=>'>', 'v'=>static::prepare_field_set($f, $filters[$f.'_more_null'])],
						['f'=>"#a#{$f}", 'o'=>'IS NULL'],
					]];

			}

		foreach (static::$join_field_list as $f=>$a) {
			if(!empty($filters[$f]))
				$res[$f] = ['f'=>$a, 'o'=>is_array($filters[$f])?'IN':'=', 'v'=>$filters[$f]];

			if(!empty($filters[$f.'_false']))
				$res[$f.'_false'] = ['f'=>$a, 'o'=>'=', 'v'=>false];

			if(!empty($filters[$f.'_like']))
				$res[$f.'_like'] = ['f'=>$a, 'o'=>'LIKE', 'v'=>$filters[$f.'_like']];

			if (isset($filters[$f.'_positive']) && $filters[$f.'_positive']!=='all')
				$res[$f.'_positive'] = ['f'=>$a, 'o'=>to_bool($filters[$f.'_positive'])?'>':'<=', 'v'=>0];

			if (isset($filters[$f.'_isnull']) && $filters[$f.'_isnull']!=='all')
				$res[$f.'_isnull'] = ['f'=>$a, 'o'=>to_bool($filters[$f.'_isnull']) ? 'IS NULL' : 'IS NOT NULL'];

/*			if (!empty($filters[$f.'_more_null'])) // передаваемое значение больше, чем данные записи или NULL
				$res[$f.'_more_null'] = ['o'=>'OR', 'v'=>[
					['f'=>"{$a}", 'o'=>'<=', 'v'=>$filters[$f.'_more_null']],
					['f'=>"{$a}", 'o'=>'IS NULL'],
				]];
			if (!empty($filters[$f.'_less_null'])) // передаваемое значение меньше, чем данные записи или NULL
				$res[$f.'_less_null'] = ['o'=>'OR', 'v'=>[
					['f'=>"{$a}", 'o'=>'>=', 'v'=>$filters[$f.'_less_null']],
					['f'=>"{$a}", 'o'=>'IS NULL'],
				]];
*/		}
		return $res;
	}

	// проверяет, есть ли такое поле, добавляет алиас
	protected static function to_sort_field($field_name) {
		if (isset(static::$system_fields[$field_name]))
			return static::$table_alias.'.'.$field_name;

		if (isset(static::$field_list[$field_name]))
			return static::$table_alias.'.'.$field_name;

		if (isset(static::$join_field_list[$field_name]))
			return static::$join_field_list[$field_name];

		$GLOBALS['exception_err'] = [
			'err'	=> 'table_db error',
			'msg'	=> 'unknown sort field: '.p($field_name, true),
		];
		throw new \Exception('custom exception');
	}

	static function get_list($options=[]) {
		$options['class_db'] = get_called_class();// для создания таблицы, если не существует

		$list = static::$db->query(static::build_sql($options), $options);

		if (!empty($options['get_total'])) {
			if (static::$db->db_type==='mysqli')
				$total = (int)static::$db->query('SELECT FOUND_ROWS() AS '.static::$db->field_quote('cnt'))[0]['cnt'];
			if (static::$db->db_type==='pg')
				$total = (int)static::get_list(['filters'=>$options['filters']??[], 'count_only'=>true])[0]['cnt'];
			if (static::$db->db_type==='clickhouse')
				$total = (int)static::get_list(['filters'=>$options['filters']??[], 'count_only'=>true])[0]['cnt'];
		}

		if (!empty($options['post_process']))
			static::post_process($list, $options);

		if (!empty($options['prepare_types']))
			foreach ($list as $k=>$r) {
				foreach (static::$system_fields as $f=>$o)
					$list[$k][$f] = static::prepare_field_get($r[$f], $o);
				foreach (static::$field_list as $f=>$o)
					$list[$k][$f] = static::prepare_field_get($r[$f], $o);
			}

		return empty($options['get_total']) ? $list : [$list, $total];
	}

	protected static function post_process(&$list, $options=[]) {
	}

	protected static $pagination = ['page_size'=>20, 'page_no'=>0, 'order'=>'id', 'dir'=>'asc', 'filters'=>[], 'page_size_values'=>[5,10,20,50,'all']];
	static function get_pagination() {return static::$pagination;}

	static function get_page(&$pagination_data) {
		$pagination = [];
		foreach(static::$pagination as $o=>$v)
			$pagination[$o] = !empty($pagination_data[$o]) ? $pagination_data[$o] : static::$pagination[$o];

		$pagination['page_no'] = (int)$pagination['page_no'];

		unset($pagination['filters']['constructor']);

		$list_options = [
			'post_process'=>true,
			'get_total'=>true,
		];
		if ($pagination['page_size']!=='all') {
			$list_options['limit'] = $pagination['page_size'] = (int)$pagination['page_size'];
			$list_options['offset'] = (int)($list_options['limit']*$pagination['page_no']);
		}

		list($list, $pagination['records_count']) = static::get_list(array_merge($pagination, $list_options));

		$pagination['page_count'] = $pagination['page_size']==='all' ? 1 : ceil($pagination['records_count']/$pagination['page_size']);

		return [$pagination, $list];
	}

	protected $data = [];
	protected $data_old = [];
	function __construct($id=null, $options=[]) {
		if (!empty($id)) {
			$res = static::get_list(['filters'=>['id'=>$id, 'constructor'=>true]]);
			$res_count = count($res);
			if ($res_count===0 && empty($options['empty_if_not_exists'])) {
				$GLOBALS['exception_err'] = [
					'err'	=> 'table_db error',
					'msg'	=> "there is no record with id: {$id} in ".static::$table_name,
				];
				throw new \Exception('custom exception');
			} else {
				if ($res_count>0)
					$this->construct_by_data($res[0]);
			}
		} else {
			$this->data['id'] = null;
			$this->data_old = $this->data;
		}
	}

	function construct_by_data($data) {
		foreach (static::$system_fields as $f=>$r)
			$this->data[$f] = key_exists($f, $data) ? static::prepare_field_set($f, $data[$f]) : null;

		foreach (static::$field_list as $f=>$r)
			$this->data[$f] = key_exists($f, $data) ? static::prepare_field_set($f, $data[$f]) : null;

		$this->data_old = $this->data;

		return $this;
	}

	static function update($id, $data) {
		if (!$id)
			return;
		foreach($data as $f=>$v)
			$data[$f] = static::prepare_field_set($f, $v);
		static::$db->update(static::$table_name, $data, $id);
		static::save_log($id, $data, 'update');
	}
	static function delete_by_id($id) {
		if (!$id)
			return;
		$sql = "DELETE FROM ".static::$db->field_quote('#p#'.static::$table_name).
			"WHERE ".static::$db->field_quote('id').'='.static::$db->data_quote($id);
		static::$db->query($sql);

		static::save_log($id, [], 'delete');
	}

	public function get_field($field) {
		if(isset(static::$system_fields[$field]) && isset($this->data[$field])) {
			if(static::$system_fields[$field]['type']==='int')
				return intval($this->data[$field]);
			return $this->data[$field];
		}
		if(isset(static::$field_list[$field]) && isset($this->data[$field])) {
			if(static::$field_list[$field]['type']==='int')
				return intval($this->data[$field]);
			if(static::$field_list[$field]['type']==='bool')
				return to_bool($this->data[$field]);
			if (static::$field_list[$field]['type']==='money')
				return floatval($this->data[$field]);

			if(static::$field_list[$field]['type']==='json') {
				return empty($this->data[$field]) ? [] : json_decode($this->data[$field], true);
			}
			return $this->data[$field];
		}
		return null;
	}

	function get_data($options=[]) {
		$data = [];
		foreach(static::$system_fields as $f=>$r) {
			$data[$f] = $this->get_field($f);
		}
		foreach(static::$field_list as $f=>$o)
			$data[$f] = $this->get_field($f);

		if (!empty($options['get_ref_name'])) {
			if (!function_exists('set_ref_name')) {
				function set_ref_name (&$data, $f, $o, $json_map) {
					if (isset($o['ref']) && !empty($data[$f])) {
						$list = $o['ref']::get_list(['filters'=>['id'=>$data[$f], 'constructor'=>true]]);
						if (count($list)>0) {
							$data[$f.'_str'] = $o['ref']::record_get_name($list[0]);
							if ($o['ref']==='\file_db')
								$data[$f.'_url'] = $o['ref']::get_url($list[0]);
						}
					}

					if ($o['type']==='date')
						$data[$f.'_str'] = $GLOBALS['lib']->date_time->date_to_format($data[$f]);

					if ($o['type']==='datetime')
						$data[$f.'_str'] = $GLOBALS['lib']->date_time->to_format($data[$f], true);

					if ($o['type']==='json')
						if (isset($json_map[$f]))
							foreach ($json_map[$f] as $jf=>$jo)
								set_ref_name($data[$f], $jf, $jo, $json_map);
				}
			}

			foreach (static::$field_list as $f=>$o)
				set_ref_name($data, $f, $o, static::$json_map);
		}

		return $data;
	}

	static $record_name_field = 'name'; // поле, которое выводится, как наименование записи (например, для user будет поле email)
	function get_name_str() { // возвращает название записи
		return static::record_get_name($this->data);
	}
	static function record_get_name($record) { // возвращает название записи
		return "[{$record['id']}] ".$record[static::$record_name_field];
	}

	function set_data($data) {
		foreach($data as $f=>$v)
			if (!array_key_exists($f, static::$system_fields))
				$this->data[$f] = static::prepare_field_set($f, $v);
	}

	// приведение типов, когда добавляем данные в объект
	protected static function prepare_field_set ($f, $v) {
		$field = isset(static::$field_list[$f]) ? static::$field_list[$f] : (isset(static::$system_fields[$f]) ? static::$system_fields[$f] : false);
		if ($field===false)
			throw new Exception("prepare unknown field: '{$f} for model ".get_class());
		if ($field['type']=='date') {
			return empty($v) ? null : $GLOBALS['lib']->date_time->date_to_sql($v, false);
		} elseif ($field['type']=='datetime') {
			return empty($v) ? null : $GLOBALS['lib']->date_time->to_sql($v, true/*, static::$db->db_type=='pg'*/);
		} elseif ($field['type']=='time') {
			return empty($v) ? null : (is_numeric($v) ? $GLOBALS['lib']->date_time->sec_to_sql_time($v) : $GLOBALS['lib']->date_time->to_sql_time($v));
//		} elseif ($field['type']=='stamp') {
//			return empty($v) ? 0 : $GLOBALS['lib']->date_time->to_stamp($v);
		} elseif ($field['type']=='json') {
			return empty($v) ? json_encode([], JSON_FORCE_OBJECT) : (is_array($v) ? json_encode($v, JSON_FORCE_OBJECT) : $v);
		} elseif (in_array($field['type'], ['int'])) {
			return empty($v) || $v==='null' ? (isset($field['ref']) ? null : 0) : (int)$v;
		} elseif (in_array($field['type'], ['money'])) {
			return is_float($v) ? $v : floatval($v);
		} elseif (in_array($field['type'], ['float'])) {
			return (float)$v;
		} elseif (in_array($field['type'], ['bool'])) {
			return to_bool($v);
//		} elseif (in_array(static::$field_list[$k]['type'], ['blob'])) {
//			return $v;
//		} elseif (in_array($f, static::$field_html_list)) {
//			return (string)$v;
		} else {
			if ($field['type']==='str')
				$v = mb_strcut(mb_convert_encoding(strval($v), 'UTF-8'), 0, 512, 'UTF-8');
//			return $v;
			return empty($field['html']) ? htmlspecialchars((string)$v, ENT_NOQUOTES, $GLOBALS['conf']['site']['code'], false) : $v;
		}

		$GLOBALS['exception_err'] = [
			'err'	=> 'table_db error',
			'msg'	=> 'unknown field name: '.p($f, true),
		];
		throw new \Exception('custom exception');
	}

	// приведение типов, при получении данных
	protected static function prepare_field_get ($v, $field_options) {
//		if ($field_options['type']=='date') {
//			return empty($v) ? null : $GLOBALS['lib']->date_time->to_sql($v, false);
//		} elseif ($field_options['type']=='datetime') {
//			return empty($v) ? null : $GLOBALS['lib']->date_time->to_sql($v, true/*, static::$db->db_type=='pg'*/);
//		} elseif ($field_options['type']=='time') {
//			return empty($v) ? null : $GLOBALS['lib']->date_time->to_sql_time($v);
//		} elseif ($field_options['type']=='stamp') {
//			return empty($v) ? 0 : $GLOBALS['lib']->date_time->to_stamp($v);
//		} else

		if ($field_options['type']=='json') {
			return empty($v) ? json_encode([], JSON_FORCE_OBJECT) : (is_array($v) ? $v : json_decode($v, 1) );
//		} elseif (in_array($field_options[$k]['type'], ['text', 'str', 'select', 'enum'])) {
//			return (string)$v;
		} elseif (in_array($field_options['type'], ['int'])) {
			return empty($v) ? (isset($field_options['ref']) ? null : 0) : (int)$v;
		} elseif (in_array($field_options['type'], ['float'])) {
			return (float)$v;
		} elseif (in_array($field_options['type'], ['bool'])) {
			return to_bool($v);
//		} elseif (in_array($field_options[$k]['type'], ['blob'])) {
//			return $v;
//		} elseif (in_array($f, static::$field_html_list)) {
//			return (string)$v;
//		} else {
//			if ($field_options['type']=='str')
//				$v = mb_strcut(mb_convert_encoding(strval($v), 'UTF-8'), 0, 512, 'UTF-8');
//			return $v;
//			return htmlspecialchars((string)$v, ENT_QUOTES, $GLOBALS['conf']['site']['code'], false);
		}

		return $v;
	}

	function __get($field) {
		if (!isset(static::$field_list[$field]) && !isset(static::$system_fields[$field])) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'table_db error',
				'msg'	=> 'unknown field name: '.p($field, true),
			];
			throw new \Exception('custom exception');
		}

		return $this->get_field($field);
	}
	function __set($field, $value) {
		$data = [$field => $value];
		$this->set_data($data);
	}
	function __isset($field) {
		return isset($this->data[$field]);
	}
	function __unset($field) {
		unset($this->data[$field]);
	}

	protected $set_id_fl = false; // флаг того, что для новой записи указан ID
	function set_id($id) {
		if (empty($this->data['id'])) {
			$this->data['id'] = $id;
			$this->set_id_fl = true;
		}
	}

	// возвращает true, если изменения сохранены
	function save($save_data=[], $options=[]) {
		$this->set_data($save_data);

		$data = [];// собираем только те поля, которые были изменены
		foreach(static::$field_list as $f=>$i)
			if (array_key_exists($f, $this->data)
				&& (isset($this->data[$f]) || isset($this->data_old[$f]))
//				&& (!array_key_exists($f, $this->data_old) || $this->data_old[$f]!==$this->data[$f])
				&& (!array_key_exists($f, $this->data_old) || static::field_comp($i['type'], $this->data[$f], $this->data_old[$f])!==0)
			)
				$data[$f] = $this->data[$f];

		$options['class_db'] = get_called_class();// для создания таблицы, если не существует

		if ($this->set_id_fl) { // вставляем новую запись с указанным ID
			$insert = true;
			$data['id'] = $this->data['id'];
			$options['set_id'] = true;
		} else {
			if (count($data)===0 && $this->id>0)
				return false;

			$insert = empty($this->data['id']);
		}

		if ($insert) {
			static::$db->insert(static::$table_name, $data, $options);
		} else {
			static::$db->update(static::$table_name, $data, $this->data['id'], $options);
		}

		$this->data = array_merge($this->data, $data);
		static::save_log($this->id, $insert ? $this->data : $data, $insert ? 'insert' : 'update');

		if (empty($options['dont_prepare_changes']))
			$this->prepare_changes();

		return true;
	}

	protected static function save_log($id, $data, $change_type) {
		$change_types = ['insert'=>1, 'update'=>2, 'delete'=>3];
		if (static::$log_changes)
			(new change_log_db)->save([
				'change_type'	=> $change_types[$change_type],
//				'table_name'	=> static::$table_name,
				'model'			=> get_called_class(),
				'record_id'		=> $id,
				'record_data'	=> $data,
			]);
	}

	protected static function field_comp ($field_type, $v1, $v2) {// функция для сравнения значений по типу поля, в том числе сравнивает json
		if ($field_type==='json') {
			if (!is_array($v1))
				$v1 = is_string($v1) && strlen($v1)>1 ? json_decode($v1, true) : [];
			if (!is_array($v2))
				$v2 = is_string($v2) && strlen($v2)>1 ? json_decode($v2, true) : [];

			foreach ($v1 as $k=>$v) {
				if (!isset($v2[$k]))
					return -1;
				if (is_array($v)) {
					$c = static::field_comp($field_type, $v1[$k], $v2[$k]);
					if ($c!==0)
						return $c;
				} else {
					if ($v1[$k] != $v2[$k])
						return $v1[$k]>$v2[$k] ? 1 : -1;
				}

				unset($v2[$k]);
			}
			return count($v2)>0 ? 1 : 0;
		}
		return $v1===$v2 ? 0 : ($v1>$v2 ? 1 : -1);
	}

	protected function prepare_changes(){
		$this->data_old = $this->data;
	}

	function delete () {
		if (!$this->id)
			return;
		$sql = "DELETE FROM ".static::$db->field_quote('#p#'.static::$table_name).
			"WHERE ".static::$db->field_quote('id').'='.static::$db->data_quote($this->data['id']);
		static::$db->query($sql);

		static::save_log($this->id, $this->data, 'delete');

		$this->data = [];
	}

	static function delete_group($id_list, $data_list=false) { // групповое удаление
		if (empty($id_list))
			return;

		static::delete_group_log($id_list, $data_list);

		static::$db->query(
			"DELETE FROM ".static::$db->field_quote('#p#'.static::$table_name)."\n".
			"WHERE ".static::$db->field_quote('id').' IN ('.implode(',', $id_list).')'
		);
	}
	static function delete_group_log($id_list, $data_list=false) { // логирование группового удаления
		if (empty($id_list))
			return;
		if (static::$log_changes) {
			$log_list = [];
			$event_time = time();
			$model = get_called_class();
			$log = function ($r) use(&$log_list, $event_time, $model) {
				$log_list[] = [
					'event_time'	=> $event_time,
					'user_id'		=> $GLOBALS['user']['id'],
					'change_type'	=> 3, // delete
					'model'			=> $model,
					'record_id'		=> $r['id'],
					'record_data'	=> json_encode($r, JSON_FORCE_OBJECT),
				];
			};

			if ($data_list) {
				foreach ($data_list as $r)
					$log($r);
			} else {
				static::get_list(['filters'=>['id'=>$id_list, 'constructor'=>true], 'no_answer'=>true, 'row_function'=>$log]);
			}
			change_log_db::insert_list($log_list);
		}
	}

	public function validate(&$data) {
		$err = [];

		foreach(static::$field_list as $f=>$r) {
			if ($r['type']==='enum' && isset($data[$f]) && !isset(static::$enum[$f][$data[$f]]))
				unset($data[$f]);

			if (!empty($r['validator'])) {
				if (!isset($data[$f]))
					$data[$f] = '';
				if (!$GLOBALS['lib']->validator->check($data[$f], $r['validator']))
					$err[$f] = isset($r['validator_msg']) ? lang($r['validator_msg']) : 1;
			}
		}

		return $err;
	}

	public function access($action) {
		if (in_array($GLOBALS['user']['role'], ['cron', 'root', 'admin']))
			return true;
		return false;
	}

	public static function shorten_str($str, $l=100) {// обрезает строку и добавляет три точки
		$s = strip_tags($str);
		return mb_strlen($s, $GLOBALS['conf']['site']['code'])>$l
			? mb_substr($s, 0, $l-3, $GLOBALS['conf']['site']['code']).'...'
			: $s;
	}

	public static function get_or_create($data) {// ищет сущность по данным или создает новый экземпляр
		$list = static::get_list(['filters'=>$data]);
		$obj = new static();
		if(count($list)>0) {
			$obj->data = $list[0];
			$obj->data_old = $obj->data;
		} else {
			$obj->data = $data;
			$obj->save();
		}
		return $obj;
	}

	public static function insert_list($data_list, $options=[]) { // мульти-вставка данных
		if (count($data_list)===0)
			return;
		$options['class_db'] = get_called_class();// для создания таблицы, если не существует
		$options['no_answer'] = true;

		$sql = "INSERT INTO ".static::$db->field_quote("#p#".static::$table_name)."\n(".
		implode(', ', array_map([static::$db, 'field_quote'], array_keys(static::$field_list))).")\n VALUES\n";

		foreach ($data_list as $data_item) {
			$sql_fields = [];
			foreach(static::$field_list as $f=>$i)
				$sql_fields[] = (isset($data_item[$f]) ?  static::$db->data_quote(static::prepare_field_set($f, $data_item[$f])) : 'null');
			$sql .= '('.implode(', ', $sql_fields)."),\n";
		}

		return static::$db->query(
			substr($sql, 0, -2).(static::$db->db_type==='clickhouse'?'':"\nON CONFLICT DO NOTHING"),
			$options
		);
	}

	public static function create_table($options=[]) { // создать таблицу
		if (static::$db->table_exists(static::$table_name))
			return false;

		foreach (static::$field_list as $r)
			if (!empty($r['ref']) && empty($r['skip_create']))
				if ($r['ref']::get_table_name() !== static::$table_name)
					$r['ref']::create_table($options);

		return static::$db->create_table(static::$table_name, static::$field_list, $options);
	}

	public static function set_sequence_number($number) {
		static::$db->set_sequence_number(static::$table_name, $number);
	}
	// запускает языковой файл lang.php для текущего модуля
//	public function add_lang() {
//		$class_info = new ReflectionClass($this);
//		$lang_file = dirname($class_info->getFileName()).'/../lang.php';
//		if (is_file($lang_file))
//			require_once $lang_file;
//	}

	protected static function create_hash($code='') {
		do {
			$hash = md5((function_exists('random_int') ? random_int(0, 999) : rand(0, 999)).time().$code);
			$list = static::get_list(['filters'=>['hash'=>$hash]]);
		} while (count($list)>0);
		return $hash;
	}

}
table_db::$db = $GLOBALS['lib']->db;
