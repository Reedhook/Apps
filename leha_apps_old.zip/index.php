<?php
chdir(__DIR__);
error_reporting(E_ALL);
require_once 'conf/config.php';
date_default_timezone_set($GLOBALS['conf']['site']['timezone']);

$GLOBALS['is_console'] = PHP_SAPI === 'cli' || (!isset($_SERVER['DOCUMENT_ROOT']) && !isset($_SERVER['REQUEST_URI']));
$GLOBALS['no_session'] = false;
if ($GLOBALS['is_console']) {
	$GLOBALS['no_session'] = true;
	$_REQUEST['request_line'] = array_slice($argv, 1); // remove index.php from $argv

	if (isset($_REQUEST['request_line'][0]) && empty($_REQUEST['request_line'][0]))
		array_shift($_REQUEST['request_line']);
} else {
	// redirect to http/https
	$conf_https = !empty($GLOBALS['conf']['site']['https']);
	$request_https = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === "on") || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');
	if ($conf_https !== $request_https) {
		header('HTTP/1.1 301 Moved Permanently');
		header('Location: http' . ($conf_https ? 's' : '') . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
		exit;
	}

	// json to $_REQUEST
	$content_type = isset($_SERVER) && !empty($_SERVER['CONTENT_TYPE']) ? $_SERVER['CONTENT_TYPE'] : false;
	if ($content_type) {
		$content_type = array_map('trim', explode(';', $content_type))[0];

		if ($content_type === 'application/json') {
			$GLOBALS['REQUEST_JSON'] = true;
			$request_payload_data = json_decode(file_get_contents('php://input'), true);
			if (!empty($request_payload_data))
				$_REQUEST = array_merge($_REQUEST, $request_payload_data);
		}
	}

	// request_line prepare
	if (empty($_REQUEST['request_line'])) {
		$_REQUEST['request_line'] = [];
	} else {
		if (strpos($_REQUEST['request_line'], '?')!==false) {
			list($_REQUEST['request_line'], $get_line) = explode('?', $_REQUEST['request_line'], 2);
			$_REQUEST = array_merge($_REQUEST, parse_str($get_line));
		}
		$_REQUEST['request_line'] = !empty($_REQUEST['request_line']) ? explode('/', $_REQUEST['request_line']) : []; // module/controller[/method[/param1/param2/...]]
	}

	// для кроссдоменных запросов
	if (!empty($GLOBALS['conf']['site']['access_allow'])) {
		$origin = empty($_SERVER['HTTP_ORIGIN']) ? '' : $_SERVER['HTTP_ORIGIN'];
		if (in_array($origin, $GLOBALS['conf']['site']['access_allow'])) {
			header('Access-Control-Allow-Origin: '.$origin);
			header('Access-Control-Allow-Credentials: true');
			header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
			header('Access-Control-Allow-Headers: Content-Type');
			header('Access-Control-Max-Age: 1000');
		}
	}

	if (file_exists('log/ip_block.txt')) {
		if (in_array($_SERVER['HTTP_X_REAL_IP'] ?? $_SERVER['HTTP_HOST'] ?? '', array_map('trim', file('log/ip_block.txt')))) {
			echo "I'm watching you.";
			exit();
		}
	}
}


require_once 'modules/core/controller_manager.php';
try {
	controller_manager::start();
	session_write_close();
} catch (Exception $e) {
	exception_event($e);
}
