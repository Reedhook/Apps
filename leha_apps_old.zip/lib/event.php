<?php
namespace lib;
class event {
	protected $callback = [];

	function add_event_listener($event_name, $fun) {
		if (!isset($this->callback[$event_name]))
			$this->callback[$event_name] = [];
		if (is_string($fun))
			if (in_array($fun, $this->callback[$event_name]))
				return;
		$this->callback[$event_name][] = $fun;
	}

	function dispatch_event($event_name, array $args=null) {
		if (isset($this->callback[$event_name]))
			foreach ($this->callback[$event_name] as $func)
				call_user_func($func, $args);
	}
}
