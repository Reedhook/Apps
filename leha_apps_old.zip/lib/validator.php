<?php
namespace lib;
class validator {
	function check (&$value, $type) {
		if(!method_exists($this, $type)){
			$GLOBALS['exception_err'] = [
				'err'	=> 'validator error',
				'msg'	=> 'unknown validation type: '.print_r($type, true),
			];
			throw new \Exception('custom exception');
		}

		return $this->$type($value);
	}

	//-- email ---------------------------------------------------------------------------------------------------------
	function email (&$data) {
		return preg_match('/^[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)*\.[a-zA-Z]{2,6}$/', $data);
	}
	function email_empty (&$data) {
		return empty($data) || $this->email($data);
	}

	//-- phone ---------------------------------------------------------------------------------------------------------
	function phone (&$data) {
		$data = $GLOBALS['lib']->phone->to_sql($data);
		return $GLOBALS['lib']->phone->is_valid($data);
	}
	function phone_empty (&$data) {
		return empty($data) || $this->phone($data);
	}

	//-- str -----------------------------------------------------------------------------------------------------------
	function str (&$data) {
		return is_string($data) && !empty($data);
	}
	function str_empty (&$data) {
		return empty($data) || is_string($data);
	}

	//-- int -----------------------------------------------------------------------------------------------------------
	function int (&$data) {
		return is_numeric($data);
	}
	function int_empty (&$data) {
		return empty($data) || $this->int($data);
	}
	function int_positive (&$data) {
		return $this->int($data) && $data>0;
	}

	//-- double --------------------------------------------------------------------------------------------------------
	function double (&$data) {
		$data = str_replace([',', ' '],['.', ''], $data);
		return is_numeric($data);
	}
	function double_empty (&$data) {
		return empty($data) || $this->double($data);
	}
	function double_positive (&$data) {
		return $this->double($data) && $data>0;
	}

	//-- date ----------------------------------------------------------------------------------------------------------
	function date (&$data) {
		return preg_match($GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['reg']['date'], $data);
	}
	function date_empty (&$data) {
		return empty($data) || $this->date($data);
	}

	//-- datetime ------------------------------------------------------------------------------------------------------
	function datetime (&$data) {
		if(is_array($data)){
			if(isset($data['date']))
				return preg_match($GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['reg']['date'], $data['date']);
			return true;
		}
		return preg_match($GLOBALS['lib']->date_time->formats[\site\setting_db::get_setting('date_format')]['reg']['datetime'], $data);
	}
	function datetime_empty (&$data) {
		return empty($data) || $this->datetime($data);
	}

	//-- time ----------------------------------------------------------------------------------------------------------
	function time (&$data) {
		if (is_array($data)) {
			return isset($data['h']) && $data['h']<=24 &&
				isset($data['i']) && $data['i']<=59 &&
				isset($data['s']) && $data['s']<=59 &&
				($data['h']<24 || ($data['i']===0 && $data['s']===0));
		}

		$format = \site\setting_db::get_setting('date_format');
		if (preg_match($GLOBALS['lib']->date_time->formats[$format]['reg']['times'], $data, $matches) ||
			preg_match($GLOBALS['lib']->date_time->formats[$format]['reg']['time'], $data, $matches)){
			$a = $GLOBALS['lib']->date_time->matches_to_array($matches, $format, 'time');
			return $a['h']<=24 && $a['i']<=59 && $a['s']<=59 && ($a['h']<24 || ($a['i']===0 && $a['s']===0));
		}

		return false;
	}
	function time_empty (&$data) {
		return empty($data) || $this->time($data);
	}
}
