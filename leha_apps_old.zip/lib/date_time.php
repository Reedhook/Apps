<?php
namespace lib;
/*
подразумевается
в классе есть типы данных
stamp		(integer)				gm
sql			yyyy-mm-dd HH:ii:ss		gm
sql			yyyy-mm-dd				local
format		dd/mm/yyyy HH:ii:ss		local
format		dd/mm/yyyy				local
array		[y, m, d, h, i, s]		local
array		[y, m, d]				local
*/

class date_time {
	var $formats = [
		'sql'	=> [
			'php'			=> [
				'date'		=> 'Y-m-d',
				'datetime'	=> 'Y-m-d H:i:s',
				'datetimeg'	=> 'Y-m-d H:i:s+00',
				'times'		=> 'H:i:s',
				'time'		=> 'H:i',
			],
			'reg'			=> [
				'date'		=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9])$/',
				'datetime'	=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9]) ([0-2][0-9])\:([0-5][0-9])$/',
				'datetimes'	=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9]) ([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])$/',
				'datetimeg'	=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9])[ |T]([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])([\+\-][0-1][0-9])[\:]?([0-5][0-9])?$/',// with greenwich meridian
				'datetimef'	=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9]) ([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])\.(\d+)$/',// seconds float
				'datetimefg'=> '/^(\d{4})-([0-1][0-9])-([0-3][0-9]) ([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])\.(\d+)([\+\-][0-1][0-9])[\:]?([0-5][0-9])?$/',// seconds float with greenwich meridian
				'times'		=> '/^([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])$/',
				'timesm'	=> '/^([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])\.(\d+)$/',
				'time'		=> '/^([0-2][0-9])\:([0-5][0-9])$/',
			],
			'reg_pos'			=> [// y, m, d position in reg
				'date'		=> ['y'=>1, 'm'=>2, 'd'=>3],
				'datetime'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5],
				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
//				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
				'datetimeg'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6, 'gm'=>7],
				'times'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>-1],
			],
		],
		'Y/m/d'	=> [
			'php'			=> [
				'date'		=> 'Y/m/d',
				'datetime'	=> 'Y/m/d H:i:s',
				'times'		=> 'H:i:s',
				'time'		=> 'H:i',
			],
			'reg'			=> [
				'date'		=> '/^(\d{4})\/([0-1][0-9])\/([0-3][0-9])$/',
				'datetime'	=> '/^(\d{4})\/([0-1][0-9])\/([0-3][0-9]) (\d{1,2})\:([0-5][0-9])$/',
				'datetimes'	=> '/^(\d{4})\/([0-1][0-9])\/([0-3][0-9]) (\d{1,2})\:([0-5][0-9])\:([0-5][0-9])$/',
				'times'		=> '/^([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])$/',
				'time'		=> '/^([0-2][0-9])\:([0-5][0-9])$/',
			],
			'reg_pos'			=> [// y, m, d position in reg
				'date'		=> ['y'=>1, 'm'=>2, 'd'=>3],
				'datetime'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5],
				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
				'times'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>-1],
			],
		],
		'd/m/Y'	=> [
			'php'			=> [
				'date'		=> 'd/m/Y',
				'datetime'	=> 'd/m/Y H:i:s',
				'times'		=> 'H:i:s',
				'time'		=> 'H:i',
			],
			'reg'			=> [
				'date'		=> '/^([0-3][0-9])\/([0-1][0-9])\/(\d{4})$/',
				'datetime'	=> '/^([0-3][0-9])\/([0-1][0-9])\/(\d{4}) (\d{1,2})\:([0-5][0-9])$/',
				'datetimes'	=> '/^([0-3][0-9])\/([0-1][0-9])\/(\d{4}) (\d{1,2})\:([0-5][0-9])\:([0-5][0-9])$/',
				'times'		=> '/^([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])$/',
				'time'		=> '/^([0-2][0-9])\:([0-5][0-9])$/',
			],
			'reg_pos'			=> [// y, m, d position in reg
				'date'		=> ['y'=>3, 'm'=>2, 'd'=>1],
				'datetime'	=> ['y'=>3, 'm'=>2, 'd'=>1, 'h'=>4, 'i'=>5],
				'datetimes'	=> ['y'=>3, 'm'=>2, 'd'=>1, 'h'=>4, 'i'=>5, 's'=>6],
				'times'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>-1],
			],
		],
		'd.m.Y'	=> [
			'php'			=> [
				'date'		=> 'd.m.Y',
				'datetime'	=> 'd.m.Y H:i:s',
				'times'		=> 'H:i:s',
				'time'		=> 'H:i',
			],
			'reg'			=> [
				'date'		=> '/^([0-3][0-9])\.([0-1][0-9])\.(\d{4})$/',
				'datetime'	=> '/^([0-3][0-9])\.([0-1][0-9])\.(\d{4}) (\d{1,2})\:([0-5][0-9])$/',
				'datetimes'	=> '/^([0-3][0-9])\.([0-1][0-9])\.(\d{4}) (\d{1,2})\:([0-5][0-9])\:([0-5][0-9])$/',
				'times'		=> '/^([0-2][0-9])\:([0-5][0-9])\:([0-5][0-9])$/',
				'time'		=> '/^([0-2][0-9])\:([0-5][0-9])$/',
			],
			'reg_pos'			=> [// y, m, d position in reg
				'date'		=> ['y'=>3, 'm'=>2, 'd'=>1],
				'datetime'	=> ['y'=>3, 'm'=>2, 'd'=>1, 'h'=>4, 'i'=>5],
				'datetimes'	=> ['y'=>3, 'm'=>2, 'd'=>1, 'h'=>4, 'i'=>5, 's'=>6],
				'times'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>-1],
			],
		],
		'onec'	=> [
			'php'			=> [
				'date'		=> 'Y-m-d',
				'datetime'	=> 'Y-m-d\TH:i:s',
				'time'		=> 'H:i:s',
			],
			'reg'			=> [
				'date'		=> '/^(\d{4})([0-1][0-9])([0-3][0-9])$/',
				'datetime'	=> '/^(\d{4})([0-1][0-9])([0-3][0-9])(\d{1,2})([0-5][0-9])$/',
				'datetimes'	=> '/^(\d{4})([0-1][0-9])([0-3][0-9])(\d{1,2})([0-5][0-9])([0-5][0-9])$/',
				'time'		=> '/^([0-2][0-9])([0-5][0-9])([0-5][0-9])$/',
			],
			'reg_pos'			=> [// y, m, d position in reg
				'date'		=> ['y'=>1, 'm'=>2, 'd'=>3],
				'datetime'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5],
				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
				'datetimes'	=> ['y'=>1, 'm'=>2, 'd'=>3, 'h'=>4, 'i'=>5, 's'=>6],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
			],
		],
		'custom'	=> [
			'php'			=> [
				'times'		=> 'H:i:s',
				'time'		=> 'H:i',
			],
			'reg'			=> [
				'times'		=> '/^((?:[0-2]?)[0-9])\:([0-5][0-9])\:([0-5][0-9])$/', // часы могут быть одной цифрой
				'time'		=> '/^((?:[0-2]?)[0-9])\:([0-5][0-9])$/', // часы могут быть одной цифрой
			],
			'reg_pos'			=> [// y, m, d position in reg
				'times'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>3],
				'time'		=> ['y'=>-1, 'm'=>-1, 'd'=>-1, 'h'=>1, 'i'=>2, 's'=>-1],
			],
		],
	];

//----------------------------------------------------------------------------------------------------------------------
//-- note: data_type_location {sql: gm, stamp: gm, format: local, array: local}

	protected function sql_array_to_stamp($matches) {
		return gmmktime(
			(isset($matches[4]) ? $matches[4] : 0),// - (isset($matches[7]) ? intval($matches[7]) : 0), // закомментировал для подсчета object_player_auth_db::get_status
			isset($matches[5]) ? $matches[5] : 0,
			isset($matches[6]) ? $matches[6] : 0,
			$matches[2],
			$matches[3],
			$matches[1]
		);
	}
//	protected
	function matches_to_array($matches, $format, $reg_name='datetimes') {
		$p = $this->formats[$format]['reg_pos'][$reg_name];
		return [
			'y'	=> isset($matches[$p['y']]) ? intval($matches[$p['y']]) : 0,
			'm'	=> isset($matches[$p['m']]) ? intval($matches[$p['m']]) : 0,
			'd'	=> isset($matches[$p['d']]) ? intval($matches[$p['d']]) : 0,
			'h'	=> isset($p['h']) && isset($matches[$p['h']]) ? intval($matches[$p['h']]) : 0,
			'i'	=> isset($p['i']) && isset($matches[$p['i']]) ? intval($matches[$p['i']]) : 0,
			's'	=> isset($p['s']) && isset($matches[$p['s']]) ? intval($matches[$p['s']]) : 0,
//			'gm'=> isset($matches[$p['gm']]) ? $matches[$p['gm']] : 0,
		];
	}
	protected function array_to_stamp($data, $gm=false) {
		return ($gm ? 'gmmktime' : 'mktime')(
			isset($data['h']) ? $data['h'] : 0,
			isset($data['i']) ? $data['i'] : 0,
			isset($data['s']) ? $data['s'] : 0,
			$data['m'],
			$data['d'],
			$data['y']
		);
	}

	//------------------------------------------------------------------------------------------------------------------
	function to_format($data, $time=false, $format=null, $gm=false) {
		if (empty($data))
			return '';

		if (!$format)
			$format = \site\setting_db::get_setting('date_format');

		// from stamp
		if (is_numeric($data)) {
			return ($gm ? 'gmdate' : 'date') ($this->formats[$format]['php'][$time ? 'datetime' : 'date'], $data);
		}

		if ($data==='0000-00-00' || $data==='0000-00-00 00:00' || $data==='0000-00-00 00:00:00' || $data==='0000-00-00 00:00:00+00')
			return '';

		// from sql date to str
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)) {
			$stamp = $this->array_to_stamp($this->matches_to_array($matches, 'sql'), true);
			return $this->to_format($stamp, $time, $format, true);
		}

		// from sql date_time to str
		if (preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimef'], $data, $matches)
		) {
			return $this->to_format($this->sql_array_to_stamp($matches), $time, $format, $gm);
		}

		//from format
		if (preg_match($this->formats[$format]['reg'][$time ? 'datetime' : 'date'], $data, $matches))
			return $data;

		return '';
	}

	//------------------------------------------------------------------------------------------------------------------
	function to_sql($data, $time=true) {
		//return $this->to_format($data, $time=true, 'sql');
		if (empty($data))
			return null;

		$format = \site\setting_db::get_setting('date_format');

		// from stamp
		if (is_numeric($data))
			return gmdate($this->formats['sql']['php'][$time ? 'datetime' : 'date'], $data);

		// from array
		if (is_array($data)) {
			if (isset($data['date'])) {
				if (preg_match($this->formats[$format]['reg']['date'], $data['date'], $matches)){
					$p = $this->formats[$format]['reg_pos']['datetimes'];
					if (!$time)
						return $matches[$p['y']].'-'.$matches[$p['m']].'-'.$matches[$p['d']];
					$data['y'] = $matches[$p['y']];
					$data['m'] = $matches[$p['m']];
					$data['d'] = $matches[$p['d']];
				} else {
					return null;
				}
			}
			return $this->to_sql($this->array_to_stamp($data), $time);
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data))
			return $time ? $data.' 00:00:00' : $data;
		if (preg_match($this->formats['sql']['reg']['datetime'], $data, $matches))
			return $time ? $data.':00' : substr($data, 0, 10);
		if (preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches))
			return $time ? $data  : substr($data, 0, 10);
		if (
			preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches) ||
			preg_match($this->formats['sql']['reg']['datetimef'], $data, $matches) ||
			preg_match($this->formats['sql']['reg']['datetimefg'], $data, $matches)
		)
			return $time ? $data : substr($data, 0, 10);
//			return $time ? substr($data, 0, 19) : substr($data, 0, 10);

		//from format
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches)) { // формируем sql дату без учета часового пояса
			$p = $this->formats[$format]['reg_pos']['date'];
			return sprintf ("%'.04d-%'.02d-%'.02d",
				intval(isset($matches[$p['y']]) ? $matches[$p['y']] : 0),
				intval(isset($matches[$p['m']]) ? $matches[$p['m']] : 0),
				intval(isset($matches[$p['d']]) ? $matches[$p['d']] : 0)
			);
		}

		if (preg_match($this->formats[$format]['reg']['datetime'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		) {
			return $this->to_sql($this->array_to_stamp($this->matches_to_array($matches, $format)), $time);
		}

		return null;
	}

	//------------------------------------------------------------------------------------------------------------------
	function to_array($data=null) {
		if (empty($data))
			return [
				'y'	=> 0,
				'm'	=> 0,
				'd'	=> 0,
				'h'	=> 0,
				'i'	=> 0,
				's'	=> 0,
			];

		$format = \site\setting_db::get_setting('date_format');

		//-- from format -----------------------------------------------------------------------------------------------
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetime'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		) {
			return $this->matches_to_array($matches, $format);
		}

		//-- from format time only -------------------------------------------------------------------------------------
		if (preg_match($this->formats[$format]['reg']['times'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['time'], $data, $matches)
		) {
			$p = $this->formats[$format]['reg_pos']['times'];
			return [
				'y'	=> 0,
				'm'	=> 0,
				'd'	=> 0,
				'h'	=> isset($matches[$p['h']]) ? $matches[$p['h']] : 0,
				'i'	=> isset($matches[$p['i']]) ? $matches[$p['i']] : 0,
				's'	=> isset($matches[$p['s']]) ? $matches[$p['s']] : 0,
			];
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)) // don't prepare gm
			return $this->matches_to_array($matches, 'sql');

		if (preg_match($this->formats['sql']['reg']['datetime'], $data, $matches) // convert to stamp to prepare gm
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
		) {
			$data = $this->sql_array_to_stamp($matches);
		}

		if (preg_match($this->formats['sql']['reg']['times'], $data, $matches) ||
			preg_match($this->formats['sql']['reg']['time'], $data, $matches)
		) {  // don't prepare gm
			$p = $this->formats['sql']['reg_pos']['times'];
			return [
				'y'	=> 0,
				'm'	=> 0,
				'd'	=> 0,
				'h'	=> isset($matches[$p['h']]) ? $matches[$p['h']] : 0,
				'i'	=> isset($matches[$p['i']]) ? $matches[$p['i']] : 0,
				's'	=> isset($matches[$p['s']]) ? $matches[$p['s']] : 0,
			];
		}

		// from stamp
		if (is_numeric($data)) {
			if ($data<3600*24) {
				$s = $data%60;
				$data = ($data-$s)/60;
				$i = $data%60;
				$h = ($data-$i)/60;
				return [
					'h'	=> $h,
					'i'	=> $i,
					's'	=> $s,
				];
			}
			$a = getdate($data);
			return [
				'y'	=> $a['year'],
				'm'	=> $a['mon'],
				'd'	=> $a['mday'],
				'h'	=> $a['hours'],
				'i'	=> $a['minutes'],
				's'	=> $a['seconds'],
			];
		}

		return [];
	}

	//------------------------------------------------------------------------------------------------------------------
	function to_stamp($data) {
		if (empty($data))
			return 0;

		$format = \site\setting_db::get_setting('date_format');

		// from stamp
		if (is_numeric($data))
			return $data;


		// from array
		if (is_array($data)) {
			if(isset($data['date'])) {
				if (preg_match($this->formats[$format]['reg']['date'], $data['date'], $matches)) {
					$p = $this->formats[$format]['reg_pos']['datetimes'];
					$data['y'] = $matches[$p['y']];
					$data['m'] = $matches[$p['m']];
					$data['d'] = $matches[$p['d']];
				} else {
					return 0;
				}
			}
			return $this->array_to_stamp($data);
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
		) {
			return $this->sql_array_to_stamp($matches);
		}

		// from format
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetime'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		) {
			return $this->array_to_stamp($this->matches_to_array($matches, $format));
		}

		return 0;
	}

	//-- time ----------------------------------------------------------------------------------------------------------
	function to_sql_time($data, $gm=false) {
		if (empty($data))
			$data = 0;

		// from stamp
		if (is_numeric($data)) {
			return $gm ? gmdate("H:i:s", $data) : date("H:i:s", $data);
		}

		// from array
		if (is_array($data)) {
			if (isset($data['hours']) || isset($data['minutes']) || isset($data['seconds']))
				return sprintf ("%'.02d:%'.02d:%'.02d", intval($data['hours']??0), intval($data['minutes']??0), intval($data['seconds']??0));
			return sprintf ("%'.02d:%'.02d:%'.02d", intval($data['h']), intval($data['i']), isset($data['s']) ? intval($data['s']) : 0);
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['times'], $data, $matches))
			return $data;
		if (preg_match($this->formats['sql']['reg']['timesm'], $data, $matches))
			return $data;
		if (preg_match($this->formats['sql']['reg']['time'], $data, $matches))
			return $data.':00';
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches))
			return '00:00:00';
		if (preg_match($this->formats['sql']['reg']['datetime'], $data, $matches))
			return $matches[3].':'.$matches[4].':00';
		if (preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches))
			return $matches[3].':'.$matches[4].':'.$matches[5];
		if (preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches))
			return $matches[7]=='+00' ? $matches[3].':'.$matches[4].':'.$matches[5] : $this->to_sql_time($this->sql_array_to_stamp($matches));
//		if (preg_match($this->formats['sql']['reg']['datetimefg'], $data, $matches))
//			return $matches[8]=='+00' ? $matches[3].':'.$matches[4].':'.$matches[5] : $this->to_sql_time($this->sql_array_to_stamp($matches));

		// from custom
		if (preg_match($this->formats['custom']['reg']['times'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, 'custom', 'times'));
		if (preg_match($this->formats['custom']['reg']['time'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, 'custom', 'time'));

		//from format
		$format = \site\setting_db::get_setting('date_format');
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches))
		return '00:00:00';
		if (preg_match($this->formats[$format]['reg']['datetime'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, $format, 'datetime'));
		if (preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, $format, 'datetimes'));
		if (preg_match($this->formats[$format]['reg']['times'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, $format, 'times'));
		if (preg_match($this->formats[$format]['reg']['time'], $data, $matches))
			return $this->to_sql_time($this->matches_to_array($matches, $format, 'time'));

		return null;
	}

	function sql_time_to_sec($sql_time) {
		if (empty($sql_time))
			return 0;

		$a = array_map('intval', array_map('trim', explode(':', $sql_time)));

		return $a[0]*3600 + $a[1]*60 + (isset($a[2])?$a[2]:0);
	}
	function sec_to_sql_time($sec) {
		return sprintf ("%'.02d:%'.02d:%'.02d", floor($sec/3600), floor(($sec%3600)/60), $sec%60);
	}

	// 00:08:35 => 8:35
	function sql_time_to_str($sql_time) {
		if (empty($sql_time))
			return '';

		$array_time = explode(':', $sql_time);
		if (count($array_time)!==3)
			return '';

		list($h, $i, $s) = array_map('intval', array_map('trim', $array_time));
		return ($h===0 ? '' : $h.':').
			($h>0 && $i<10 ? '0'.$i : $i).':'.
			($s<10 ? '0'.$s : $s);
	}

	//-- date ----------------------------------------------------------------------------------------------------------
	// работа с датами (без времени). все данные обрабатываются по гринвичу

	// переводит в форматированную строку (из stamp, array[y,m,d], sql, format(y,m,d))
	function date_to_format($data, $format=null) {
		if (empty($data))
			return '';

		if (!$format)
			$format = \site\setting_db::get_setting('date_format');

		if (is_numeric($data)) // from stamp
			return gmdate($this->formats[$format]['php']['date'], $data);

		if (is_array($data)) // from array
			return str_replace(
				['Y', 'm', 'd'],
				[($data['y']<1000?str_repeat('0', 4-strlen($data['y'])):'').$data['y'], ($data['m']<10?'0':'').$data['m'], ($data['d']<10?'0':'').$data['d']],
				$this->formats[$format]['php']['date']
			);

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimef'], $data, $matches)
		) {
			return $this->date_to_format($this->matches_to_array($matches, 'sql'), $format);
		}

		//from format
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches))
			return $data;

		if (preg_match($this->formats[$format]['reg']['datetime'], $data, $matches))
			return $this->date_to_format($this->matches_to_array($matches, $format), $format);

		return '';
	}
	function date_to_sql($data, $format=null) {
		if (empty($data))
			return null;

		if (!$format)
			$format = \site\setting_db::get_setting('date_format');

		// from stamp
		if (is_numeric($data))
			return gmdate($this->formats['sql']['php']['date'], $data);

		// from array
		if (is_array($data)) {
			if (isset($data['date'])) { // [data, h, i, s]
				if (preg_match($this->formats[$format]['reg']['date'], $data['date'], $matches)) {
					$data = $this->matches_to_array($matches, $format);
				} else {
					return null;
				}
			}
			return sprintf ("%'.04d-%'.02d-%'.02d", $data['y'], $data['m'], $data['d']);
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data))
			return $data;

		if (preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimef'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimefg'], $data, $matches)
		)
			return substr($data, 0, 10);

		//from format
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches)
			|| preg_match($this->formats[$format]['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		)
			return $this->date_to_sql($this->matches_to_array($matches, $format, 'date'));

		return null;
	}
	function date_to_array($data=null) {
		if (empty($data))
			return [
				'y'	=> 0,
				'm'	=> 0,
				'd'	=> 0,
			];

		$format = \site\setting_db::get_setting('date_format');

		//-- from format -----------------------------------------------------------------------------------------------
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetime'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		) {
			return $this->matches_to_array($matches, $format, 'date');
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)
			||preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimef'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimefg'], $data, $matches)
		)
			return $this->matches_to_array($matches, 'sql', 'date');

		// from stamp
		if (is_numeric($data)) {
			$a = explode('|', gmdate('Y|m|d'));
			return [
				'y'	=> $a[0],
				'm'	=> $a[1],
				'd'	=> $a[2],
			];
		}

		return [];
	}

	function date_to_stamp($data) {
		if (empty($data))
			return 0;

		$format = \site\setting_db::get_setting('date_format');

		// from stamp
		if (is_numeric($data))
			return $data;

		// from array
		if (is_array($data)) {
			if(isset($data['date'])) {
				if (preg_match($this->formats[$format]['reg']['date'], $data['date'], $matches)) {
					$data = $this->matches_to_array($matches, $format, 'date');
				} else {
					return 0;
				}
			}
			return $this->array_to_stamp($data, true);
		}

		// from sql
		if (preg_match($this->formats['sql']['reg']['date'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetime'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimes'], $data, $matches)
			|| preg_match($this->formats['sql']['reg']['datetimeg'], $data, $matches)
		)
			return $this->date_to_stamp($this->matches_to_array($matches, 'sql', 'date'));

		// from format
		if (preg_match($this->formats[$format]['reg']['date'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetime'], $data, $matches) ||
			preg_match($this->formats[$format]['reg']['datetimes'], $data, $matches)
		)
			return $this->date_to_stamp($this->matches_to_array($matches, $format, 'date'));

		return 0;
	}
}