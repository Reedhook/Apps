<?php
namespace lib;
define ('SQL_DURATION_LOG', 2); // SQL запросы более 2 секунд будут логироваться

abstract class db_ {
	protected $db_o = false;
	protected static $db_type = '';
	protected $settings = [];

	abstract function connect ($settings=[]);
	abstract function ping ();
	abstract function query ($sql_str, $options=[]);
	abstract function data_quote($data);
	abstract function field_quote($data);
	abstract function get_insert_id($table_name);
	abstract function insert($table_name, &$data);
	abstract function update($table_name, &$data, $id);
	abstract function escape_string($data);
	abstract function close();
	abstract function table_exists($table);
	abstract function create_table($table_name, $field_list);
	abstract function create_index($table, $fields, $unique=false);
	abstract function add_column($table, $field_list, $f);

	function __get($property_name) {
		if ($property_name==='db_type')
			return static::$db_type;
		if ($property_name==='settings')
			return $this->settings;

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'unknown property name: '.p($property_name, true),
		];
		throw new \Exception('custom exception');
	}
}

class db_pg extends db_ {
	protected $db_o = false;
	protected static $db_type = 'pg';
//	protected $settings = [];
	protected static $create_table_counter = 0;


	function connect ($settings=[]) {
		$this->settings = empty($settings) ? $GLOBALS['conf']['db'] : $settings;

		$this->db_o =  \pg_connect (
			"host=".$this->settings['host'].
			" port=".$this->settings['port'].
			" dbname=".$this->settings['name'].
			" user=".$this->settings['user'].
			" password=".$this->settings['pass']
			);
		if (!$this->db_o) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db connect error',
			];
			throw new \Exception('custom exception');
		}
//		$this->query("set timezone = '{$GLOBALS['conf']['site']['timezone']}';");
	}

	function ping () {
//			if (!\pg_ping($this->db_o))
		if (pg_connection_status($this->db_o)!==PGSQL_CONNECTION_OK)
			$this->connect();
	}

	function query ($sql_str, $options=[]) {
		$query_counter = isset($options['query_counter']) ? $options['query_counter'] : 0;

		$start_time = microtime(true);
		if (!empty($options['data_list'])) {// don't use! waiting for php update. now values false and null converts to ''
			$query_result = @\pg_query_params($this->db_o, $sql_str, $options['data_list']);
		} else {
			$query_result = @\pg_query($this->db_o, $sql_str);// @ - don't call error_handler
		}
		$query_time = microtime(true)-$start_time;
		$GLOBALS['lib']->site_stat->add_sql_time($query_time);

		if ($query_result===false) {
			$err_msg = \pg_last_error($this->db_o);

			//-- if column doesn't exist, try to add column
			if (!empty($options['class_db']) && $query_counter<2 && (
				preg_match("/column ([^\s]+) does not exist/is", $err_msg, $matches) ||
				preg_match("/column \"([^\"]+)\" of relation \"[^\"]+\" does not exist/is", $err_msg, $matches) ||
				preg_match("/столбец \"([^\"]+)\" в таблице \"[^\"]+\" не существует/is", $err_msg, $matches)
			)) {
				$options['query_counter'] = $query_counter + 1;

				$class_name = '\\'.$options['class_db'];
				$field = array_slice(explode('.', $matches[1]), -1)[0];
				$this->add_column($class_name::get_table_name(), $class_name::get_field_list(), $field);

				return $this->query($sql_str, $options);
			}

			//-- if table doesn't exist, try to create table
			if (!empty($options['class_db']) && $query_counter<2 && (
				preg_match("/отношение .+ не существует/is", $err_msg) ||
				preg_match("/relation .+ does not exist/is", $err_msg)
			)) {
				$options['query_counter'] = $query_counter + 1;
				if (static::$create_table_counter++ > 100)
					throw new \Exception('custom exception');

				$class_name = '\\'.$options['class_db'];
				$class_name::create_table();
				return $this->query($sql_str, $options);
			}

			$GLOBALS['lib']->log->write($sql_str."\n--".number_format($query_time, 6, '.', ' ')." sec\n{$err_msg}\n", 'sql_err.sql');

			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> $err_msg,
				'sql'	=> $sql_str,
			];
			throw new \Exception('custom exception');
		}

		if ($query_time>SQL_DURATION_LOG) {
			$controller = isset($GLOBALS['controller']) ? $GLOBALS['controller']['module'].'/'.$GLOBALS['controller']['controller'].'/'.$GLOBALS['controller']['method']."\n" : '';
			$GLOBALS['lib']->log->write($controller.$sql_str."\n--".number_format($query_time, 6, '.', ' ')." sec\n", 'sql_long.sql');
		}

		$list = [];
		while($row = pg_fetch_assoc($query_result)) {
			if (isset($options['row_function']))
				$options['row_function'] ($row);
			if (empty($options['no_answer']))
				if (!empty($options['key'])) {
					$list[$row[$options['key']]] = empty($options['field']) ? $row : $row[$options['field']];
				} else {
					$list[] = empty($options['field']) ? $row : $row[$options['field']];;
				}
		}
		return $list;
	}

	function data_quote($data) {
		if (is_null($data))
			return 'NULL';
		if (is_bool($data))
			return ($data ? 'TRUE' : 'FALSE');
		if (is_int($data) || is_float($data))
			return $data;

		if (!is_string($data)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> 'invalid argument: ' . print_r($data, true),
			];
			throw new \Exception('custom exception');
		}

		if (in_array($data, ['now()']))
			return $data;

		return "'".$this->escape_string($data)."'";
	}

	function field_quote($data) {
		$data = explode('.', $data);
		if (count($data)==2){
			return static::field_quote($data[0]).'.'.static::field_quote($data[1]);
		} elseif (count($data)==1){
			$data[0] = str_replace("#p#", $this->settings['prefix'], $data[0]);
			return \pg_escape_identifier($data[0]);
		}

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'error field name: ' . print_r($data, true),
		];
		throw new \Exception('custom exception');
	}

	function get_insert_id($table_name) {
		return static::query("SELECT currval('".$this->settings['prefix']."{$table_name}_id_seq') AS id;")[0]['id'];
	}

	function insert($table_name, &$data, $options=[]/*, $created=true*/) {
		if (count($data)==0) {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name).
				" (".static::field_quote('id').")\n".
				"VALUES (nextval(".static::data_quote($this->settings['prefix'].$table_name."_id_seq")."::regclass))\n".
				"RETURNING ".static::field_quote('id');
		} else {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name).
				" (".implode(', ', array_map([get_class(), 'field_quote'], array_keys($data))).")\n".
				"VALUES (".implode(', ', array_map([get_class(), 'data_quote'], $data)).")\n".
				"RETURNING ".static::field_quote('id');
		}

		$res = static::query($sql, $options);
		if (count($res)>0)
			$data['id'] = $res[0]['id'];
//		$data['id'] = $this->get_insert_id($table_name);
	}

	function update($table_name, &$data, $id, $options=[]/*, $updated=true*/) {
		$field_values = [];
//			$i = 1;
		foreach($data as $f=>$v)
			$field_values[] = static::field_quote($f)."=".static::data_quote($v);
//				$field_values[] = static::field_quote($f).'=$'.($i++);
		$sql = "UPDATE ".static::field_quote('#p#'.$table_name).
			"\nSET ".implode(', ', $field_values).
			"\nWHERE ".static::field_quote('id').'='.static::data_quote($id);
//				"\nWHERE ".static::field_quote('id').'=$'.($i++);

		static::query($sql, $options);
//			static::query($sql, ['data_list'=>array_merge($data, [$id])]);
	}

	function escape_string($data) {
		if (is_bool($data) || is_float($data) || is_int($data))
			return $data;

		if (is_string($data))
			return \pg_escape_string($this->db_o, $data);

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'string or numeric should be.' . print_r($data, true),
		];
		throw new \Exception('custom exception');
	}

	function close() {
		\pg_close($this->db_o);
	}

	function table_exists($table) {
		return count($this->query("SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_NAME='".$this->settings['prefix']."{$table}'"))>0;
	}

	protected function get_column_sql($f, $field_list) {

		switch ($field_list[$f]['type']) {
			case 'stamp':
			case 'int':		$field_sql = $this->field_quote($f)." int".(isset($field_list[$f]['size'])?$field_list[$f]['size']:4)."".(isset($field_list[$f]['ref']) ? "" : " DEFAULT 0 NOT NULL")."";		break;
			case 'money':	$field_sql = $this->field_quote($f)." DECIMAL(12,2)";		break;
			case 'float':	$field_sql = $this->field_quote($f)." real DEFAULT 0 NOT NULL";		break;
			case 'bool':	$field_sql = $this->field_quote($f)." boolean DEFAULT false NOT NULL";	break;
			case 'enum':
			case 'str':		$field_sql = $this->field_quote($f)." varchar(".(isset($field_list[$f]['size'])?$field_list[$f]['size']:512).") COLLATE \"default\"";break;
			case 'json':	$field_sql = $this->field_quote($f)." jsonb";							break;
			case 'text':	$field_sql = $this->field_quote($f)." text COLLATE \"default\"";		break;
			case 'date':	$field_sql = $this->field_quote($f)." date";							break;
//			case 'datetime':$field_sql = $this->field_quote($f)." timestamptz(0)";					break;
			case 'datetime':$field_sql = $this->field_quote($f)." timestamp";						break;
			case 'time':	$field_sql = $this->field_quote($f)." interval";						break;
			default: throw new \Exception('unknown field type '.$field_list[$f]['type']);
		}
		return $field_sql;
	}
	function add_column($table, $field_list, $f) {
		$table_name = $this->settings['prefix'].$table;

		$this->query("ALTER TABLE {$this->field_quote($table_name)} ADD COLUMN {$this->get_column_sql($f, $field_list)};");

		if (isset($field_list[$f]['ref']))
			$this->query(
"ALTER TABLE {$this->field_quote($table_name)}
ADD CONSTRAINT {$this->field_quote($table_name."_{$f}_fkey")} FOREIGN KEY ({$this->field_quote($f)}) 
REFERENCES {$this->field_quote($this->settings['prefix'].$field_list[$f]['ref']::get_table_name())} ({$this->field_quote("id")}) ON DELETE SET NULL ON UPDATE CASCADE"
			);
	}
	function create_table($table, $field_list) {
		$id_str = $table==='session';
		$table_name = $this->settings['prefix'].$table;
		$sequence_name = "{$table_name}_id_seq";
		$fields_sql = '';
		$constraints_sql = '';

		foreach ($field_list as $f=>$r) {
			if (isset($r['ref']))
				$constraints_sql .= "CONSTRAINT \"{$table_name}_{$f}_fkey\" FOREIGN KEY (\"{$f}\") REFERENCES \"".$this->settings['prefix']."{$r['ref']::get_table_name()}\" (\"id\") ON DELETE SET NULL ON UPDATE CASCADE,\n";

			$fields_sql.= $this->get_column_sql($f, $field_list)."\n,";
		}

		$sql_list = [
			'drop_table'		=> "DROP TABLE IF EXISTS {$table_name}",
			'drop_sequence'		=> "DROP SEQUENCE IF EXISTS {$sequence_name}",
			'create_sequence'	=> $id_str ? false : "CREATE SEQUENCE {$sequence_name} MINVALUE 1 NO MAXVALUE START 1 INCREMENT 1",
//			'alter_sequence_owner'	=> "ALTER SEQUENCE $table_name}_id_seq OWNER TO postgres",
			'create_table'		=> "CREATE TABLE {$table_name} (
".$this->field_quote('id').($id_str?' varchar(255)':' serial')." NOT NULL,
{$fields_sql}{$constraints_sql}CONSTRAINT {$table_name}_pkey PRIMARY KEY (id))
WITH (OIDS=FALSE)",
//			"alter_table_owner"	=> "ALTER TABLE {$table_name} OWNER TO postgres",
			"alter_table_id"	=> $id_str ? false : "ALTER TABLE {$table_name} ALTER COLUMN id SET DEFAULT NEXTVAL('{$sequence_name}'::regclass)",
			"alter_sequence_id"	=> $id_str ? false : "ALTER SEQUENCE {$sequence_name} OWNED BY {$table_name}.id",
		];

		foreach ($sql_list as $sql)
			if ($sql)
				$this->query($sql);

		if ($id_str)
			$this->create_index($table, ['id'], true);

		return true;
	}

	function create_index($table, $fields, $unique=false) {
		$index_name = $this->field_quote('#p#'.$table.'_'.implode('_', $fields).'_idx');
		$this->query("DROP INDEX IF EXISTS ".$index_name);
		$sql = "CREATE ".($unique ? 'UNIQUE' : '')
			." INDEX ".$index_name
			." ON ".$this->field_quote('#p#'.$table)
			." USING btree (".implode(', ', array_map([$this, 'field_quote'], $fields)).")";

		$this->query($sql);
	}
	function drop_index($table, $fields, $unique=false) {
		$index_name = $this->field_quote('#p#'.$table.'_'.implode('_', $fields).'_idx');
		$this->query("DROP INDEX IF EXISTS ".$index_name);
	}

	function set_sequence_number($table, $number) {
		$table_name = $this->settings['prefix'].$table;
		$sequence_name = "{$table_name}_id_seq";
		$sql = "ALTER SEQUENCE {$sequence_name} RESTART WITH ".intval($number);
		$this->query($sql);
	}
}

class db_mysqli extends db_ {
	protected $db_o = false;
	protected static $db_type = 'mysqli';
//	protected static $settings = [];
	protected static $create_table_counter = 0;

	function connect ($settings=[]) {
		$this->settings = empty($settings) ? $GLOBALS['conf']['db'] : $settings;

		$this->db_o = new \mysqli(
			$this->settings['host'],
			$this->settings['user'],
			$this->settings['pass'],
			$this->settings['name'],
			isset($this->settings['port'])?$this->settings['port']:ini_get("mysqli.default_port")
			);
		if ($this->db_o->connect_error) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db connect error',
				'msg'	=> $this->db_o->connect_error,
			];
			throw new \Exception('custom exception');
		}

		$this->db_o->set_charset('utf8');
	}

	function ping() {
		if (!@$this->db_o->ping())
			$this->connect();
	}

	function query ($sql_str, $options=[]) {
		$query_counter = isset($options['query_counter']) ? $options['query_counter'] : 0;

		$start_time = microtime(true);
		$query_result = @$this->db_o->query($sql_str);
		$query_time = microtime(true)-$start_time;
		$GLOBALS['lib']->site_stat->add_sql_time($query_time);

		if ($query_time>SQL_DURATION_LOG)
			$GLOBALS['lib']->log->write($sql_str."\n".number_format($query_time, 6, '.', ' ')." sec\n", 'sql_long.sql');

		if ($query_result===false) {
			$err_msg = $this->db_o->error;

			//-- if table doesn't exist, try to create table
			if (!empty($options['class_db']) && $query_counter<2 && (
				preg_match("/Table .+ doesn't exist/is", $err_msg)
			)) {
				$options['query_counter'] = $query_counter + 1;

				$class_name = '\\'.$options['class_db'];
				$class_name::create_table();

				return $this->query($sql_str, $options);
			}

			//-- if column doesn't exist, try to add column
			if (!empty($options['class_db']) && $query_counter<10 && (
				preg_match("/Unknown column '(.+)' in 'field list'/is", $err_msg, $matches) ||
				preg_match("/Unknown column '[^\.]+\.(.+)' in 'where clause'/is", $err_msg, $matches) ||
				preg_match("/Unknown column '[^\.]+\.(.+)' in 'order clause'/is", $err_msg, $matches)
			)) {
				$options['query_counter'] = $query_counter + 1;

				$class_name = '\\'.$options['class_db'];
				$this->add_column($class_name::get_table_name(), $class_name::get_field_list(), $matches[1]);

				return $this->query($sql_str, $options);
			}

			if ($query_counter<2 && $err_msg==='MySQL server has gone away') {
				$options['query_counter'] = $query_counter + 1;
				$this->ping();
				return $this->query($sql_str, $options);
			}

			$GLOBALS['lib']->log->write($sql_str."\n--".number_format($query_time, 6, '.', ' ')." sec\n{$err_msg}\n", 'sql_err.sql');

			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> $this->db_o->error,
			];
			throw new \Exception('custom exception');
		}

		if (is_object($query_result)){
			$list = [];
			while($row = $query_result->fetch_assoc()) {
				if (isset($options['row_function']))
					$options['row_function'] ($row);
				if (empty($options['no_answer']))
					if (!empty($options['key'])) {
						$list[$row[$options['key']]] = empty($options['field']) ? $row : $row[$options['field']];
					} else {
						$list[] = empty($options['field']) ? $row : $row[$options['field']];
					}
			}
			$query_result->close();
			return $list;
		}

		return $query_result;
	}

	function data_quote($data) {
		if (is_null($data))
			return 'NULL';
		if (is_bool($data))
			return ($data ? 1 : 0);
		if (is_int($data) || is_float($data))
			return $data;

		if (!is_string($data)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> 'invalid argument: ' . print_r($data, true),
			];
			throw new \Exception('custom exception');
		}

		if (in_array($data, ['now()']))
			return $data;

		return "'".$this->escape_string($data)."'";
	}

	function field_quote($data){
		$data = explode('.', $data);
		if (count($data)==2){
			return static::field_quote($data[0]).'.'.static::field_quote($data[1]);
		} elseif (count($data)==1){
			$data[0] = str_replace("#p#", $this->settings['prefix'], $data[0]);
			return '`'.$this->escape_string($data[0]).'`';
		}

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'error field name: ' . print_r($data, true),
		];
		throw new \Exception('custom exception');
	}

	function get_insert_id($table_name) {
		return $this->db_o->insert_id;
	}

	function insert($table_name, &$data, $options=[]) {
		if (count($data)==0) {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name)." (".static::field_quote('id').") VALUES (NULL)";
		} else {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name).
			" (".implode(', ', array_map([get_class(), 'field_quote'], array_keys($data))).') '.
			"VALUES (".implode(', ', array_map([get_class(), 'data_quote'], $data)).")";
		}
		static::query($sql, $options);
		$data['id'] = $this->get_insert_id($table_name);
	}

	function update($table_name, &$data, $id, $options=[]) {
//			if ($updated) {
//				$now = gmdate("Y-m-d H:i:s");
//				$data['updated'] = $now;
//			}
		$field_values = [];
		foreach($data as $f=>$v)
			$field_values[] = static::field_quote($f)."=".static::data_quote($v);
		$sql = "UPDATE ".static::field_quote('#p#'.$table_name).
			" SET ".implode(', ', $field_values).
			" WHERE ".static::field_quote('id').'='.static::data_quote($id);
		static::query($sql, $options);
	}

	function escape_string($data) {
		if (is_string($data)) {
			$data = $this->db_o->real_escape_string($data);
//			$data = str_replace('`', '', $data);
		}
		if (is_array($data)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> 'string or numeric should be. array given. ' . print_r($data, true),
			];
			throw new \Exception('custom exception');
		}
		return $data;
	}
	function close() {
		$this->db_o->close();
	}

	function table_exists($table) {
		return count($this->query("SHOW TABLES LIKE '".$this->settings['prefix']."{$table}'"))>0;
	}

	protected function get_column_sql($f, $field_list) {

		switch ($field_list[$f]['type']) {
			case 'stamp':
			case 'int':
				$field_sql = $this->field_quote($f).
					" int(".(isset($field_list[$f]['size']) ? $field_list[$f]['size'] : 10).")".
					(isset($field_list[$f]['ref']) ? " UNSIGNED DEFAULT NULL" : " DEFAULT 0 NOT NULL");
				break;
			case 'money':	$field_sql = $this->field_quote($f)." double NOT NULL DEFAULT '0'";		break;
			case 'float':	$field_sql = $this->field_quote($f)." double NOT NULL DEFAULT '0'";	break;
			case 'bool':	$field_sql = $this->field_quote($f)." tinyint(1) NOT NULL DEFAULT '0'";break;
			case 'enum':
			case 'str':
				$field_sql = $this->field_quote($f).
					" varchar(".(isset($field_list[$f]['size']) ? $field_list[$f]['size']:256).") NOT NULL DEFAULT ''";
				break;
			case 'json':
			case 'text':	$field_sql = $this->field_quote($f)." longtext DEFAULT NULL";			break;
			case 'date':	$field_sql = $this->field_quote($f)." date DEFAULT NULL";				break;
			case 'datetime':$field_sql = $this->field_quote($f)." datetime DEFAULT NULL";			break;
			case 'time':	$field_sql = $this->field_quote($f)." time DEFAULT NULL";				break;
			default: throw new \Exception('unknown field type '.$field_list[$f]['type']);
		}
		return $field_sql;
	}
	function add_column($table, $field_list, $f) {
		$table_name = $this->settings['prefix'].$table;
		$this->query("ALTER TABLE {$this->field_quote($table_name)} ADD COLUMN {$this->get_column_sql($f, $field_list)};");

		if (isset($field_list[$f]['ref']))
			$this->query("ALTER TABLE {$this->field_quote($table_name)}
ADD CONSTRAINT {$this->field_quote($table_name."_{$f}_fkey")} FOREIGN KEY ({$this->field_quote($f)}) 
REFERENCES {$this->field_quote($this->settings['prefix'].$field_list[$f]['ref']::get_table_name())} ({$this->field_quote("id")}) ON DELETE SET NULL ON UPDATE CASCADE"
			);

//"ALTER TABLE {$this->field_quote($table_name)} DROP FOREIGN KEY {$this->field_quote($table_name."_{$f}_fkey")}"
//"ALTER TABLE {$this->field_quote($table_name)} DROP COLUMN {$this->field_quote($f)};"
	}

	function create_table($table, $field_list) {
		$id_str = $table==='session';
		$table_name = $this->settings['prefix'].$table;
		$fields_sql = '';
		$constraints_sql = '';

		foreach ($field_list as $f=>$r) {
			if (isset($r['ref'])){
				$ref_table_name = $this->settings['prefix'].$r['ref']::get_table_name();
//				$constraints_sql .= "CONSTRAINT fk_{$table_name}_{$f} FOREIGN KEY ({$f}) REFERENCES {$ref_table_name} (id) ON DELETE SET NULL,\n";
				$constraints_sql .= "FOREIGN KEY (`{$f}`) REFERENCES `{$ref_table_name}` (`id`) ON DELETE SET NULL,\n";
			}

			$fields_sql.= $this->get_column_sql($f, $field_list).",\n";
		}
		$sql_list = [
			'drop_table'	=> "DROP TABLE IF EXISTS ".$this->field_quote($table_name),
			'create_tbale'	=> "CREATE TABLE ".$this->field_quote($table_name)." (
".$this->field_quote('id').($id_str?' varchar(255) NOT NULL':' int(10) UNSIGNED NOT NULL AUTO_INCREMENT').",  
{$fields_sql}{$constraints_sql}PRIMARY KEY (id));",
		];

		foreach ($sql_list as $sql)
			$this->query($sql);

		return true;
	}


	function create_index($table, $fields, $unique=false) {
		$sql = "ALTER TABLE ".$this->field_quote('#p#'.$table)." ADD ".($unique?'UNIQUE':'INDEX')."(".implode(', ', array_map([$this, 'field_quote'], $fields)).")";
		return $this->query($sql);
	}

}

class db_clickhouse extends db_ {
	protected $db_o = false;
	protected static $db_type = 'clickhouse';

/*	protected function q($query) {
		$url = "http://{$this->settings['host']}:{$this->settings['port']}/?database={$this->settings['name']}&query=".urlencode($query);

//		return file_get_contents($url, false, $this->db_o);

		return $GLOBALS['lib']->curl->request([$url, ['header'=>[
			'X-ClickHouse-User: '.$this->settings['user'],
			'X-ClickHouse-Key: '.$this->settings['pass'],
		]]]);
	}
*/
	function connect ($settings=[]) {
		$this->settings = empty($settings) ? $GLOBALS['conf']['db'] : $settings;
/*		$this->db_o = stream_context_create([
			'http' => [
				'method'		=> 'GET',
				'protocol_version' => 1.1,
				'header'		=> [
					'X-ClickHouse-User: '.$this->settings['user'],
					'X-ClickHouse-Key: '.$this->settings['pass'],
				],
			]
		]);

		if (!$this->db_o) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db connect error',
//				'msg'	=> $this->db_o->connect_error,
			];
			throw new \Exception('custom exception');
		}
*/
	}
	function ping () {
	}

//	protected $rows_before_limit_at_least = 0;
//	function get_last_count() {
//		return $this->rows_before_limit_at_least;
//	}
	function query ($sql_str, $options=[]) {
		$this->rows_before_limit_at_least = 0;
		$query_counter = isset($options['query_counter']) ? $options['query_counter'] : 0;

		$start_time = microtime(true);
		$query_result = $GLOBALS['lib']->curl->request(
			"http://{$this->settings['host']}:{$this->settings['port']}",
			'post',
			[
				'database'	=> $this->settings['name'],
				'query'		=> $sql_str.(strpos($sql_str, 'SELECT')===0?' FORMAT JSON':''),
			],
			[
				'header'	=> [
					'X-ClickHouse-User: '.$this->settings['user'],
					'X-ClickHouse-Key: '.$this->settings['pass'],
				],
			]
		);

		$query_time = microtime(true)-$start_time;
		$GLOBALS['lib']->site_stat->add_sql_time($query_time);

		if ($query_result===false) {
			$err_msg = $GLOBALS['lib']->curl->response;
/*
			//-- if column doesn't exist, try to add column
			if (!empty($options['class_db']) && $query_counter<2 && (
					preg_match("/column \"([^\"]+)\" of relation \"[^\"]+\" does not exist/is", $err_msg, $matches) ||
					preg_match("/столбец \"([^\"]+)\" в таблице \"[^\"]+\" не существует/is", $err_msg, $matches)
				)) {
				$options['query_counter'] = $query_counter + 1;

				$class_name = '\\'.$options['class_db'];
				$this->add_column($class_name::get_table_name(), $class_name::get_field_list(), $matches[1]);

				return $this->query($sql_str, $options);
			}
*/
			//-- if table doesn't exist, try to create table
			if (!empty($options['class_db']) && $query_counter<2 && (
					preg_match("/doesn't exist\. \(UNKNOWN_TABLE\)/is", $err_msg)
				)) {
				$options['query_counter'] = $query_counter + 1;

				$class_name = '\\'.$options['class_db'];
				$class_name::create_table();
				return $this->query($sql_str, $options);
			}

			$GLOBALS['lib']->log->write($sql_str."\n--".number_format($query_time, 6, '.', ' ')." sec\n{$err_msg}\n", 'sql_err.sql');

			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> $err_msg,
				'sql'	=> $sql_str,
			];
			throw new \Exception('custom exception');
		}

		if ($query_time>SQL_DURATION_LOG) {
			$controller = isset($GLOBALS['controller']) ? $GLOBALS['controller']['module'].'/'.$GLOBALS['controller']['controller'].'/'.$GLOBALS['controller']['method']."\n" : '';
			$GLOBALS['lib']->log->write($controller.$sql_str."\n--".number_format($query_time, 6, '.', ' ')." sec\n", 'sql_long.sql');
		}

		$list = [];
		$query_result = json_decode($query_result, true);
//p($query_result);
//		$this->rows_before_limit_at_least = empty($query_result['rows_before_limit_at_least']) ? 0 : $query_result['rows_before_limit_at_least'];

		if (!empty($query_result['data'])) foreach ($query_result['data'] as $row) {
			if (isset($options['row_function']))
				$options['row_function'] ($row);
			if (empty($options['no_answer']))
				if (!empty($options['key'])) {
					$list[$row[$options['key']]] = empty($options['field']) ? $row : $row[$options['field']];
				} else {
					$list[] = empty($options['field']) ? $row : $row[$options['field']];;
				}
		}

		return $list;
	}

	function data_quote($data) {
		if (is_null($data))
			return 'NULL';
		if (is_bool($data))
			return ($data ? 1 : 0);
		if (is_int($data) || is_float($data))
			return $data;

		if (!is_string($data)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> 'invalid argument: ' . print_r($data, true),
			];
			throw new \Exception('custom exception');
		}

		if (in_array($data, ['now()']))
			return $data;

		return "'".$this->escape_string($data)."'";
	}

	function field_quote($data) {
		$data = explode('.', $data);
		if (count($data)==2){
			return static::field_quote($data[0]).'.'.static::field_quote($data[1]);
		} elseif (count($data)==1){
			$data[0] = str_replace("#p#", /*$this->settings['name'].'.'.*/$this->settings['prefix'], $data[0]);
			return $this->escape_string($data[0]);
		}

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'error field name: ' . print_r($data, true),
		];
		throw new \Exception('custom exception');
	}

	function get_insert_id($table_name) {
		return false;
	}
	function insert($table_name, &$data) {
		$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name).
			" (".implode(', ', array_map([get_class(), 'field_quote'], array_keys($data))).') '.
			"VALUES (".implode(', ', array_map([get_class(), 'data_quote'], $data)).")";

		static::query($sql);
	}

	function update($table_name, &$data, $id) {
		return false;
	}
	function escape_string($data) {
		if (is_bool($data) || is_float($data) || is_int($data))
			return $data;

		if (is_string($data))
			return str_replace(["\n", "\r", "\\", "'", '"'], ["\\n", "\\r", "\\\\", "\'", "\""], $data);

		$GLOBALS['exception_err'] = [
			'err'	=> 'db error',
			'msg'	=> 'string or numeric should be.' . print_r($data, true),
		];
		throw new \Exception('custom exception');
	}
	function close() {
	}

	function table_exists($table) {
		return count($this->query("SHOW TABLES WHERE name='{$this->settings['prefix']}{$table}'"))>0;
	}

	protected function get_column_sql($f, $field_list) {
		$default = isset($field_list[$f]['order_by']);

		switch ($field_list[$f]['type']) {
			case 'stamp':
			case 'int':		$field_sql = $this->field_quote($f)." int(".(isset($field_list[$f]['size']) ? $field_list[$f]['size'] : 16).") NOT NULL DEFAULT 0"; break;
			case 'money':	$field_sql = $this->field_quote($f)." Float32 NOT NULL DEFAULT '0'";		break;
			case 'float':	$field_sql = $this->field_quote($f)." Float32 NOT NULL DEFAULT '0'";	break;
			case 'bool':	$field_sql = $this->field_quote($f)." bool NOT NULL DEFAULT 0";			break;
			case 'enum':
			case 'str':		$field_sql = $this->field_quote($f)." String ".($default ? 'NOT NULL' : 'DEFAULT NULL');	break;
			case 'json':
			case 'text':	$field_sql = $this->field_quote($f)." String ".($default ? 'NOT NULL' : 'DEFAULT NULL');	break;
			case 'date':	$field_sql = $this->field_quote($f)." Date ".($default ? 'NOT NULL' : 'DEFAULT NULL');		break;
			case 'datetime':$field_sql = $this->field_quote($f)." DateTime ".($default ? 'NOT NULL' : 'DEFAULT NULL');	break;
//			case 'time':	$field_sql = $this->field_quote($f)." int(16) ".($default ? 'NOT NULL' : 'DEFAULT NULL');	break;
			default: throw new \Exception('unknown field type '.$field_list[$f]['type']);
		}

		return $field_sql;
	}

	function add_column($table, $field_list, $f) {
/*		$table_name = $this->settings['prefix'].$table;

		$this->query("ALTER TABLE {$this->field_quote($table_name)} ADD COLUMN {$this->get_column_sql($f, $field_list)};");

		if (isset($field_list[$f]['ref']))
			$this->query(
				"ALTER TABLE {$this->field_quote($table_name)}
ADD CONSTRAINT {$this->field_quote($table_name."_{$f}_fkey")} FOREIGN KEY ({$this->field_quote($f)})
REFERENCES {$this->field_quote($this->settings['prefix'].$field_list[$f]['ref']::get_table_name())} ({$this->field_quote("id")}) ON DELETE SET NULL ON UPDATE CASCADE"
			);*/
	}
	function create_table($table, $field_list) {
//		$id_str = $table==='session';
		$table_name = $this->settings['name'].'.'.$this->settings['prefix'].$table;
		$fields_sql = '';
//		$constraints_sql = '';
		$order_by = [];

		foreach ($field_list as $f=>$r) {
//			if (isset($r['ref'])){
//				$ref_table_name = $this->settings['prefix'].$r['ref']::get_table_name();
//				$constraints_sql .= "CONSTRAINT fk_{$table_name}_{$f} FOREIGN KEY ({$f}) REFERENCES {$ref_table_name} (id) ON DELETE SET NULL,\n";
//			}

			$fields_sql.= $this->get_column_sql($f, $field_list).",\n";
			if (isset($r['order_by']))
				$order_by[$r['order_by']] = $f;
		}
		if (empty($order_by))
			throw new \Exception('no order_by fields');
		ksort($order_by);
		$sql_list = [
			'drop_table'	=> "DROP TABLE IF EXISTS ".$this->field_quote($table_name),
			'create_tbale'	=> "CREATE TABLE ".$this->field_quote($table_name)." (
".//$this->field_quote('id').' UUID '.
				"{$fields_sql}".//{$constraints_sql}PRIMARY KEY (id)
				") ENGINE = MergeTree() \n".
				"ORDER BY (".implode(', ', $order_by).")",
		];

		foreach ($sql_list as $sql)
			$this->query($sql);

		return true;
	}

	function create_index($table, $fields, $unique=false) {

	}

/*
	function get_insert_id($table_name) {
return null;
		return $this->db_o->insert_id;
	}

	function insert($table_name, &$data, $options=[]) {
return null;
		if (count($data)==0) {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name)." (".static::field_quote('id').") VALUES (NULL)";
		} else {
			$sql = "INSERT INTO ".static::field_quote('#p#'.$table_name).
				" (".implode(', ', array_map([get_class(), 'field_quote'], array_keys($data))).') '.
				"VALUES (".implode(', ', array_map([get_class(), 'data_quote'], $data)).")";
		}
		static::query($sql, $options);
		$data['id'] = $this->get_insert_id($table_name);
	}

	function update($table_name, &$data, $id, $options=[]) {
return null;
//			if ($updated) {
//				$now = gmdate("Y-m-d H:i:s");
//				$data['updated'] = $now;
//			}
		$field_values = [];
		foreach($data as $f=>$v)
			$field_values[] = static::field_quote($f)."=".static::data_quote($v);
		$sql = "UPDATE ".static::field_quote('#p#'.$table_name).
			" SET ".implode(', ', $field_values).
			" WHERE ".static::field_quote('id').'='.static::data_quote($id);
		static::query($sql, $options);
	}

	function escape_string($data) {
		if (is_string($data)) {
//			$data = \mysqli_real_escape_string(null, $data);
			$data = str_replace("'", "\\'", $data);
		}
		if (is_array($data)) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'db error',
				'msg'	=> 'string or numeric should be. array given. ' . print_r($data, true),
			];
			throw new \Exception('custom exception');
		}
		return $data;
	}
	function close() {
		$this->db_o->close();
	}

	function table_exists($table) {
return null;
		return count($this->query("SHOW TABLES LIKE '".$this->settings['prefix']."{$table}'"))>0;
	}

	function add_column($table, $field_list, $f) {
		$table_name = $this->settings['prefix'].$table;
		$this->query("ALTER TABLE {$this->field_quote($table_name)} ADD COLUMN {$this->get_column_sql($f, $field_list)};");

		if (isset($field_list[$f]['ref']))
			$this->query("ALTER TABLE {$this->field_quote($table_name)}
ADD CONSTRAINT {$this->field_quote($table_name."_{$f}_fkey")} FOREIGN KEY ({$this->field_quote($f)})
REFERENCES {$this->field_quote($this->settings['prefix'].$field_list[$f]['ref']::get_table_name())} ({$this->field_quote("id")}) ON DELETE SET NULL ON UPDATE CASCADE"
			);

//"ALTER TABLE {$this->field_quote($table_name)} DROP FOREIGN KEY {$this->field_quote($table_name."_{$f}_fkey")}"
//"ALTER TABLE {$this->field_quote($table_name)} DROP COLUMN {$this->field_quote($f)};"
	}

	function create_table($table, $field_list) {

	}


	function create_index($table, $fields, $unique=false, $options=[]) {
		$sql = "ALTER TABLE ".$this->field_quote('#p#'.$table)." ADD ".($unique?'UNIQUE':'INDEX')."(".implode(', ', array_map([$this, 'field_quote'], $fields)).")";
		return $this->query($sql);
	}
*/
}

if (isset($GLOBALS['conf']['db']['type'])) {
	if ($GLOBALS['conf']['db']['type']==='pg') {
		class db extends db_pg {};
	}

	if ($GLOBALS['conf']['db']['type']==='mysqli') {
		class db extends db_mysqli {};
	}

	if ($GLOBALS['conf']['db']['type']==='clickhouse') {
		class db extends db_clickhouse {};
	}
}
