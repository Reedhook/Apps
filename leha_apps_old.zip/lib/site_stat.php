<?php
namespace lib;

class site_stat {
	protected
		$stat = [
			'time_begin'	=> 0,
			'sql'			=> ['count'=>0, 'time'=>0],
			'curl'			=> ['count'=>0, 'time'=>0],
		],
		$ajax_out = false;


	function begin() {
		if($this->stat['time_begin']>0)
			return;
		$this->stat['time_begin'] = microtime(true);
	}

	function add_sql_time($time){
		$this->stat['sql']['count'] ++;
		$this->stat['sql']['time'] += $time;
	}
	function add_curl_time($time){
		$this->stat['curl']['count'] ++;
		$this->stat['curl']['time'] += $time;
	}

	function change() {// use only after session has started
		if (empty($_SESSION['stat_info'])) {
			$_SESSION['stat_info'] = true;
		} else {
			unset($_SESSION['stat_info']);
		}
		return !empty($_SESSION['stat_info']);
	}

	function report() {
		if (empty($GLOBALS['is_console']) && empty($_SESSION['stat_info']))
			return false;

		$php_time = microtime(true) - $this->stat['time_begin'];

		$time_format = function($t) {return $t>10 ? $GLOBALS['lib']->date_time->sec_to_sql_time($t) : number_format($t, 6, '.', ' ');};

		$this->stat['sql']['time_str'] = $time_format($this->stat['sql']['time']);
		$this->stat['curl']['time_str'] = $time_format($this->stat['curl']['time']);
		$report_data = [
			'request_time'	=> date('H:i:s', $this->stat['time_begin']) . '.'.round(fmod($this->stat['time_begin'], 1)*100),
			'url'	=> isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '',
			'php'	=> ['mem'=>bytes_format(memory_get_peak_usage()), 'time'=>$php_time, 'time_str'=>$time_format($php_time)],
			'sql'	=> $this->stat['sql'],
			'curl'	=> $this->stat['curl'],
		];
		if ($this->stat['curl']['count']===0)
			unset($report_data['curl']);

		if ($GLOBALS['is_console']) {
			unset($report_data['url']);
			foreach ($report_data as $k=>$r)
				if (is_array($r))
					$report_data[$k] = implode("\t", $r);
			return implode('',
				array_map(
					function($k, $v) {
						$l = strlen($k);
						return $k.":".str_repeat(' ', $l>16?0:16-$l)."{$v}\n";
					},
					array_keys($report_data),
					array_values($report_data)
				)
			);
		}
		return $report_data;
	}
}
