<?php
namespace lib;

class auth {
	// помещает данные текущего пользователя в $GLOBALS['user']
	function start($user_id=null) {
		if ($GLOBALS['is_console']) {
			$user_o = new \user\user_db();
			$user_list = \user\user_db::get_list(['filters'=>['role'=>'cron', 'constructor'=>true]]);
			if (count($user_list)>0) {
				$user_o->construct_by_data($user_list[0]);
			} else {
				$user_o->set_data([
					'role'		=> 'cron',
					'email'		=> 'cron',
				]);
				\user\user_db::set_log_changes(false);
				$user_o->save();
				\user\user_db::set_log_changes(true);
			}
			$GLOBALS['user'] = $user_o->get_data();
			$_SESSION['user_id'] = $user_o->id;
			return;
		}

		$user_id = $user_id ?? $_SESSION['user_id'] ?? -1;
		$user_list = \user\user_db::get_list(['filters'=>['id'=>$user_id, 'constructor'=>true]]);

		if (count($user_list)>0) {
			$GLOBALS['user'] = $user_list[0];
			$this->user_prepare($GLOBALS['user']);
		} else {
			$GLOBALS['user'] = [
				'id'			=> -1,
				'email'			=> null,
				'role'			=> 'guest',
			];
			unset ($_SESSION['user_id']);
		}
	}

	// проверяет текущего пользователя
	function user_prepare (&$user_data, $return=false) {
		foreach (['block'] as $f)
			$user_data[$f] = to_bool($user_data[$f]);

		foreach (['id'] as $f)
			$user_data[$f] = intval($user_data[$f]);

		$GLOBALS['user']['properties'] = empty($GLOBALS['user']['properties']) ? [] : json_decode($GLOBALS['user']['properties'], true);

		$err_msg = false;

		if ($user_data['block'])
			$err_msg = lang('user_blocked');

		if ($err_msg) {
			if ($return)
				return false;
			\user\user_db::logout();
			session_write_close();
			if (empty($GLOBALS['REQUEST_JSON'])) {
				echo $err_msg;
			} else {
				\output::ajax([
					'success'	=> false,
					'err_code'	=> 'auth_err',
					'msg'		=> $err_msg,
				]);
			}
			die();
		}
		return true;
	}
}
