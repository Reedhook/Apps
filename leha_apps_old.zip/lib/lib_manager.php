<?php
class lib_manager {
	protected $lib_list =[];

	protected function connect_lib($lib_name) {
//		if (empty($this->lib_list[$lib_name])) {
			require_once "lib/{$lib_name}.php";

			$class_name = '\\lib\\'.$lib_name;

			if(!class_exists($class_name)){
				$GLOBALS['exception_err'] = [
					'err'	=> 'lib error',
					'msq'	=> 'unknown lib: '.p($class_name, true),
				];
				throw new \Exception('custom exception');
			}

			$this->lib_list[$lib_name] = new $class_name();
//		}
	}

	function __get($lib_name) {
		if(!isset($this->lib_list[$lib_name]))
			$this->connect_lib($lib_name);

		return $this->lib_list[$lib_name];
	}

}
