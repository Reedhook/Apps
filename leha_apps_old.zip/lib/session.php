<?php
namespace lib;
class session {
	protected $session = false;
	function get_session_data() {
		return $this->session ? $this->session->get_data() : false;
	}

	function start() {
		session_set_save_handler(
			[$this, 'open'],
			[$this, 'close'],
			[$this, 'read'],
			[$this, 'write'],
			[$this, 'destroy'],
			[$this, 'garbage_collector']
		);
		session_name($GLOBALS['conf']['session']['session_name']);
		session_start();
	}

	protected function get_session($session_id) {
		if ($this->session===false) {
			$this->session = new \session_db();
			$list = \session_db::get_list(['filters'=>['id'=>$session_id]]);

			if(count($list)>0) {
/*				if ($list[0]['user_ip']!==\session_db::get_ip()) {
					$GLOBALS['exception_err'] = [
						'err'	=> 'session error',
						'msq'	=> 'same user_id',
					];
					throw new \Exception('custom exception');
				}*/
				$this->session->construct_by_data($list[0]);
			} else {
				$this->session->set_id($session_id);
			}
		}
		return $this->session;
	}

	function open($session_path, $session_name) {
		return true;
	}

	function close() {
		return true;
	}

	function read($session_id) {
		if ($GLOBALS['no_session'])
			return '';

		$session_o = $this->get_session($session_id);
		return is_null($session_o->content) ? '' : $session_o->content;
	}

	function write($session_id, $data) {
		if ($GLOBALS['no_session'])
			return true;

		if(isset($GLOBALS['lib']) && is_object($GLOBALS['lib']->db)) {
			$session_o = $this->get_session($session_id);
			$session_o->save(['content' => $data]);
			$GLOBALS['lib']->db->close();
		}
		return true;
	}

	function destroy($session_id) {
		if ($GLOBALS['no_session'])
			return true;

		$session_o = $this->get_session($session_id);
		$session_o->delete(true);
		return true;
	}

	function garbage_collector($maxlifetime) {
//		if ($GLOBALS['no_session'])
//			return true;

		//$GLOBALS['lib']->log->write($maxlifetime."\n", 'session_garbage_collector.txt');// todo remove this row
//		$session_time_over = gmdate("Y-m-d H:i:s+00", time()-$GLOBALS['conf']['session']['session_timeout']);
		$session_time_over = $GLOBALS['lib']->date_time->to_sql(time()-$GLOBALS['conf']['session']['session_timeout']);
		$GLOBALS['lib']->db->query("DELETE FROM ".$GLOBALS['lib']->db->field_quote('#p#session')." WHERE updated < ".$GLOBALS['lib']->db->data_quote($session_time_over));
		return true;
	}
}
