<?php
namespace lib;

// блокиратор процессов по файлу
class process_blocker {
	protected $lock_handle = null; // указатель на файл блокировки

	//-- делаем блокировку, что бы параллельные процессы ожидали окончания текущего процесса
	function block($lock_name='') {
		$lock_file = "cache/{$lock_name}.lock"; // название фала блокировки
		if (!file_exists($lock_file)) { // если файл не существует, создаём его
			file_put_contents($lock_file, '');
			chmod($lock_file, 0777);
		}

		$this->lock_handle = fopen($lock_file, 'r'); // создаём указатель на файл (открываем файл для чтения)
		while(!flock($this->lock_handle, LOCK_EX)) // пытаемся заблокировать файл, если он уже заблокирован ждём разблокировки
			sleep(1);
	}

	//-- снять блокировку, что бы параллельные ожидающие процессы могли продолжить выполняться
	function unblock() {
		flock($this->lock_handle, LOCK_UN); // снимаем блокировку с файла
		fclose($this->lock_handle); // закрываем файл
		$this->lock_handle = null;
	}
}
