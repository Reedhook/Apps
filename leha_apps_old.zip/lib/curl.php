<?php
namespace lib;

class curl {
	function request($url, $method='post', $data=null, $options=[]) {
		$start_time = microtime(true);
		$ch = curl_init();

		if ($method==='get') {
			curl_setopt($ch, CURLOPT_HTTPGET, true);
			if (!empty($data)) {
				foreach ($data as $k=>&$v)
					$v = "{$k}=".(is_bool($v) ? ($v?'true':'false') : $v);
				$url .= (strpos($url, '?')===false?'?':'&').implode('&', $data);
			}
		}

		if ($method==='get_json') {
//			curl_setopt($ch, CURLOPT_HTTPGET, true); // для сброса метода HTTP-запроса на метод GET. Так как GET используется по умолчанию, этот параметр необходим только в случае, если метод запроса был ранее изменён.
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
			if (!isset($options['header']))
				$options['header'] = [];
			$options['header'][] = 'Accept: application/json';
			$options['header'][] = 'Content-Type: application/json';
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		}

		if ($method==='post') {
			curl_setopt($ch, CURLOPT_POST, true);
			if (!empty($data))
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		}

		if ($method==='put_json') {
//			curl_setopt($ch, CURLOPT_PUT, true); // загрузки файла методом HTTP PUT
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PUT');
			if (!isset($options['header']))
				$options['header'] = [];
			$options['header'][] = 'Accept: application/json';
			$options['header'][] = 'Content-Type: application/json';
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		}

		if ($method==='json') {
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');

			if (!isset($options['header']))
				$options['header'] = [];
			$options['header'][] = 'Accept: application/json';
			$options['header'][] = 'Content-Type: application/json';
//			$options['header'][] = 'Content-Length: ' . strlen($data);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
		}

		if (!empty($options['header']))
			curl_setopt($ch, CURLOPT_HTTPHEADER, $options['header']);

		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		if (!empty($options['redirect'])) {
			curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
			curl_setopt($ch, CURLOPT_MAXREDIRS, 20);
		}

		if (!empty($options['get_header']))
			curl_setopt($ch, CURLOPT_HEADER, true);

		if (!empty($options['http_1']))
			curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);

		if (!empty($options['cookie_file'])) {
			if (file_exists($options['cookie_file']))
				curl_setopt($ch, CURLOPT_COOKIEFILE, $options['cookie_file']);
			curl_setopt($ch, CURLOPT_COOKIEJAR, $options['cookie_file']);
		}

		if (!empty(($options['userpwd']))) {
//			curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
			curl_setopt($ch, CURLOPT_USERPWD, $options['userpwd']);
//			curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		}

		$this->response = curl_exec($ch);
		$this->httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

		$header_size = empty($options['get_header']) ? 0 : curl_getinfo($ch, CURLINFO_HEADER_SIZE);

		$this->error = curl_error($ch);
		curl_close($ch);

		if (!empty($options['cookie_file']))
			@chmod($options['cookie_file'], 0777);

		$this->header = false;
		if (!empty($options['get_header'])) {
			$this->header = substr($this->response, 0, $header_size);
			$this->response = substr($this->response, $header_size);
		}

		if (!empty($options['win_to_utf']))
			$this->response = mb_convert_encoding($this->response, "utf-8", "windows-1251");

		$GLOBALS['lib']->site_stat->add_curl_time(microtime(true)-$start_time);

		if (!empty($options['sleep']))
			usleep($options['sleep']);

// 429 - пользователь отправил слишком много запросов за последнее время
// 500 - сервер столкнулся с неожиданной ошибкой
		return $this->httpcode===200 || $this->httpcode===500 || $this->httpcode===422 ? $this->response : false;
	}

	protected $error = false;
	protected $header = false;
	protected $httpcode = false;
	protected $response = false;

	function __get($attribute) {
		if (property_exists($this, $attribute))
			return $this->$attribute;
		return false;
	}
}
