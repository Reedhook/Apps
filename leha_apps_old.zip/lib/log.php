<?php
namespace lib;
class log {
	function write(string $data, string $log_file = 'log.txt') {
		$file = __DIR__.'/../log/'.$log_file;
		$file_exists = file_exists($file);
		file_put_contents($file, (substr($log_file,-3)==='sql'?'--':'').gmdate("Y-m-d H:i:s")."\n".p($data, true)."\n", FILE_APPEND);
		if (!$file_exists)
			chmod($file, 0777);
	}
}
