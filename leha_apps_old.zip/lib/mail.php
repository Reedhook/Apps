<?php
namespace lib;
require_once 'external_soft/PHPMailer_v5.1/class.phpmailer.php';
require_once 'external_soft/PHPMailer_v5.1/class.pop3.php';
require_once 'external_soft/PHPMailer_v5.1/class.smtp.php';
//require_once 'external_soft/PHPMailer/PHPMailer.php';
//require_once 'external_soft/PHPMailer/SMTP.php';
//require_once 'external_soft/PHPMailer/Exception.php';

class mail {
	protected $mail_o = null;
	protected $err_msg = '';
	function get_err_msg() {
		return $this->err_msg;
	}
	function __construct() {
//		$this->mail_o = new \PHPMailer\PHPMailer\PHPMailer();
		$this->mail_o = new \PHPMailer();
		if($GLOBALS['conf']['mail']['smtp']){
			$this->mail_o->IsSMTP();
//			$this->mail_o->isMail();
//			$this->mail_o->isSendmail();
			$this->mail_o->Host			= $GLOBALS['conf']['mail']['smtp_host'];
			$this->mail_o->Port			= $GLOBALS['conf']['mail']['smtp_port'];
			$this->mail_o->SMTPAuth		= $GLOBALS['conf']['mail']['smtp_auth'];
			$this->mail_o->Username		= $GLOBALS['conf']['mail']['smtp_username'];
			$this->mail_o->Password		= $GLOBALS['conf']['mail']['smtp_password'];
			$this->mail_o->SMTPDebug	= $GLOBALS['conf']['mail']['smtp_debug'];
			$this->mail_o->SMTPSecure	= 'ssl';//'tls';
			$this->mail_o->CharSet		= $GLOBALS['conf']['site']['code'];
/*
настройки для gmail:
лезете в google  настройки, отключение капчи: https://accounts.google.com/DisplayUnlockCaptcha
включаете доступ к непроверенным приложениям: https://www.google.com/settings/security/lesssecureapps
*/
		}
	}

	function send($o) {
		$this->err_msg = '';

		$fields = [
			'from_mail'	=> $GLOBALS['conf']['mail']['smtp_username'],
			'from_name'	=> '',
			'to_mail'	=> '',
			'to_name'	=> '',
			'subject'	=> '',
			'body'		=> '',
		];
		foreach($fields as $f=>$v)
			if(!isset($o[$f]))
				$o[$f] = $v;

		$o['status'] = \mail\setting_db::get_setting('mail_cron') ? 'wait' : ($this->real_send($o) ? 'sent' : 'error');
		$o['error'] = $this->err_msg;
		(new \mail\mail_db())->save($o);

		return $o['status'];
	}

	function real_send($o) {
		$this->err_msg = '';

		if (!empty($GLOBALS['conf']['mail']['mail_limiter'])) {
			$mail_access = false;
			foreach ($GLOBALS['conf']['mail']['mail_limiter'] as $mail)
				if (strpos($o['to_mail'], $mail)!==false) {
					$mail_access = true;
					break;
				}
			if (!$mail_access) {
				$this->err_msg = 'mail_limiter';
				return false;
			}
		}

		$this->mail_o->SetFrom(empty($o['from_mail']) ? $GLOBALS['conf']['mail']['smtp_username'] : $o['from_mail'], empty($o['from_name']) ? '' : $o['from_name']);
		$this->mail_o->AddAddress($o['to_mail'], empty($o['to_name']) ? '' : $o['to_name']);
		$this->mail_o->IsHTML(isset($o['is_html']) ? $o['is_html'] : true);
		$this->mail_o->Subject = htmlspecialchars($o['subject']);
		$this->mail_o->MsgHTML($o['body']);
		if (!empty($o['attachment']))
			foreach($o['attachment'] as $a)
				$this->mail_o->addAttachment($a['file'], empty($a['name']?$a['name']:''));

		ob_start();
		try {
			$res = $this->mail_o->Send() ? 1 : 0;
			if(empty($o['status']))
				$this->err_msg = $this->mail_o->ErrorInfo;
		} catch (phpmailerException $e) {
			$res = 0;
			$this->err_msg = $e->errorMessage();
		} catch (Exception $e) {
			$res = 0;
			$this->err_msg = $e->getMessage();
		}
		@ob_end_clean();

		$this->mail_o->ClearAddresses();
		$this->mail_o->ClearCCs();
		$this->mail_o->ClearBCCs();
		$this->mail_o->ClearReplyTos();
		$this->mail_o->ClearAllRecipients();
		$this->mail_o->ClearAttachments();
		$this->mail_o->ClearCustomHeaders();

		return $res;
	}

/*	protected function address($data) {
		if (!is_array($data)) {
			$this->mail_o->AddAddress($data);
			return;
		}

		if(isset($data['email'])) {
			$this->mail_o->AddAddress($data['mail'], isset($data['name']) ? $data['name'] : '');
		} else {
			foreach($data as $i)
				$this->address($i);
		}
	}

	protected function reply($data) {
		if (!is_array($data)) {
			$this->mail_o->AddReplyTo($data);
			return;
		}

		if(isset($data['email'])) {
			$this->mail_o->AddReplyTo($data['mail'], isset($data['name']) ? $data['name'] : '');
		} else {
			foreach($data as $i)
				$this->reply($i);
		}
	}

	protected function attachment($data){
		if(!is_array($data))
			return false;

		if(isset($data['file_path']) && isset($data['file_name'])){
			$this->mail_o->AddAttachment($data['file_path'], $data['file_name']);
		} else {
			foreach($data as $i)
				$this->attachment($i);
		}
	}
*/
}