<?php
namespace lib;
class image {

	/**
	 * изменяет размер изображения
	 *
	 * создает изображение указанного размера (блока) и записывает в указанный файл или возвращет в объекте GdImage
	 *
	 * @param array $options = [
	 * int	$width	- ширина указанной картинки. если 0, то пропорционально от указанной высоты
	 * int	$height	- высота указанной картинки. если 0, то пропорционально от указанной ширины
	 * bool	$cover	- если true, изображение обрезается так, чтобы весь блок был заполнен, иначе изображение вписывается в указанный блок
	 * str	source	- путь до исходного файла
	 * str	dest	- путь указанного файла. если не указан, то функция возвращает объект GdImage, который потом следует удалить функцией imagedestroy
	 * ]
	 *
	 * @return bool | GdImage
	**/
	function resize($options) {
		if (!empty($options['dest'])) {
			$dest_info = pathinfo($options['dest']);
			if (!file_exists($dest_info['dirname'])) // создает деррикторию к указанному файлу
				if (!mkdir($dest_info['dirname'], 0777, true)){
					$GLOBALS['exception_err'] = [
						'err'	=> 'make dir error',
						'msg'	=> "can't create dir: ".p($dest_info['dirname'], true),
					];
					throw new \Exception('custom exception');
				}
		}

		$result = @getimagesize($options['source']);
		if (!$result)
			return false;

		list($w1, $h1, $type_orig) = $result;

		$img_orig =
			$type_orig==1 ? imagecreatefromgif($options['source']) :
			($type_orig==2 ? imagecreatefromjpeg($options['source']) :
			($type_orig==3 ? imagecreatefrompng($options['source']) : null));

		if (!$img_orig)
			return false;

		$w2 = $options['width']>0	? $options['width']		: $w1;
		$h2 = $options['height']>0	? $options['height']	: $h1;

		$kw = $w2/$w1;
		$kh = $h2/$h1;

		$k['in'] = min($kw, $kh);	// коэффициен, что бы вписать картинку в прямоугольник
		$k['out'] = max($kw, $kh);	// коэффициен, что бы опписАть картинку вокруг прямоугольника

		$cover = !empty($options['cover']);
		$src_w	= $cover ? $w2/$k['out']	: $w1;
		$src_h	= $cover ? $h2/$k['out']	: $h1;
		$src_x	= $cover ? ($w1-$src_w)/2	: 0;
		$src_y	= $cover ? ($h1-$src_h)/2	: 0;

		$dst_w	= $cover ? $w2	: $w1*$k['in'];
		$dst_h	= $cover ? $h2	: $h1*$k['in'];

		$img = imagecreatetruecolor($dst_w, $dst_h);
		if ($type_orig==3) {
			imageAlphaBlending($img, false);
			imageSaveAlpha($img, true);
		}
		imageCopyResampled($img, $img_orig, 0, 0, $src_x, $src_y, $dst_w, $dst_h, $src_w, $src_h);
		imagedestroy($img_orig);

		if(!empty($options['dest'])) {
			$fn = $type_orig==3 ? 'imagepng' : 'imagejpeg';
			$quality = $type_orig==3 ? -1 : 90;
			if (!$fn($img, $options['dest'], $quality))
				throw new Exception($fn.' error');
			chmod($options['dest'], 0777);
			imagedestroy($img);
			return true;
		}

		return $img;
	}
}