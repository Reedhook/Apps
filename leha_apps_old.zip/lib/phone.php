<?php
namespace lib;
class phone {
	static $formats = [
		0	=> "+7 123 456-78-90",
		1	=> "+7 123 456 78 90",
		2	=> "+7 (1234) 56-78-90",
	];

	function to_sql($str) {
		$str = trim($str);
		if (substr($str, 0, 1)==='8')// заменяем первую 8 на +7
			$str = '+7'.substr($str, 1);

		if (substr($str, 0, 1)!=='+')// номер должен начинаться с '+'
			$str = '+'.$str;

		$str = '+'.preg_replace('/([^\d]+)/', '', $str); // удаляем все не цифры

		if ($str==='+')
			return false;

		return $str;
	}

	function is_valid($str) {
		return preg_match('/^\+\d{11,}$/', $str); // '+' и не менее 11 цифр
	}

	function to_format($str) {
		if (empty($str))
			return '';
		$format = \site\setting_db::get_setting('phone_format');
		if ($format === 0) //	+78007001191 > +7 800 700-11-91
			return substr($str, 0, 2).' '.substr($str, 2, 3).' '.substr($str, 5, 3).'-'.substr($str, 8, 2).'-'.substr($str, 10, 2).(strlen($str)>12?' '.substr($str, 12):'');
		if ($format === 1) //	+78007001191 > +7 800 700 11 91
			return substr($str, 0, 2).' '.substr($str, 2, 3).' '.substr($str, 5, 3).' '.substr($str, 8, 2).' '.substr($str, 10, 2).(strlen($str)>12?' '.substr($str, 12):'');
		if ($format === 2) //	+78007001191 > +7(8007) 00-11-91
			return substr($str, 0, 2).' ('.substr($str, 2, 4).') '.substr($str, 6, 2).'-'.substr($str, 8, 2).'-'.substr($str, 10, 2).(strlen($str)>12?' '.substr($str, 12):'');
		return $str;
	}
}
