<?php
namespace lib;
class hash{
	static protected
		$bytes		= false, // array[0-7] = [0=>0b00000001, 2=>0b00000010, ... 7=>0b10000000];
		$bit_count	= false; // array[0-255] = [0b00000000=>0, 0b00000001=>1, ..., 0b10010001=>3, ..., 0b11111111=>8];

	static protected function prepare_bytes () {
		if(static::$bytes)
			return;

		for($j=0; $j<8; $j++)
			static::$bytes[$j] = 1<<$j;
	}
	static protected function prepare_bit_count () {
		if(static::$bit_count)
			return

		static::prepare_bytes();
		for($i=0; $i<256; $i++) {
			$count = 0;
			for($j=0; $j<8; $j++)
				if(($i>>$j)&1)
					$count ++;
			static::$bit_count[$i] = $count;
		}
	}

	public function get_image_hash ($scale, $file_name) {
		$img = $GLOBALS['lib']->image->resize($file_name, ['w'=>$scale, 'h'=>$scale, 'fit'=>'cover']);

		$average = 0; // average color (for grey color is average tone)
		$colors		= [];
		$colors_k = 0;
		for($i=0; $i<$scale; $i++)
			for($j=0; $j<$scale; $j++) {
				$c = imagecolorat($img, $i, $j);
				$g = (int)((($c&255)+($c>>8&255)+($c>>16&255))/3); // grey = red + green + blue / 3
				$colors[$colors_k++] = $g;
				$average += $g;
			}
		imagedestroy($img);
		$average = (int)($average/$scale/$scale);

		static::prepare_bytes();

		$str = '';
		$colors_k=0;
		$l=$scale*$scale;
		while($colors_k<$l){
			$byte = 0;
			for($j=0; $j<8; $j++)
				if(($colors[$colors_k++]>=$average))
					$byte = $byte | static::$bytes[$j];
			$str .= chr($byte);
		}
		return $str;
	}

	public function get_hash_dif ($scale, $h1, $h2) {
		static::prepare_bit_count();
		$res = 0;
		$l=$scale*$scale/8;
		for($i=0; $i<$l; $i++)
			$res += static::$bit_count[(ord($h1[$i]) ^ ord($h2[$i]))];

		return $res;
	}
}