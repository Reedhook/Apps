<?php
namespace lib;
class file {
	function get_dir_map($dir){
		$dir_map = [];
		$this->_get_dir_map($dir, $dir_map);
		return $dir_map;
	}
	protected function _get_dir_map($dir, &$dir_map){
		$dir_map[] = $dir;
		$dir_list = $this->read_dir($dir, ['is_dir'=>true]);
		foreach($dir_list as $d)
			$this->_get_dir_map($dir.$d.'/', $dir_map);
	}

	function get_folders(){
		$dir_list = $this->read_dir($GLOBALS['conf']['pic']['dir'], ['is_dir'=>true]);
		return $dir_list;
	}

	function get_galleries($dir_n){
		$dir = $GLOBALS['conf']['pic']['dir'].$dir_n;
		$galleries = [];
		$file_list = $this->read_dir($dir);
		foreach($file_list as $f){
			if($f['is_dir']){
			} else {
				list($gallery_n, $file_n) = explode('_', substr($f['file'], 0, 9));
				$galleries[$gallery_n][$file_n] = [
					'dir_n'		=> $dir_n,
					'gallery_n'	=> $gallery_n,
					'file_n'	=> $file_n,
					'file'		=> $f['file'],
					'orig_path'	=> $dir,
				];
			}
		}
		return $galleries;
	}

/*	function get_image($local_path, $file){
		$origin_file = $GLOBALS['conf']['pic']['dir'].$local_path.$file;
		if(file_exists($origin_file)){
			$path_parts = pathinfo($origin_file);
			return [
				'origin_file'	=> $origin_file,
				'file_name'		=> $path_parts['filename'],
				'extension'		=> $path_parts['extension'],
				'local_path'	=> $local_path,
			];
		}
		return false;
	}
*/
	function read_dir($dir, $options=[]){
		$list = [];
		if (is_dir($dir)) {
			if ($dh = opendir($dir)) {
				while (($file_name = readdir($dh)) !== false) {
					if(in_array($file_name, ['.', '..']) || is_link($dir.$file_name))
						continue;

					$is_dir = is_dir($dir.$file_name);

					if(isset($options['is_dir']) && (($options['is_dir'] && !$is_dir) || (!$options['is_dir'] && $is_dir)))
						continue;

					if(!empty($options['mask']) && !preg_match('/^'.$options['mask'].'$/', $file_name))
						continue;

					if(isset($options['ext'])) {
						$path_parts = pathinfo($file_name);
						if(is_array($options['ext'])){
							if (!in_array(strtolower($path_parts['extension']), $options['ext']))
								continue;
						} else {
							if (strtolower($path_parts['extension'])!=$options['ext'])
								continue;
						}
					}

//					if (!empty($options['key']))
//						$list[$file_name[$options['key']]] = $file_name;
//					else
						$list[] = $file_name;
				}
				closedir($dh);
			}
		}
		if (empty($options['pathinfo']) && empty($options['imginfo']))
			sort($list);
		else
			uasort($list, function($a1, $a2){return strcmp($a1['basename'], $a2['basename']);});
		return $list;
	}

	function get_dir_tree($dir=null, $local_path='') {
		if(!$dir) {
			$dir = $GLOBALS['conf']['pic']['dir'];
			return [[
				'file_name'		=> basename($dir),
				'sub'			=> $this->get_dir_tree($dir, ''),
				'local_path'	=> '',
			]];
		}

		$dir_list = [];
		$file_list = $this->read_dir($dir, ['is_dir'=>true]);
		foreach($file_list as $f)
			$dir_list[] = [
				'file_name'		=> $f,
				'sub'			=> $this->get_dir_tree($dir.$f.'/', $local_path.$f.'/'),
				'local_path'	=> $local_path.$f.'/'
			];

		return $dir_list;
	}

	function create_dir($dir, $options=[]) { // создаёт папку, если не существует
		if (!file_exists($dir)) {
			if (mkdir($dir, 0777, true)) {
				chmod($dir, 0777);

				if (isset($options['htaccess'])) {
					$htacces_file_name = $dir.'.htaccess';
					file_put_contents($htacces_file_name, "<Files *>\nOrder Allow,Deny\n".($options['htaccess']?"Allow":"Deny")." from All\n</Files>");
					chmod($htacces_file_name, 0777);
				}

			} else {
				return false;
			}
		}
		return true;
	}

	function delete_dir($dir) {
		if (is_dir($dir)) {
			if ($dh = opendir($dir)) {
				while (($file_name = readdir($dh)) !== false) {
					if(in_array($file_name, ['.', '..']))
						continue;

					$file_name = $dir.DIRECTORY_SEPARATOR.$file_name;

					if (is_link($file_name)) {
						unlink($file_name);
					} else if (is_dir($file_name)) {
						$this->delete_dir($file_name.DIRECTORY_SEPARATOR);
					} else {
						unlink($file_name);
					}
				}
			}
			rmdir($dir);
		}
	}

}
