<?php
namespace lib;
require_once 'external_soft/smarty-3.1.27/Smarty.class.php';

class Smarty_Resource_Global extends \Smarty_Resource_Custom {// global resource
	protected function fetch($name, &$source, &$mtime) {
		$source = isset($GLOBALS[$name]) ? $GLOBALS[$name] : null;
		$mtime = $source ? time() : null;
	}
	protected function fetchTimestamp($name) {
		return time();
	}
}

class smarty {
	protected $obj = null;
	function __construct() {
		$this->obj = new \Smarty();

		$this->obj->template_dir	= './view';
		$this->obj->compile_dir		= './cache/templates';
		$this->obj->cache_dir		= './cache';
		$this->obj->config_dir		= './conf';
		$this->obj->error_reporting= E_ALL & ~E_NOTICE;
		//$this->obj->debugging = true;
		//$this->obj->caching = true;
		//$this->obj->cache_lifetime = 120;
		//$this->obj->force_compile = true;

		$this->obj->registerResource("gl", new Smarty_Resource_Global());
	}

	public function assign($tpl_var, $value = null, $nocache = false) {
		return $this->obj->assign($tpl_var, $value, $nocache);
	}
	public function display($template = null, $cache_id = null, $compile_id = null, $parent = null) {
		$previous_error_handler = set_error_handler(['Smarty', 'mutingErrorHandler']);
		$res = $this->obj->display($template, $cache_id, $compile_id, $parent);
		set_error_handler($previous_error_handler);
		return $res;
	}

	public function fetch($template = null, $cache_id = null, $compile_id = null, $parent = null, $display = false, $merge_tpl_vars = true, $no_output_filter = false) {
		$previous_error_handler = set_error_handler(null);
		$res = $this->obj->fetch($template, $cache_id, $compile_id, $parent, $display, $merge_tpl_vars, $no_output_filter);
		set_error_handler($previous_error_handler);
		return $res;
	}
}
