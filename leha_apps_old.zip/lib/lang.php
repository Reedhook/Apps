<?php
namespace lib;

class lang {
	protected $value = 'en';
	protected $list = ['en', 'ru'];
	protected $destination = 'lang';

	function __construct($id=null) {
		$lang = null;
		if (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $this->list)) {
			$lang = $_SESSION['lang'];
		} elseif (isset($_SERVER['HTTP_ACCEPT_LANGUAGE'])) {
			// https://habr.com/ru/post/159129/
			// https://www.iana.org/assignments/language-subtag-registry/language-subtag-registry
			$list = strtolower($_SERVER['HTTP_ACCEPT_LANGUAGE']);
			if (preg_match_all('/([a-z]{1,8}(?:-[a-z]{1,8})?)(?:;q=([0-9.]+))?/', $list, $lan_list)) {
				$lan_list = array_combine($lan_list[1], $lan_list[2]); // [ln=>weight, ...] (, weight 0-1)

				foreach ($lan_list as $n => $v)
					$lan_list[$n] = $v==='' ? 1 : floatval($v);
				arsort($lan_list, SORT_NUMERIC);
				foreach ($lan_list as $l=>$q) {
					//$s = strtok($l, '-');// убираем то что идет после тире в языках вида "en-us, ru-ru"
					$s = strtolower(explode('-', $l)[0]);// убираем то что идет после тире в языках вида "en-us, ru-ru"
					if (in_array($s, $this->list)) {
						$lang = $s;
						break;
					}
				}
			}
		}
		$_SESSION['lang'] = $this->value = $lang ?? \site\setting_db::get_setting('lang');
	}

	function add($dict) {
		if(!isset($GLOBALS[$this->destination]))
			$GLOBALS[$this->destination] = [];
		if (isset($dict[$this->value]))
			$GLOBALS[$this->destination] = array_merge($GLOBALS[$this->destination], $dict[$this->value]);

		if(!isset($GLOBALS['lang_en']))
			$GLOBALS['lang_en'] = [];
		if (isset($dict['en']))
			$GLOBALS['lang_en'] = array_merge($GLOBALS['lang_en'], $dict['en']);
	}

	function __set($attribute, $value) {
		if (in_array($attribute, ['value', 'destination']))
			return $this->$attribute = $value;

		static::attribute_err($attribute);
	}

	function __get($attribute) {
		if (property_exists($this, $attribute))
			return $this->$attribute;

		static::attribute_err($attribute);
	}

	function __isset($attribute) {
		if (property_exists($this, $attribute))
			return isset($this->$attribute);

		static::attribute_err($attribute);
	}

	function __unset($attribute) {
		if ($attribute==='value')
			unset($this->value);

		static::attribute_err($attribute);
	}

	protected static function attribute_err($attribute) {
		$GLOBALS['exception_err'] = [
			'err'	=> 'lang error',
			'msg'	=> 'unknown attribute: '.p($attribute, true),
		];
		throw new \Exception('custom exception');
	}
}
