<?php
namespace lib;

use PHPMailer\PHPMailer\Exception;

class imap {
	protected $connection = false;

	function connect($options) { // $mailbox, $user, $password,
		$this->connection = @\imap_open(
			$options['mailbox'],
			$options['user'],
			$options['password'],
			OP_READONLY//,
//			0,
//			[]
		);
		if (!$this->connection) {
			$GLOBALS['exception_err'] = [
				'err'	=> 'imap error',
				'msg'	=> imap_last_error(),
			];
			throw new \Exception('custom exception');
		}
	}

	function close() {
		imap_close($this->connection);
	}

	function num_msg() {
		return imap_num_msg($this->connection);
	}

	function msg_num($num_msg, $part_num=0) {
		$structure = imap_fetchstructure($this->connection, $num_msg);

		if (isset($structure->parts) && is_array($structure->parts) && isset($structure->parts[$part_num])) {
			//foreach ($structure->parts as $part_num=>$i) {
			$encoding = $structure->parts[$part_num]->encoding;
			$message = imap_fetchbody($this->connection, $num_msg, $part_num+1);
		} else {
			$encoding = $structure->encoding;
			$message = imap_fetchbody($this->connection, $num_msg, 1);
		}

		switch ($encoding) {
			case 0:
				$message = imap_8bit($message);
			case 1:
				$message = imap_8bit($message);
			case 2:
				$message = imap_binary($message);
			case 3:
				$message = imap_base64($message);
			case 4:
				$message = quoted_printable_decode($message);
			case 5:
		}
		return $message;

	}


//	function

	function help() {
		return <<<END
yandex: 
mailbox: {imap.gmail.com:993/imap/ssl}INBOX
используйте пароль для приложений: https://yandex.ru/support/id/authorization/app-passwords.html

google: 
mailbox: {imap.yandex.ru:993/imap/ssl}INBOX
разрешите доступ для ненадёжных приложений
\n
END;
	}
}
