<?php
return [
	'login'			=> ['user', 'login'],
	'logout'		=> ['user', 'login', 'logout'],
	'download'		=> ['apps', 'release', 'download'],

	'.env'			=> ['site', 'block_ip', 'block_me'],
];