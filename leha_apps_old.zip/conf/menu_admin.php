<?php
$GLOBALS['menu_admin'] = [
	'modules' => [
		'title'		=> 'modules',
		'className'	=> 'icon icon-left-h36 sitemap',
		'access'	=> ['root', 'admin'],
		'sub'		=> [
			'user'=> [
				'title'		=> 'users',
				'className'	=> 'icon icon-left-h30 users',
				'access'	=> ['root', 'admin'],
				'sub'		=> [
					'user'	=> [
						'title'		=> 'users',
						'className'	=> 'icon icon-left-h30 users',
						'access'	=> ['root', 'admin'],
						'url'		=> 'user/user',
					],
					'user_group'	=> [
						'title'		=> 'group_list',
						'access'	=> ['root', 'admin', 'manager'],
						'url'		=> 'user/group',
					],
					'user_registration'	=> [
						'title'		=> 'user_registration_list',
						'className'	=> 'icon icon-left-h30 user-plus',
						'access'	=> ['root', 'admin'],
						'url'		=> 'user/user_registration',
					],
					'user_auth'	=> [
						'title'		=> 'user_auth_list',
						'className'	=> 'icon icon-left-h30 sign-in',
						'access'	=> ['root', 'admin'],
						'url'		=> 'user/user_auth',
					],
					'confirm_list'	=> [
						'title'		=> 'confirm_list',
						'className'	=> 'icon icon-left-h30 mail',
						'access'	=> ['root', 'admin'],
						'url'		=> 'user/confirm',
					],
				],
			],
			'site'	=> [
				'title'		=> 'site',
				'className'	=> 'icon icon-left-h30 cogs',
				'access'	=> ['root', 'admin'],
				'sub'		=> [
					'settings'	=> [
						'title'		=> 'settings',
						'access'	=> ['root', 'admin'],
						'url'		=> 'site/settings',
					],
					'files'	=> [
						'title'		=> 'file_list',
						'access'	=> ['root', 'admin'],
						'url'		=> 'core/file',
					],
					'log'	=> [
						'title'		=> 'log_manager',
						'access'	=> ['root', 'admin'],
						'url'		=> 'core/change_log',
					],
					[
						'title'		=> 'cron',
						'access'	=> ['root', 'admin'],
						'url'		=> 'cron/cron/start',
					],
					[
						'title'		=> 'dict',
						'access'	=> ['root', 'admin'],
						'url'		=> 'core/model_table_db/start/dict_db',
					],
					[
						'title'		=> 'localisation',
						'access'	=> ['root', 'admin'],
						'url'		=> 'core/model_table_db/start/localisation_db',
					],
					[
						'title'		=> 'notes',
						'access'	=> ['root', 'admin'],
						'url'		=> 'core/model_table_db/start/notes_db',
					],
					[
						'title'		=> 'session_list',
						'access'	=> ['root', 'admin'],
//						'url'		=> 'core/model_table_db/start/session_db',
						'url'		=> 'core/session',
					],
					[
						'title'		=> 'block_ip_list',
						'access'	=> ['root', 'admin'],
						'url'		=> 'site/block_ip',
					],
				],
			],
			'email_list'	=> [
				'title'		=> 'email_list',
				'className'	=> 'icon icon-left-h30 envelope-o',
				'access'	=> ['root', 'admin'],
				'sub'		=> [
					'email_list'	=> [
						'title'		=> 'email_list',
						'access'	=> ['root', 'admin'],
						'url'		=> 'mail/mail',
					],
					'subscriber'	=> [
						'title'		=> 'subscribers',
						'access'	=> ['root', 'admin'],
						'url'		=> 'mail/subscriber',
					],
					'mail_template'	=> [
						'title'		=> 'mail_templates',
						'access'	=> ['root', 'admin'],
						'url'		=> 'mail/mail_template',
					],
					'mail_settings'	=> [
						'title'		=> 'mail_settings',
						'access'	=> ['root', 'admin'],
						'url'		=> 'mail/settings',
					],
				],
			],
			'news'	=> [
				'title'		=> 'news_list',
				'className'	=> 'icon icon-left-h30 newspaper-o',
				'access'	=> ['root', 'admin'],
				'sub'		=> [
					'news'	=> [
						'title'		=> 'news_list',
						'access'	=> ['root', 'admin'],
						'url'		=> 'news/news',
					],
					'news_category'	=> [
						'title'		=> 'news_category_list',
						'access'	=> ['root', 'admin'],
						'url'		=> 'news/cat',
					],
					'news_settings'	=> [
						'title'		=> 'news_settings',
						'access'	=> ['root', 'admin'],
						'url'		=> 'news/settings',
					],
				],
			],
			'backup'	=> [
				'title'		=> 'backup',
				'className'	=> 'icon icon-left-h30 file-archive-o',
				'access'	=> ['root', 'admin'],
				'sub'		=> [
					[
						'title'		=> 'backup_db',
						'access'	=> ['root', 'admin'],
						'url'		=> 'backup/backup',
					],
					[
						'title'		=> 'backup_settings',
						'access'	=> ['root', 'admin'],
						'url'		=> 'backup/settings',
					],
				],
			],
			'callback'		=> [
				'title'		=> 'callback',
				'className'	=> 'icon icon-left-h30 phone',
				'access'	=> ['root', 'admin'],
				'url'		=> 'callback/callback',
			],
		],
	],
];